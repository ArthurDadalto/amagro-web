# AMAGRO — Arquitetura Frontend (React + Vite + Tailwind)

## 1. Stack

| Lib | Versão | Papel |
|-----|--------|-------|
| React | 19 | UI |
| Vite | 6 | Build/dev |
| Tailwind CSS | 4 | Styling |
| React Router | 7 | Rotas SPA |
| Zustand | 5 | Estado global (auth, farm selecionada) |
| TanStack Query | 5 | Data fetching, cache, mutations |
| Axios | 1.7 | HTTP client |
| Leaflet + react-leaflet | 4 | Mapas |
| Recharts | 2 | Gráficos do dashboard |
| React Hook Form + Zod | - | Forms + validação |
| Lucide React | - | Ícones |

**Zero libs desnecessárias.** Sem Redux, sem Material UI, sem Styled Components.

## 2. Design System — Tokens

```js
// tailwind.config.js — cores AMAGRO
colors: {
  brand: {
    50:  '#f0fdf4',
    100: '#dcfce7',
    200: '#bbf7d0',
    300: '#86efac',
    400: '#4ade80',
    500: '#22c55e',  // Primary
    600: '#16a34a',  // Primary hover
    700: '#15803d',
    800: '#166534',
    900: '#14532d',
  },
  earth: {
    50:  '#faf5f0',
    100: '#f0e6d3',
    500: '#8B6914',  // Accent (café/terra)
    700: '#6B4F10',
  }
}
```

Mobile-first: breakpoints `sm:640 md:768 lg:1024 xl:1280`

## 3. Hierarquia de Componentes

```
<App>
├── <AuthProvider>              // Zustand: user, token, farm selecionada
│   ├── <PublicRoutes>
│   │   ├── /login              → <LoginPage>
│   │   └── /register           → <RegisterPage>
│   │
│   └── <ProtectedRoutes>
│       └── <AppLayout>         // Sidebar + Header + MobileNav
│           ├── /               → <DashboardPage>
│           ├── /fazenda        → <FarmSettingsPage>
│           ├── /talhoes        → <PlotsListPage>
│           ├── /talhoes/:id    → <PlotDetailPage>
│           ├── /gastos         → <ExpensesPage>
│           ├── /colheita       → <HarvestsPage>
│           ├── /estoque        → <InventoryPage>
│           ├── /solo           → <SoilPage>
│           ├── /solo/mapa      → <SoilMapPage>        // Leaflet
│           ├── /lotes          → <LotsPage>
│           ├── /lotes/:id      → <LotDetailPage>
│           ├── /precificacao   → <PricingPage>
│           ├── /irrigacao      → <IrrigationPage>
│           └── /clima          → <WeatherPage>
```

## 4. Componentes Reutilizáveis (ui/)

| Componente | Uso |
|-----------|-----|
| `<Button>` | Variants: primary, secondary, danger, ghost. Sizes: sm, md, lg |
| `<Input>` | Text, number, date, currency (centavos). Com label e error |
| `<Select>` | Dropdown nativo estilizado. Async options via TanStack Query |
| `<Card>` | Container com shadow, padding, border-radius |
| `<Modal>` | Dialog acessível (focus trap, ESC close) |
| `<Table>` | Responsive (cards no mobile, tabela no desktop) |
| `<Badge>` | Status tags: draft (cinza), published (verde), alerta (vermelho) |
| `<Stat>` | Métrica com label + valor + variação. Usado no dashboard |
| `<EmptyState>` | Ilustração + CTA quando lista está vazia |
| `<LoadingSkeleton>` | Placeholder animado durante fetch |
| `<CurrencyInput>` | Máscara R$ que salva centavos |
| `<DateRange>` | Seletor de período (from/to) para filtros |

## 5. Layout

### Desktop (lg+)
```
┌──────────────────────────────────────────────┐
│ Sidebar (240px)  │  Header (farm name + user)│
│ ┌──────────────┐ │  ─────────────────────────│
│ │ Logo AMAGRO  │ │  Content area             │
│ │ Dashboard    │ │                           │
│ │ Talhões      │ │                           │
│ │ Gastos       │ │                           │
│ │ Colheita     │ │                           │
│ │ Estoque      │ │                           │
│ │ Solo & Mapa  │ │                           │
│ │ Lotes/QR     │ │                           │
│ │ Precificação │ │                           │
│ │ Irrigação    │ │                           │
│ │ Clima        │ │                           │
│ │              │ │                           │
│ │ ─────────── │ │                           │
│ │ Farm select  │ │                           │
│ │ Configurações│ │                           │
│ └──────────────┘ │                           │
└──────────────────────────────────────────────┘
```

### Mobile (< lg)
```
┌────────────────────┐
│ Header (hamburger) │
│ ───────────────────│
│ Content area       │
│ (full width)       │
│                    │
│                    │
│                    │
│ ───────────────────│
│ Bottom Nav (5 tabs)│
│ Home|Gastos|+|Lotes│
└────────────────────┘

Bottom Nav tabs:
1. Dashboard (home)
2. Gastos
3. + (FAB: novo gasto / nova colheita / novo lote)
4. Lotes
5. Mais (menu completo)
```

## 6. Data Fetching — TanStack Query

```jsx
// hooks/useExpenses.js
export function useExpenses(farmId, filters) {
  return useQuery({
    queryKey: ['expenses', farmId, filters],
    queryFn: () => api.get(`/farms/${farmId}/expenses`, { params: filters }),
    staleTime: 1000 * 60 * 5, // 5 min
  });
}

export function useCreateExpense(farmId) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data) => api.post(`/farms/${farmId}/expenses`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses', farmId] });
      queryClient.invalidateQueries({ queryKey: ['dashboard', farmId] });
    },
  });
}
```

**Regras:**
- Toda query tem `staleTime: 5min` (dados agropecuários não mudam a cada segundo)
- Mutations invalidam queries relacionadas
- `enabled: !!farmId` evita fetch antes de selecionar farm
- Offline: TanStack Query retorna cache stale automaticamente

## 7. Estado Global (Zustand)

```js
// stores/authStore.js
export const useAuthStore = create((set) => ({
  user: null,
  token: null,
  currentFarmId: null,
  setAuth: (user, token) => set({ user, token, currentFarmId: user.farms[0]?.id }),
  setCurrentFarm: (farmId) => set({ currentFarmId: farmId }),
  logout: () => set({ user: null, token: null, currentFarmId: null }),
}));
```

**Apenas auth e farm selecionada no Zustand.** Todo o resto é server state via TanStack Query.

## 8. Estrutura de Pastas

```
src/
├── api/
│   ├── client.js              # Axios instance + interceptors
│   ├── auth.js                # login, register, logout, me
│   ├── farms.js               # CRUD farms
│   ├── plots.js               # CRUD plots
│   ├── expenses.js            # CRUD expenses + summary
│   ├── harvests.js            # CRUD harvests + summary
│   ├── inventory.js           # CRUD items + movements
│   ├── soil.js                # CRUD analyses + alerts
│   ├── lots.js                # CRUD lots + publish/unpublish
│   ├── pricing.js             # cost-per-bag, quotation, margin
│   ├── irrigation.js          # calculate, CRUD saved
│   ├── weather.js             # forecast
│   └── dashboard.js           # metrics
│
├── components/
│   ├── ui/                    # Design system primitives
│   ├── layout/
│   │   ├── AppLayout.jsx
│   │   ├── Sidebar.jsx
│   │   ├── Header.jsx
│   │   ├── MobileNav.jsx
│   │   └── BottomNav.jsx
│   └── maps/
│       ├── FarmMap.jsx        # Leaflet base com MapTiler satellite
│       ├── PlotMarker.jsx
│       └── NdviLayer.jsx     # futuro
│
├── features/
│   ├── auth/
│   │   ├── LoginPage.jsx
│   │   ├── RegisterPage.jsx
│   │   └── useAuth.js
│   ├── dashboard/
│   │   ├── DashboardPage.jsx
│   │   ├── StatGrid.jsx
│   │   ├── ExpenseChart.jsx
│   │   └── AlertsList.jsx
│   ├── farms/
│   │   └── FarmSettingsPage.jsx
│   ├── plots/
│   │   ├── PlotsListPage.jsx
│   │   ├── PlotDetailPage.jsx
│   │   └── PlotForm.jsx
│   ├── expenses/
│   │   ├── ExpensesPage.jsx
│   │   ├── ExpenseForm.jsx
│   │   └── ExpenseSummary.jsx
│   ├── harvests/
│   │   ├── HarvestsPage.jsx
│   │   └── HarvestForm.jsx
│   ├── inventory/
│   │   ├── InventoryPage.jsx
│   │   ├── ItemForm.jsx
│   │   └── MovementForm.jsx
│   ├── soil/
│   │   ├── SoilPage.jsx
│   │   ├── SoilMapPage.jsx
│   │   └── AnalysisForm.jsx
│   ├── lots/
│   │   ├── LotsPage.jsx
│   │   ├── LotDetailPage.jsx
│   │   ├── LotForm.jsx
│   │   └── QrCodePreview.jsx
│   ├── pricing/
│   │   ├── PricingPage.jsx
│   │   └── MarginCalculator.jsx
│   ├── irrigation/
│   │   ├── IrrigationPage.jsx
│   │   └── Calculator.jsx
│   └── weather/
│       ├── WeatherPage.jsx
│       └── ForecastCard.jsx
│
├── hooks/
│   ├── useExpenses.js
│   ├── useHarvests.js
│   ├── useInventory.js
│   ├── useLots.js
│   ├── useDashboard.js
│   └── ...
│
├── lib/
│   ├── formatCurrency.js      # centavos → "R$ 1.234,56"
│   ├── formatDate.js          # ISO → "15/03/2026"
│   ├── constants.js           # Enum labels, process names pt-BR
│   └── cn.js                  # classnames helper
│
├── stores/
│   └── authStore.js
│
├── routes/
│   └── index.jsx              # React Router config
│
├── App.jsx
├── main.jsx
└── index.css                  # Tailwind imports
```

## 9. Performance

| Técnica | Implementação |
|---------|--------------|
| Code splitting | `React.lazy()` por feature (cada página é um chunk) |
| Prefetch | Hover em nav item → `queryClient.prefetchQuery` |
| Image lazy loading | QR codes e mapas com `loading="lazy"` |
| Bundle size | Sem moment.js (usa date-fns ou Intl nativo), tree-shake Recharts |
| Offline read | TanStack Query `gcTime: Infinity` para dados já carregados |
| Mapa | Leaflet tiles carregam sob demanda, cluster markers se > 50 plots |

## 10. Acessibilidade

- Todos os inputs com `<label>` associado
- Modais com focus trap e `role="dialog"`
- Contraste mínimo 4.5:1 (verificado nos tokens brand/earth)
- Skip link para conteúdo principal
- Tabelas responsivas: `role="grid"` no mobile com cards
- Touch targets mínimo 44×44px (mobile-first)
