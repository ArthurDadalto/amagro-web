# ADR-001: Escolha da Stack

## Status: Aceito

## Contexto
AMAGRO é um SaaS de gestão para produtores de café no ES e sul da Bahia.
Precisamos de uma stack que permita desenvolvimento rápido por uma equipe de 2 pessoas.

## Decisão
- **Backend:** Laravel 11 (PHP) — ecossistema maduro, Sanctum para auth SPA, Eloquent ORM
- **Frontend:** React + Vite + Tailwind — performance, ecossistema, contratação
- **Banco:** MySQL (Laragon local) / PostgreSQL (produção)
- **Auth:** Sanctum SPA mode — mais simples que Passport/JWT para SPA

## Alternativas descartadas
- Node.js + Express: menos produtivo para CRUD pesado e migrations
- Inertia.js: acopla front e back, dificulta mobile futuro
- Next.js: SSR desnecessário para dashboard SPA, complexidade extra

## Consequências
- Laravel fornece tudo out-of-the-box (auth, queue, cache, ORM)
- React SPA desacoplada permite mobile futuro
- Equipe pode trabalhar em paralelo (api/ e web/)
