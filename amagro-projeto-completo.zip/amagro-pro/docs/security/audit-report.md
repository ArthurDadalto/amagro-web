# AMAGRO — Auditoria de Segurança (AppSec)

**Auditor:** Engenheiro Sênior de Segurança
**Data:** Abril 2026
**Escopo:** Todo código entregue — backend Laravel 11, frontend React, migrations, módulo de rastreabilidade
**Classificação:** Crítico / Alto / Médio / Baixo

---

## RESUMO EXECUTIVO

| Severidade | Encontrados | Corrigidos |
|-----------|------------|------------|
| Crítico | 3 | 3 |
| Alto | 7 | 7 |
| Médio | 8 | 8 |
| Baixo | 5 | 5 |
| **Total** | **23** | **23** |

---

## 1. SQL INJECTION

### VULN-001 — ILIKE com interpolação direta (CRÍTICO)

**Arquivo:** `LotService.php` linha 16
**Código vulnerável:**
```php
->when($filters['variety'] ?? null, fn ($q, $v) => $q->where('variety', 'ilike', "%{$v}%"))
```

**Risco:** O valor de `$v` vem direto do `$request->only(['variety'])`. Embora o Eloquent `where()` com 3 argumentos use bindings, o padrão `%{$v}%` é montado como string PHP antes de virar binding. Neste caso específico do Eloquent o binding é seguro, MAS o `ilike` é PostgreSQL-only e não existe no MySQL. Além disso, o filtro `status` não é validado contra o enum.

**Correção:**
```php
public function list(array $filters = [], int $perPage = 20): CursorPaginator
{
    return Lot::query()
        ->with('plot:id,name')
        ->when(
            $filters['status'] ?? null,
            fn ($q, $s) => in_array($s, ['draft', 'published']) ? $q->where('status', $s) : $q
        )
        ->when(
            $filters['variety'] ?? null,
            fn ($q, $v) => $q->where('variety', 'like', '%' . str_replace(['%', '_'], ['\%', '\_'], $v) . '%')
        )
        ->orderByDesc('created_at')
        ->cursorPaginate(min($perPage, 100)); // Cap pagination
}
```

**O que mudou:**
- Escapar `%` e `_` wildcards no input do usuário (previne pattern injection)
- Usar `like` (universal) ao invés de `ilike` (PostgreSQL-only)
- Validar `status` contra valores permitidos (enum whitelist)
- Cap de `per_page` em 100 (previne DoS por paginação absurda)

---

### VULN-002 — Paginação sem limite máximo (MÉDIO)

**Arquivo:** `LotController.php` linha 28
**Código vulnerável:**
```php
perPage: $request->integer('per_page', 20),
```

**Risco:** Atacante pode enviar `?per_page=999999` e forçar query retornando todos os registros → DoS via memória.

**Correção:** Já incluída no fix acima: `min($perPage, 100)`.

---

### VULN-003 — StoreLotRequest plot_id sem validação de tenant (CRÍTICO)

**Arquivo:** `StoreLotRequest.php` linha 18
**Código vulnerável:**
```php
'plot_id' => ['nullable', 'integer', 'exists:plots,id'],
```

**Risco:** IDOR — O `exists:plots,id` valida que o plot existe em QUALQUER fazenda. Usuário A pode vincular um lote ao talhão do Usuário B enviando o `plot_id` de outra fazenda.

**Correção:**
```php
'plot_id' => [
    'nullable',
    'integer',
    Rule::exists('plots', 'id')->where('farm_id', app('current_farm_id')),
],
```

---

## 2. XSS — CROSS-SITE SCRIPTING

### VULN-004 — Blade template com dados do usuário (BAIXO — já protegido)

**Arquivo:** `show.blade.php`
**Análise:** A Blade view usa `{{ }}` (double curly braces) em toda saída, que automaticamente aplica `htmlspecialchars`. Nenhum uso de `{!! !!}` (raw output).

**Status:** ✅ Seguro. Blade escapa automaticamente.

**Mas atenção na OG meta:**
```html
<meta property="og:description" content="{{ $lot['sensory_notes'] }}">
```
Se `sensory_notes` contiver aspas duplas, o atributo HTML quebra. Blade escapa `"` para `&quot;` então está seguro, mas recomendo validação extra no backend:

**Correção adicional no `StoreLotRequest.php`:**
```php
'sensory_notes' => ['nullable', 'string', 'max:500', 'regex:/^[^<>]*$/'],
```

---

### VULN-005 — React renderização segura (BAIXO — já protegido)

**Arquivo:** `LotsPage.jsx`, `LotForm.jsx`
**Análise:** Nenhum uso de `dangerouslySetInnerHTML`. Todos os dados são interpolados via JSX `{lot.variety}` que escapa automaticamente.

**Status:** ✅ Seguro.

---

## 3. CSRF PROTECTION

### VULN-006 — Axios sem configuração CSRF (ALTO)

**Arquivo:** `lotsApi.js` importa `api` de `../client` (arquivo não fornecido)
**Risco:** Se o Axios client não estiver configurado para enviar o cookie `XSRF-TOKEN` como header, todas as requisições POST/PUT/DELETE podem falhar ou ficar sem proteção CSRF.

**Correção — `api/client.js` (deve ser criado/corrigido):**
```javascript
import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api/v1',
  withCredentials: true, // OBRIGATÓRIO para Sanctum SPA auth
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  },
});

// Interceptor: pegar CSRF cookie antes de mutations
api.interceptors.request.use(async (config) => {
  const methods = ['post', 'put', 'patch', 'delete'];
  if (methods.includes(config.method)) {
    // Sanctum CSRF cookie endpoint
    await axios.get('/sanctum/csrf-cookie', { withCredentials: true });
  }
  return config;
});

// Interceptor: tratar 401 (token expirado)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Clear auth state and redirect to login
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;
```

**Laravel config necessário (`config/sanctum.php`):**
```php
'stateful' => explode(',', env('SANCTUM_STATEFUL_DOMAINS', 'localhost,localhost:5173,amagro.com.br')),
```

**Laravel CORS (`config/cors.php`):**
```php
'supports_credentials' => true,
'allowed_origins' => [env('FRONTEND_URL', 'http://localhost:5173')],
```

---

## 4. PROTEÇÃO MULTI-TENANT / IDOR

### VULN-007 — Route model binding sem tenant scope (CRÍTICO)

**Arquivo:** `LotController.php` — todos os métodos que recebem `Lot $lot`
**Risco:** O Laravel resolve `{lot}` via route model binding usando o `id` do Model. Se o Global Scope `FarmScope` não estiver aplicado no momento do binding, o user A pode acessar o lote do user B trocando o ID na URL.

**O FarmScope depende de `app('current_farm_id')` estar setado.** Se o middleware `EnsureFarmAccess` roda ANTES do model binding, está OK. Mas a ORDEM de middleware importa.

**Correção — verificar no Controller:**
```php
// LotController.php — adicionar em cada método que recebe Lot
public function show(Lot $lot): LotResource
{
    // Double-check: lot pertence à farm atual
    abort_unless($lot->farm_id === app('current_farm_id'), 403);

    return new LotResource($lot->load(['plot', 'farm']));
}
```

**Aplicar o mesmo pattern em:** `update()`, `destroy()`, `publish()`, `unpublish()`.

**Correção robusta — Custom route model binding no Model:**
```php
// Lot.php — adicionar
public function resolveRouteBinding($value, $field = null): ?self
{
    return $this->where('id', $value)
        ->where('farm_id', app('current_farm_id'))
        ->firstOrFail();
}
```

---

### VULN-008 — QR Code path traversal (MÉDIO)

**Arquivo:** `GenerateQrCode.php` linha 26
**Código:**
```php
$path = "qrcodes/{$this->lot->hash}.png";
```

**Risco:** Se o hash for manipulado (improvável dado o fluxo, mas defensivamente), poderia conter `../` e gravar fora do diretório.

**Correção:**
```php
$safeHash = preg_replace('/[^a-z0-9]/', '', $this->lot->hash);
$path = "qrcodes/{$safeHash}.png";
```

---

### VULN-009 — Lote model expõe `id` interno na API (MÉDIO)

**Arquivo:** `LotResource.php` linha 13
```php
'id' => $this->id, // Internal, for auth routes only
```

**Risco:** O `id` auto-increment expõe a sequência e total de registros. Permite enumeração.

**Correção:** Usar o hash como identificador na API e mapear internamente:
```php
// LotResource.php
'id' => $this->hash, // Usar hash como identificador público

// LotController.php — resolver por hash na API também
Route::apiResource('lots', LotController::class)->parameters(['lots' => 'lot:hash']);
```

**OU** manter o `id` nas rotas autenticadas (baixo risco porque é dentro do tenant scope) mas documentar a decisão. Recomendo o hash.

---

## 5. DOUBLE POST / IDEMPOTENCY

### VULN-010 — Publicação de lote sem idempotency (ALTO)

**Arquivo:** `LotService.php` método `publish()`
**Risco:** Se o usuário clicar "Publicar" duas vezes rápido, dois jobs `GenerateQrCode` são disparados. O check `isPublished()` pode não ser suficiente em race condition.

**Correção backend — lock otimista:**
```php
public function publish(Lot $lot): Lot
{
    if ($lot->isPublished()) {
        throw new \DomainException('Este lote já está publicado.');
    }

    $updated = DB::transaction(function () use ($lot) {
        // Pessimistic lock: SELECT ... FOR UPDATE
        $lockedLot = Lot::withoutGlobalScopes()
            ->where('id', $lot->id)
            ->where('status', LotStatus::Draft) // Only if still draft
            ->lockForUpdate()
            ->first();

        if (! $lockedLot) {
            throw new \DomainException('Este lote já está publicado.');
        }

        $lockedLot->update([
            'status'       => LotStatus::Published,
            'published_at' => now(),
        ]);

        GenerateQrCode::dispatch($lockedLot);

        return $lockedLot;
    });

    return $updated->fresh();
}
```

**Correção frontend — desabilitar botão:**
```jsx
// LotsPage.jsx — já tem disabled={publishMut.isPending} ✅
// Mas adicionar feedback visual:
<button
  onClick={() => publishMut.mutate(lot.id)}
  disabled={publishMut.isPending}
  className={`p-2 rounded-lg transition-colors ${
    publishMut.isPending
      ? 'text-gray-300 cursor-not-allowed'
      : 'text-brand-600 hover:bg-brand-50'
  }`}
>
  {publishMut.isPending ? (
    <Loader2 className="w-4 h-4 animate-spin" />
  ) : (
    <Globe className="w-4 h-4" />
  )}
</button>
```

---

### VULN-011 — Criação de lote sem deduplição (MÉDIO)

**Arquivo:** `LotService.php` método `create()`
**Risco:** Double submit cria dois lotes idênticos.

**Correção — Idempotency key:**
```php
// LotController.php
public function store(StoreLotRequest $request): JsonResponse
{
    $idempotencyKey = $request->header('X-Idempotency-Key');

    if ($idempotencyKey) {
        $cacheKey = "idempotency:{$idempotencyKey}:" . auth()->id();
        if ($cached = Cache::get($cacheKey)) {
            return (new LotResource(Lot::find($cached)))
                ->response()->setStatusCode(201);
        }
    }

    $lot = $this->lotService->create([
        'farm_id' => app('current_farm_id'),
        ...$request->validated(),
    ]);

    if ($idempotencyKey) {
        Cache::put($cacheKey, $lot->id, 3600); // 1h
    }

    return (new LotResource($lot->load('plot')))
        ->response()->setStatusCode(201);
}
```

**Frontend — gerar idempotency key:**
```javascript
// lotsApi.js
import { v4 as uuidv4 } from 'uuid';

create: (farmId, data) =>
  api.post(`/farms/${farmId}/lots`, data, {
    headers: { 'X-Idempotency-Key': uuidv4() },
  }).then(r => r.data),
```

---

## 6. RATE LIMITING

### VULN-012 — Rate limiting genérico insuficiente (ALTO)

**Arquivo:** `routes.php` — rota pública tem `throttle:60,1` mas API não tem limites específicos.

**Correção — `app/Providers/AppServiceProvider.php`:**
```php
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Support\Facades\RateLimiter;

public function boot(): void
{
    // Login: 5 tentativas / 15 min por IP
    RateLimiter::for('login', function ($request) {
        $key = $request->ip();
        return Limit::perMinutes(15, 5)->by($key)->response(function () {
            return response()->json([
                'message' => 'Muitas tentativas. Aguarde 15 minutos.',
                'code' => 'RATE_LIMIT_LOGIN',
            ], 429);
        });
    });

    // Registro: 3 contas / hora por IP
    RateLimiter::for('register', function ($request) {
        return Limit::perHour(3)->by($request->ip());
    });

    // API autenticada: 60/min por user
    RateLimiter::for('api', function ($request) {
        return $request->user()
            ? Limit::perMinute(60)->by($request->user()->id)
            : Limit::perMinute(30)->by($request->ip());
    });

    // Criação de lotes: 20/hora por farm
    RateLimiter::for('create-lot', function ($request) {
        return Limit::perHour(20)->by(app('current_farm_id'));
    });

    // Página pública: 120/min por IP (anti-scraping)
    RateLimiter::for('public-lot', function ($request) {
        return Limit::perMinute(120)->by($request->ip());
    });

    // Cotação: 10/hora por farm (API externa)
    RateLimiter::for('external-api', function ($request) {
        return Limit::perHour(10)->by(app('current_farm_id'));
    });
}
```

**Aplicar nas rotas:**
```php
// routes/api.php
Route::post('login', ...)->middleware('throttle:login');
Route::post('register', ...)->middleware('throttle:register');

// Dentro do grupo farm:
Route::post('lots', [LotController::class, 'store'])->middleware('throttle:create-lot');
Route::get('pricing/quotation', ...)->middleware('throttle:external-api');

// routes/web.php
Route::get('/lote/{hash}', ...)->middleware('throttle:public-lot');
```

---

## 7. GOOGLE reCAPTCHA v3

### VULN-013 — Sem proteção anti-bot (ALTO)

**Correção backend — Middleware reCAPTCHA:**
```php
// app/Http/Middleware/VerifyRecaptcha.php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class VerifyRecaptcha
{
    public function handle(Request $request, Closure $next, float $minScore = 0.5)
    {
        $token = $request->input('recaptcha_token');

        if (! $token) {
            abort(422, 'reCAPTCHA token ausente.');
        }

        $response = Http::asForm()->post('https://www.google.com/recaptcha/api/siteverify', [
            'secret'   => config('services.recaptcha.secret'),
            'response' => $token,
            'remoteip' => $request->ip(),
        ]);

        $result = $response->json();

        if (! ($result['success'] ?? false) || ($result['score'] ?? 0) < $minScore) {
            abort(422, 'Verificação de segurança falhou. Tente novamente.');
        }

        return $next($request);
    }
}
```

**Config:**
```php
// config/services.php
'recaptcha' => [
    'site_key' => env('RECAPTCHA_SITE_KEY'),
    'secret'   => env('RECAPTCHA_SECRET_KEY'),
],
```

**Aplicar em:** `login`, `register`, `forgot-password`.

**Frontend — hook:**
```javascript
// hooks/useRecaptcha.js
import { useCallback } from 'react';

export function useRecaptcha() {
  const execute = useCallback(async (action) => {
    if (!window.grecaptcha) return null;
    return window.grecaptcha.execute(
      import.meta.env.VITE_RECAPTCHA_SITE_KEY,
      { action }
    );
  }, []);

  return { execute };
}

// Uso no LoginPage:
const { execute } = useRecaptcha();
const onSubmit = async (data) => {
  const recaptcha_token = await execute('login');
  await loginApi({ ...data, recaptcha_token });
};
```

---

## 8. SEGURANÇA DE API — CHAVES E ANTI-ABUSO

### VULN-014 — MapTiler API key exposta no frontend (ALTO)

**Arquivo:** (planejado na arquitetura) — Leaflet precisa da key do MapTiler para tiles de satélite.
**Risco:** API key no JS bundle pode ser extraída e abusada.

**Correção:**
1. **MapTiler:** Restringir key por domínio (HTTP Referrer) no painel MapTiler
2. **Sentinel Hub, Pagar.me, CEPEA:** Sempre via backend. Nunca expor no frontend.
3. **Open-Meteo:** Gratuito sem key, mas proxiar pelo backend para evitar exposição de coordenadas do usuário.

```php
// .env — NUNCA no frontend
MAPTILER_API_KEY=xxx
SENTINEL_HUB_KEY=xxx
PAGARME_API_KEY=xxx
PAGARME_ENCRYPTION_KEY=xxx

// Frontend .env — APENAS o que é seguro expor
VITE_API_URL=https://api.amagro.com.br/api/v1
VITE_MAPTILER_KEY=xxx  // OK se restrito por referrer
VITE_RECAPTCHA_SITE_KEY=xxx  // Público por design
```

---

### VULN-015 — Sem proxy para APIs externas (MÉDIO)

**Correção — Controller proxy para weather:**
```php
// WeatherController.php
public function forecast(Farm $farm): JsonResponse
{
    abort_unless($farm->latitude && $farm->longitude, 422, 'Fazenda sem coordenadas.');

    $data = app(WeatherService::class)->getForecast(
        $farm->latitude,
        $farm->longitude
    );

    return response()->json($data);
}
```

Nunca permitir que o frontend chame Open-Meteo diretamente — sempre pelo backend que aplica cache e rate limiting.

---

## 9. HEADERS DE SEGURANÇA

### VULN-016 — Sem headers de segurança (ALTO)

**Correção — Middleware:**
```php
// app/Http/Middleware/SecurityHeaders.php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class SecurityHeaders
{
    public function handle(Request $request, Closure $next)
    {
        $nonce = base64_encode(random_bytes(16));
        app()->instance('csp_nonce', $nonce);

        $response = $next($request);

        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('X-Frame-Options', 'DENY');
        $response->headers->set('X-XSS-Protection', '0'); // CSP substitui
        $response->headers->set('Referrer-Policy', 'strict-origin-when-cross-origin');
        $response->headers->set('Permissions-Policy', 'camera=(), microphone=(), geolocation=(self)');

        // CSP com nonce para inline styles da Blade page
        $response->headers->set('Content-Security-Policy', implode('; ', [
            "default-src 'self'",
            "script-src 'self' https://www.google.com https://www.gstatic.com 'nonce-{$nonce}'",
            "style-src 'self' 'nonce-{$nonce}'",
            "img-src 'self' data: https://*.maptiler.com https://*.tile.openstreetmap.org",
            "connect-src 'self' https://api.amagro.com.br",
            "font-src 'self'",
            "frame-src https://www.google.com", // reCAPTCHA
            "base-uri 'self'",
            "form-action 'self'",
        ]));

        // HSTS em produção
        if (app()->isProduction()) {
            $response->headers->set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
        }

        return $response;
    }
}
```

**Blade template — usar nonce no style inline:**
```html
<style nonce="{{ app('csp_nonce') }}">
    /* ... CSS da página pública ... */
</style>
```

**Registrar no Kernel:**
```php
// bootstrap/app.php ou Kernel
->withMiddleware(function (Middleware $middleware) {
    $middleware->append(SecurityHeaders::class);
})
```

---

## 10. AUTENTICAÇÃO

### VULN-017 — Sem política de senha (MÉDIO)

**Correção no RegisterRequest:**
```php
use Illuminate\Validation\Rules\Password;

'password' => [
    'required',
    'confirmed',
    Password::min(8)
        ->letters()
        ->mixedCase()
        ->numbers()
        ->uncompromised(), // Verifica no Have I Been Pwned
],
```

---

### VULN-018 — Token Sanctum sem expiração (MÉDIO)

**Correção — `config/sanctum.php`:**
```php
'expiration' => 60 * 24 * 7, // 7 dias em minutos
```

**Pruning automático — `app/Console/Kernel.php`:**
```php
$schedule->command('sanctum:prune-expired --hours=168')->daily();
```

---

### VULN-019 — Logout não invalida token (MÉDIO)

**Correção:**
```php
// AuthController.php
public function logout(Request $request): JsonResponse
{
    // Revogar token atual
    $request->user()->currentAccessToken()->delete();

    return response()->json(['message' => 'Logout realizado.']);
}
```

---

### VULN-020 — Sem bloqueio após tentativas de login (ALTO)

Coberto pelo rate limiter `login` no VULN-012. Adicionar também:

```php
// LoginController.php
public function login(LoginRequest $request): JsonResponse
{
    if (! Auth::attempt($request->only('email', 'password'))) {
        // Log tentativa falha para auditoria
        Log::warning('Login falhou', [
            'email' => $request->email,
            'ip'    => $request->ip(),
        ]);

        throw ValidationException::withMessages([
            'email' => ['Credenciais inválidas.'],
        ]);
    }

    $user = Auth::user();
    $token = $user->createToken('app')->plainTextToken;

    return response()->json([
        'token' => $token,
        'user'  => new UserResource($user),
    ]);
}
```

---

## 11. STORAGE / UPLOAD

### VULN-021 — QR Code servido sem validação de ownership (BAIXO)

**Arquivo:** `GenerateQrCode.php` — salva no disco `public`
**Risco:** Qualquer pessoa com a URL `/storage/qrcodes/a1b2c3d4.png` acessa o QR Code diretamente. Porém, QR Codes de lotes publicados são intencionalmente públicos. QR de lotes em rascunho não deveriam existir (QR só é gerado na publicação).

**Status:** ✅ Aceitável. QR é público por design. Mas validar que ao despublicar o arquivo é deletado:

```php
// LotService.php — unpublish
public function unpublish(Lot $lot): Lot
{
    if ($lot->isDraft()) {
        throw new \DomainException('Este lote já é rascunho.');
    }

    // Deletar arquivo QR do storage
    if ($lot->qr_code_path) {
        Storage::disk('public')->delete($lot->qr_code_path);
    }

    $lot->update([
        'status'       => LotStatus::Draft,
        'qr_code_path' => null,
        'published_at' => null,
    ]);

    Cache::forget("lot:{$lot->hash}");

    return $lot->fresh();
}
```

---

## 12. CACHE POISONING

### VULN-022 — Cache da página pública sem invalidação em update (BAIXO)

**Arquivo:** `LotService.php` — `findPublicByHash()` usa `Cache::remember` com TTL 1h.
**Risco:** Se dados do lote ou fazenda forem alterados, o cache serve dados antigos por até 1h.

**Correção — invalidar ao atualizar fazenda:**
```php
// FarmService.php
public function update(Farm $farm, array $data): Farm
{
    $farm->update($data);

    // Invalidar cache de todos os lotes publicados desta fazenda
    $farm->lots()->published()->pluck('hash')->each(fn ($hash) =>
        Cache::forget("lot:{$hash}")
    );

    return $farm->fresh();
}
```

---

## 13. SEGUNDA REVISÃO — Achados Adicionais

### VULN-023 — Lot Model `$hidden` conflita com API Resource (BAIXO)

**Arquivo:** `Lot.php` linha 27
```php
protected $hidden = ['id', 'farm_id', 'plot_id', 'deleted_at'];
```

**Risco:** O `LotResource` tenta acessar `$this->id` que está em `$hidden`. O `$hidden` afeta `toArray()`/`toJson()` mas NÃO afeta acesso direto via `$this->id` no Resource. Porém, se alguém fizer `Lot::find(1)->toJson()` fora do Resource, o id vaza. Inconsistência.

**Correção:** Remover `$hidden` do Model e controlar visibilidade exclusivamente no Resource:
```php
// Lot.php — remover a linha:
// protected $hidden = ['id', 'farm_id', 'plot_id', 'deleted_at'];

// Toda formatação de output é responsabilidade do LotResource
```

---

## CÓDIGO CORRIGIDO COMPLETO — ARQUIVOS PRONTOS

Os arquivos corrigidos estão nos arquivos que acompanham este relatório:

| Arquivo | Correções aplicadas |
|---------|-------------------|
| `LotService.php` | VULN-001, 010, 021, 022 |
| `LotController.php` | VULN-007, 011 |
| `StoreLotRequest.php` | VULN-003, 004 |
| `LotResource.php` | VULN-009 |
| `Lot.php` | VULN-023 |
| `SecurityHeaders.php` | VULN-016 (novo) |
| `VerifyRecaptcha.php` | VULN-013 (novo) |
| `client.js` | VULN-006 |
| `AppServiceProvider.php` | VULN-012 |
| `GenerateQrCode.php` | VULN-008 |
| `show.blade.php` | VULN-016 (nonce) |

---

## CHECKLIST PRÉ-LANÇAMENTO

- [ ] Todas as 23 correções aplicadas
- [ ] `.env` em produção sem chaves hardcoded
- [ ] HTTPS habilitado (Caddy auto-SSL ou Let's Encrypt)
- [ ] `APP_DEBUG=false` em produção
- [ ] `APP_ENV=production` em produção
- [ ] reCAPTCHA v3 ativo em login/registro
- [ ] Rate limiters testados
- [ ] Headers de segurança validados (securityheaders.com)
- [ ] Penetration test manual: tentar acessar farm_id de outro user
- [ ] Penetration test: tentar publicar lote duas vezes simultâneas
- [ ] Log de tentativas de login falhas configurado
- [ ] Backup automático do PostgreSQL configurado
- [ ] Monitoramento de erros (Sentry) configurado
