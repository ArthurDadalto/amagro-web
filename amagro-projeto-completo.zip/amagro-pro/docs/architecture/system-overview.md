# AMAGRO — Arquitetura do Sistema (MVP)

## 1. Visão de Alto Nível

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENTES                                 │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────────┐    │
│  │ React SPA    │  │ Página Lote  │  │ App Mobile (PWA)   │    │
│  │ Dashboard    │  │ Blade + Cache│  │ futuro             │    │
│  │ Produtor     │  │ QR Code      │  │                    │    │
│  │ (auth)       │  │ (público)    │  │                    │    │
│  └──────┬───────┘  └──────┬───────┘  └────────┬───────────┘    │
│         │                 │                    │                │
└─────────┼─────────────────┼────────────────────┼────────────────┘
          │ HTTPS/JSON      │ HTTPS/HTML         │
          ▼                 ▼                    ▼
┌─────────────────────────────────────────────────────────────────┐
│                     SERVIDOR LARAVEL 11                          │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                     NGINX / Caddy                        │   │
│  │              (reverse proxy + SSL + gzip)                │   │
│  └──────────────────────────┬───────────────────────────────┘   │
│                             │                                   │
│  ┌──────────────────────────▼───────────────────────────────┐   │
│  │                    LARAVEL 11                             │   │
│  │                                                          │   │
│  │  ┌─────────┐ ┌──────────┐ ┌──────────┐ ┌────────────┐   │   │
│  │  │ API     │ │ Auth     │ │ Web      │ │ Middleware  │   │   │
│  │  │ Routes  │ │ Sanctum  │ │ Routes   │ │ CORS, Rate │   │   │
│  │  │ /api/v1 │ │ Tokens   │ │ /lote/   │ │ Tenant     │   │   │
│  │  └────┬────┘ └────┬─────┘ └────┬─────┘ └──────┬─────┘   │   │
│  │       │           │            │               │         │   │
│  │  ┌────▼───────────▼────────────▼───────────────▼─────┐   │   │
│  │  │              SERVICE LAYER                        │   │   │
│  │  │  FarmService, ExpenseService, HarvestService,     │   │   │
│  │  │  LotService, InventoryService, SoilService,       │   │   │
│  │  │  PricingService, WeatherService, IrrigationService│   │   │
│  │  └────────────────────┬──────────────────────────────┘   │   │
│  │                       │                                  │   │
│  │  ┌────────────────────▼──────────────────────────────┐   │   │
│  │  │              ELOQUENT MODELS                      │   │   │
│  │  │  (Global Scope: farm_id tenant isolation)         │   │   │
│  │  └────────────────────┬──────────────────────────────┘   │   │
│  └───────────────────────┼──────────────────────────────────┘   │
│                          │                                      │
│  ┌───────────┐  ┌────────▼─────┐  ┌───────────┐  ┌──────────┐  │
│  │ File      │  │ PostgreSQL   │  │ Redis/    │  │ Queue    │  │
│  │ Storage   │  │              │  │ File Cache│  │ database │  │
│  │ (QR PNGs) │  │ 14 tabelas   │  │           │  │ driver   │  │
│  └───────────┘  └──────────────┘  └───────────┘  └──────────┘  │
└─────────────────────────────────────────────────────────────────┘
          │                                    │
          ▼ EXTERNAL APIs                      ▼ JOBS
  ┌──────────────┐                    ┌──────────────────┐
  │ Open-Meteo   │ clima gratuito     │ FetchWeather     │
  │ Sentinel Hub │ NDVI (futuro)      │ FetchCoffeePrice │
  │ CEPEA/B3     │ cotação café       │ GenerateQrCode   │
  │ Pagar.me     │ pagamentos         │ AlertLowStock    │
  └──────────────┘                    └──────────────────┘
```

## 2. Fluxo de Requisições

### 2.1 Produtor autenticado (React SPA → API)
```
Browser → React SPA (Vite build, served by CDN/Nginx)
  → POST /api/v1/login (Sanctum token)
  → GET /api/v1/farms/{farm}/expenses (Bearer token)
  → Laravel Middleware: auth:sanctum → EnsureFarmAccess → TenantScope
  → Controller → Service → Model (scoped by farm_id) → JSON response
```

### 2.2 Página pública do lote (QR Code scan)
```
Smartphone camera → amagro.com.br/lote/a1b2c3d4
  → Laravel Web Route (não API)
  → LoteController@show (Blade view)
  → Cache::remember("lot:{hash}", 3600, fn() => query)
  → Blade renderiza HTML estático com meta OG tags
  → Tempo alvo: < 300ms (cache hit < 50ms)
```

## 3. Decisões Arquiteturais

| Decisão | Escolha | Alternativa descartada | Motivo |
|---------|---------|----------------------|--------|
| Frontend delivery | SPA separada (Vite build) | Inertia.js / SSR | Desacoplamento total, equipe pode trabalhar em paralelo |
| Auth | Sanctum SPA + token | Passport / JWT | Mais simples, suficiente para SPA + mobile futuro |
| Página pública lote | Blade view com cache | React route | SEO, performance < 300ms, zero JS necessário |
| Multi-tenancy | farm_id scope | Schema separado | Escala para milhares de tenants sem overhead de DDL |
| Valores monetários | Centavos (BIGINT) | DECIMAL(10,2) | Elimina erros de arredondamento, padrão Stripe/Pagar.me |
| File storage | Laravel Storage (local MVP, S3 futuro) | Upload direto S3 | Sem vendor lock-in no MVP |
| Queue driver | database (MVP) | Redis/SQS | Zero dependência extra no MVP |
| Cache driver | file (MVP) | Redis | Zero dependência extra no MVP, Redis quando escalar |

## 4. Segurança

| Camada | Implementação |
|--------|--------------|
| HTTPS | Obrigatório em produção (Caddy auto-SSL ou Nginx + Let's Encrypt) |
| Auth | Sanctum tokens, httpOnly cookies para SPA |
| CORS | Apenas domínio do frontend |
| Rate limiting | 60 req/min autenticado, 30 req/min público |
| Tenant isolation | Global Scope em todos os Models + middleware EnsureFarmAccess |
| Input validation | FormRequest em todo endpoint |
| SQL injection | Eloquent ORM (prepared statements) |
| XSS | React (escape automático) + Blade {{ }} |
| CSRF | Sanctum cookie mode para SPA |
| IDs públicos | Nunca expor auto_increment — hash nanoid nos lotes |

## 5. Estrutura de Pastas — Monorepo

```
amagro/
├── backend/                          # Laravel 11
│   ├── app/
│   │   ├── Http/
│   │   │   ├── Controllers/
│   │   │   │   └── Api/V1/           # Todos os controllers API
│   │   │   ├── Middleware/
│   │   │   │   ├── EnsureFarmAccess.php
│   │   │   │   └── TenantScope.php
│   │   │   └── Requests/             # FormRequests por recurso
│   │   ├── Models/                   # Eloquent models
│   │   ├── Services/                 # Business logic
│   │   ├── Observers/                # Model observers (inventory sync)
│   │   ├── Jobs/                     # Queue jobs
│   │   ├── Scopes/                   # FarmScope global
│   │   └── Enums/                    # PHP enums (Plan, Process, LotStatus)
│   ├── database/
│   │   ├── migrations/
│   │   └── seeders/
│   ├── routes/
│   │   ├── api.php                   # /api/v1/* rotas autenticadas
│   │   └── web.php                   # /lote/{hash} rota pública
│   ├── resources/views/
│   │   └── lots/show.blade.php       # Página pública do lote
│   └── storage/app/qrcodes/          # QR Code PNGs
│
├── frontend/                         # React + Vite
│   ├── src/
│   │   ├── api/                      # API client (axios)
│   │   ├── components/               # Componentes reutilizáveis
│   │   │   ├── ui/                   # Design system (Button, Input, Card...)
│   │   │   ├── layout/               # Sidebar, Header, MobileNav
│   │   │   └── maps/                 # Leaflet wrappers
│   │   ├── features/                 # Módulos por domínio
│   │   │   ├── auth/
│   │   │   ├── dashboard/
│   │   │   ├── farms/
│   │   │   ├── plots/
│   │   │   ├── expenses/
│   │   │   ├── harvests/
│   │   │   ├── inventory/
│   │   │   ├── soil/
│   │   │   ├── lots/
│   │   │   ├── pricing/
│   │   │   ├── irrigation/
│   │   │   └── weather/
│   │   ├── hooks/                    # Custom hooks
│   │   ├── lib/                      # Utils, formatters, constants
│   │   ├── routes/                   # React Router config
│   │   └── stores/                   # Zustand stores
│   ├── index.html
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── docs/                             # Documentação
│   ├── database-architecture.md
│   ├── api-endpoints.md
│   └── deployment.md
│
├── docker-compose.yml                # Dev environment
└── README.md
```

## 6. Plano de Implantação (MVP)

### 6.1 Ambiente de desenvolvimento
```yaml
# docker-compose.yml
services:
  app:        Laravel 11 (PHP 8.3-fpm)
  nginx:      Reverse proxy
  db:         PostgreSQL 16
  frontend:   Node 20 (Vite dev server)
```

### 6.2 Produção — Opções sem vendor lock-in
| Opção | Custo estimado | Prós | Contras |
|-------|---------------|------|---------|
| VPS (Hetzner/DigitalOcean) | ~R$50-100/mês | Controle total, barato | Ops manual |
| Railway/Render | ~R$100-200/mês | Deploy fácil, zero ops | Mais caro ao escalar |
| AWS Lightsail | ~R$80/mês | Previsível, fácil migrar para AWS full | Ecossistema AWS |

### 6.3 Deploy pipeline (MVP)
```
git push → GitHub Actions:
  1. Run tests (PHPUnit + Vitest)
  2. Build frontend (vite build)
  3. Deploy backend (ssh + artisan migrate)
  4. Deploy frontend (copy dist/ to Nginx)
```

## 7. Escalabilidade — Roadmap Técnico

| Fase | Ação |
|------|------|
| MVP (0-500 users) | Single VPS, file cache, database queue |
| Growth (500-5k) | Redis (cache + queue), read replica PG, CDN para assets |
| Scale (5k-50k) | Horizontal scaling (load balancer + N app servers), S3 storage, background workers separados |
| National (50k+) | Kubernetes ou ECS, particionamento de tabelas por ano, API Gateway |
