# AMAGRO — API Endpoints (v1)

## Decisões

- **REST** (não GraphQL) — mais simples, cacheável, equipe pequena
- **Versionamento:** prefixo `/api/v1/`
- **Paginação:** cursor-based (`?cursor=xxx&per_page=20`) para listagens grandes, offset para pequenas
- **Filtros:** query params (`?from=2026-01-01&to=2026-12-31&category_id=3`)
- **Includes:** `?include=plot,farm` para eager loading opcional
- **Rate limit:** 60/min auth, 30/min público

---

## AUTH

| Método | Endpoint | Descrição | Auth |
|--------|----------|-----------|------|
| POST | `/api/v1/register` | Criar conta | ✗ |
| POST | `/api/v1/login` | Login → retorna token Sanctum | ✗ |
| POST | `/api/v1/logout` | Revogar token | ✓ |
| GET | `/api/v1/me` | Dados do user + plano + farms | ✓ |
| PUT | `/api/v1/me` | Atualizar perfil | ✓ |
| POST | `/api/v1/forgot-password` | Enviar email reset | ✗ |
| POST | `/api/v1/reset-password` | Resetar senha | ✗ |

### Request/Response — Login
```
POST /api/v1/login
Body: { "email": "joao@email.com", "password": "..." }

200: {
  "token": "1|abc...",
  "user": {
    "id": 1, "name": "João", "email": "...",
    "plan": "produtor", "plan_expires_at": "2027-04-01T00:00:00Z",
    "farms": [{ "id": 1, "name": "Sítio Boa Vista", "role": "owner" }]
  }
}

422: { "message": "Credenciais inválidas", "code": "INVALID_CREDENTIALS" }
```

---

## FARMS

Base: `/api/v1/farms`

| Método | Endpoint | Descrição | Auth |
|--------|----------|-----------|------|
| GET | `/farms` | Listar farms do user | ✓ |
| POST | `/farms` | Criar farm (checa limite plano) | ✓ |
| GET | `/farms/{farm}` | Detalhes da farm | ✓ farm_access |
| PUT | `/farms/{farm}` | Atualizar farm | ✓ owner/manager |
| DELETE | `/farms/{farm}` | Soft delete farm | ✓ owner |

### Request — Criar Farm
```json
{
  "name": "Sítio Boa Vista",
  "municipality": "Marilândia",
  "state": "ES",
  "altitude_m": 720,
  "latitude": -19.4123456,
  "longitude": -40.5432198,
  "total_area_ha": 15.5
}
```

---

## PLOTS (Talhões)

Base: `/api/v1/farms/{farm}/plots`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/plots` | Listar talhões da farm |
| POST | `/plots` | Criar talhão |
| GET | `/plots/{plot}` | Detalhes + últimas análises de solo |
| PUT | `/plots/{plot}` | Atualizar |
| DELETE | `/plots/{plot}` | Soft delete |

---

## EXPENSES (Gastos)

Base: `/api/v1/farms/{farm}/expenses`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/expenses` | Listar (filtros: from, to, category_id, plot_id) |
| POST | `/expenses` | Registrar gasto |
| GET | `/expenses/{expense}` | Detalhe |
| PUT | `/expenses/{expense}` | Atualizar |
| DELETE | `/expenses/{expense}` | Soft delete |
| GET | `/expenses/summary` | Totais por categoria e período |

### Request — Criar Gasto
```json
{
  "plot_id": null,
  "category_id": 1,
  "description": "20 sacas NPK 20-05-20",
  "amount_cents": 280000,
  "expense_date": "2026-03-15"
}
```

### Response — Summary
```json
{
  "period": { "from": "2026-01-01", "to": "2026-12-31" },
  "total_cents": 4500000,
  "by_category": [
    { "category": "Adubo", "total_cents": 2100000, "pct": 46.7 },
    { "category": "Mão de obra", "total_cents": 1200000, "pct": 26.7 }
  ],
  "by_month": [
    { "month": "2026-01", "total_cents": 350000 },
    { "month": "2026-02", "total_cents": 420000 }
  ]
}
```

---

## EXPENSE CATEGORIES

Base: `/api/v1/farms/{farm}/expense-categories`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/expense-categories` | System + custom da farm |
| POST | `/expense-categories` | Criar categoria custom |
| PUT | `/expense-categories/{cat}` | Editar (somente custom) |
| DELETE | `/expense-categories/{cat}` | Deletar (somente custom, sem gastos vinculados) |

---

## HARVESTS (Colheita)

Base: `/api/v1/farms/{farm}/harvests`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/harvests` | Listar (filtros: from, to, plot_id, variety) |
| POST | `/harvests` | Registrar colheita |
| GET | `/harvests/{harvest}` | Detalhe |
| PUT | `/harvests/{harvest}` | Atualizar |
| DELETE | `/harvests/{harvest}` | Soft delete |
| GET | `/harvests/summary` | Totais por safra, talhão, variedade |

---

## INVENTORY (Estoque)

Base: `/api/v1/farms/{farm}/inventory`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/inventory` | Listar items (filtro: ?low_stock=true) |
| POST | `/inventory` | Criar item |
| GET | `/inventory/{item}` | Detalhe + histórico movements |
| PUT | `/inventory/{item}` | Atualizar (nome, unit, min_qty) |
| DELETE | `/inventory/{item}` | Soft delete |
| POST | `/inventory/{item}/movements` | Registrar entrada ou saída |
| GET | `/inventory/{item}/movements` | Histórico de movimentações |

### Request — Movement
```json
{
  "type": "in",
  "qty": 20,
  "unit_cost_cents": 14000,
  "description": "Compra NPK fornecedor X",
  "movement_date": "2026-03-15"
}
```

---

## SOIL ANALYSES

Base: `/api/v1/farms/{farm}/soil-analyses`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/soil-analyses` | Listar (filtro: plot_id) |
| POST | `/soil-analyses` | Registrar laudo |
| GET | `/soil-analyses/{analysis}` | Detalhe |
| PUT | `/soil-analyses/{analysis}` | Atualizar |
| DELETE | `/soil-analyses/{analysis}` | Soft delete |
| GET | `/soil-analyses/alerts` | Talhões com solo fora do ideal |

---

## LOTS (Rastreabilidade)

Base: `/api/v1/farms/{farm}/lots`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/lots` | Listar (filtro: status, variety) |
| POST | `/lots` | Criar lote (status=draft) |
| GET | `/lots/{lot}` | Detalhe (por ID interno, auth) |
| PUT | `/lots/{lot}` | Atualizar (somente draft) |
| DELETE | `/lots/{lot}` | Soft delete (somente draft) |
| POST | `/lots/{lot}/publish` | Publicar → gera hash + QR Code |
| POST | `/lots/{lot}/unpublish` | Despublicar → mantém hash, remove QR |

### Rota pública (NÃO API — Web route)
| Método | Endpoint | Descrição | Auth |
|--------|----------|-----------|------|
| GET | `/lote/{hash}` | Página pública Blade | ✗ |

### Response — Criar Lote
```json
{
  "id": 42,
  "hash": null,
  "variety": "Catuaí Vermelho",
  "process": "natural",
  "harvest_date": "2026-06-15",
  "bags_60kg": 30,
  "altitude_m": 720,
  "cupping_score": null,
  "sensory_notes": null,
  "status": "draft",
  "qr_code_url": null,
  "plot": { "id": 5, "name": "Talhão 3" },
  "farm": { "name": "Sítio Boa Vista", "municipality": "Marilândia", "state": "ES" }
}
```

### Response — Após Publicar
```json
{
  "id": 42,
  "hash": "a1b2c3d4",
  "status": "published",
  "public_url": "https://amagro.com.br/lote/a1b2c3d4",
  "qr_code_url": "https://amagro.com.br/storage/qrcodes/a1b2c3d4.png",
  "published_at": "2026-04-09T14:30:00Z"
}
```

---

## PRICING (Precificação)

Base: `/api/v1/farms/{farm}/pricing`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/pricing/cost-per-bag` | Custo real por saca (gastos ÷ sacas) com filtro de período |
| GET | `/pricing/quotation` | Cotação CEPEA mais recente (do cache) |
| GET | `/pricing/margin` | Margem por canal (exportador, cafeteria, direto) |

---

## IRRIGATION (Calculadora)

Base: `/api/v1/farms/{farm}/irrigation`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/irrigation/calculate` | Calcula custo (não salva) |
| GET | `/irrigation` | Listar cálculos salvos |
| POST | `/irrigation` | Salvar cálculo |
| DELETE | `/irrigation/{calc}` | Deletar |

### Request — Calcular
```json
{
  "power_cv": 25,
  "hours_per_day": 8,
  "tariff_cents_kwh": 55,
  "is_green_tariff": true
}
```

### Response
```json
{
  "power_cv": 25,
  "power_kw": 18.38,
  "daily_cost_cents": 80872,
  "monthly_cost_cents": 2426160,
  "formula": "18.38 kW × 8h × R$0.55/kWh = R$80.87/dia"
}
```

---

## WEATHER (Clima)

Base: `/api/v1/farms/{farm}/weather`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/weather` | Previsão 7 dias (usa lat/lng da farm, cache 6h) |

---

## DASHBOARD

Base: `/api/v1/farms/{farm}/dashboard`

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/dashboard` | Métricas agregadas |

### Response
```json
{
  "current_season": "2025/2026",
  "total_bags": 450.5,
  "cost_per_bag_cents": 38500,
  "estimated_revenue_cents": 22500000,
  "expense_total_cents": 17342500,
  "profit_margin_pct": 22.9,
  "low_stock_alerts": 3,
  "soil_alerts": 1,
  "lots_published": 8,
  "lots_draft": 2,
  "weather_today": { "temp_max": 28, "temp_min": 16, "rain_mm": 0 }
}
```
