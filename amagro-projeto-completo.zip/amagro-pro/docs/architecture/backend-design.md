# AMAGRO — Design do Backend (Laravel 11)

## 1. Camadas da Aplicação

```
Request → Middleware → Controller → FormRequest → Service → Model → Response
                                                     │
                                                  Observer (side effects)
                                                     │
                                                  Job (async: QR, weather, prices)
```

**Regra:** Controllers são finos. Toda lógica de negócio fica nos Services.
Controllers fazem: validar (FormRequest), chamar Service, retornar Resource.

## 2. Middleware Stack

### EnsureFarmAccess
Verifica se o user autenticado tem acesso à farm_id da rota.
```php
// Rota: /api/v1/farms/{farm}/expenses
// Middleware checa: farm_user pivot existe para auth()->id() + {farm}
```

### SetTenantScope
Após EnsureFarmAccess, injeta o farm_id no contexto para Global Scopes.
```php
app()->instance('current_farm_id', $farm->id);
```

### CheckPlanFeature
Middleware parametrizado que verifica se o plano do user permite a feature.
```php
Route::middleware('plan:especial')->group(fn() => ...); // só plano especial
```

## 3. Enums PHP

```php
enum Plan: string {
    case Free = 'free';
    case Produtor = 'produtor';
    case Especial = 'especial';
}

enum Process: string {
    case Natural = 'natural';
    case Washed = 'washed';
    case Honey = 'honey';
    case Other = 'other';
}

enum LotStatus: string {
    case Draft = 'draft';
    case Published = 'published';
}

enum MovementType: string {
    case In = 'in';
    case Out = 'out';
}

enum FarmRole: string {
    case Owner = 'owner';
    case Manager = 'manager';
    case Viewer = 'viewer';
}
```

## 4. Models — Relacionamentos

### User
```
belongsToMany(Farm::class, 'farm_user')->withPivot('role')
hasMany(Subscription::class) // Cashier
```

### Farm
```
belongsToMany(User::class, 'farm_user')->withPivot('role')
hasMany(Plot::class)
hasMany(Expense::class)
hasMany(Harvest::class)
hasMany(InventoryItem::class)
hasMany(SoilAnalysis::class)
hasMany(Lot::class)
hasMany(IrrigationCalculation::class)
hasMany(ExpenseCategory::class) // custom categories
```

### Plot
```
belongsTo(Farm::class)
hasMany(Harvest::class)
hasMany(SoilAnalysis::class)
hasMany(Lot::class)
hasMany(Expense::class)
```

### Expense
```
belongsTo(Farm::class)
belongsTo(Plot::class) // nullable
belongsTo(ExpenseCategory::class, 'category_id')
```

### Harvest
```
belongsTo(Farm::class)
belongsTo(Plot::class)
```

### InventoryItem
```
belongsTo(Farm::class)
hasMany(InventoryMovement::class)
```

### Lot
```
belongsTo(Farm::class)
belongsTo(Plot::class) // nullable
```

## 5. Global Scope — Tenant Isolation

```php
// app/Scopes/FarmScope.php
class FarmScope implements Scope
{
    public function apply(Builder $builder, Model $model): void
    {
        if ($farmId = app()->bound('current_farm_id') ? app('current_farm_id') : null) {
            $builder->where($model->getTable() . '.farm_id', $farmId);
        }
    }
}
```

Aplicado em: Plot, Expense, Harvest, InventoryItem, InventoryMovement, SoilAnalysis, Lot, IrrigationCalculation, ExpenseCategory (com fallback para farm_id IS NULL nas system categories).

## 6. Services

| Service | Responsabilidades |
|---------|------------------|
| FarmService | CRUD farm, attach/detach users, verificar limites do plano (Free = 1 farm) |
| PlotService | CRUD talhão, validar unicidade nome dentro da farm |
| ExpenseService | CRUD gastos, totais por período/categoria, custo por saca |
| HarvestService | CRUD colheita, total sacas por safra/talhão |
| InventoryService | CRUD items, registrar movement (in/out), recalcular current_qty, alertas |
| SoilService | CRUD análises, alertas (pH, alumínio), histórico por talhão |
| LotService | CRUD lotes, publicar (gerar hash + QR), despublicar, query pública por hash |
| PricingService | Calcular custo/saca, buscar cotação CEPEA, margem por canal |
| WeatherService | Fetch Open-Meteo por lat/lng, cache 6h, retornar forecast 7 dias |
| IrrigationService | Calcular custo irrigação (cv→kW × horas × tarifa), salvar cálculos |
| QrCodeService | Gerar PNG via simple-qrcode, salvar no Storage, retornar path |
| DashboardService | Agregar métricas: sacas total, custo/saca, receita estimada, alertas |

## 7. Jobs (Filas)

| Job | Trigger | Ação |
|-----|---------|------|
| GenerateQrCode | Lot published | Gera PNG, salva path no lot |
| FetchWeatherForecast | Scheduled (6h) | Busca Open-Meteo para farms ativas |
| FetchCoffeePrice | Scheduled (diário) | Scrape/API cotação CEPEA |
| AlertLowStock | Scheduled (diário) | Notifica items abaixo de min_qty |
| CleanWeatherCache | Scheduled (semanal) | Remove forecasts antigos > 30 dias |

## 8. Observers

| Observer | Model | Ação |
|----------|-------|------|
| InventoryMovementObserver | InventoryMovement | created → recalcula current_qty do InventoryItem |
| LotObserver | Lot | updating → se status mudou para published, dispatch GenerateQrCode |

## 9. API Resources (JSON Response Formatting)

Cada model tem um Resource que formata o JSON de saída:
- Nunca expõe `id` interno nos lotes (usa `hash`)
- Converte `amount_cents` → `amount` (float R$) na resposta
- Inclui `links` para navegação HATEOAS-lite
- Suporta `?include=plot,farm` para eager loading condicional

## 10. Error Handling

```php
// Padrão de resposta de erro
{
    "message": "Descrição legível",
    "errors": {                    // Apenas em 422
        "field": ["mensagem"]
    },
    "code": "LOT_ALREADY_PUBLISHED" // Código máquina para o frontend
}
```

| HTTP Code | Quando |
|-----------|--------|
| 401 | Token inválido/expirado |
| 403 | Sem acesso à farm ou feature do plano |
| 404 | Recurso não encontrado (dentro do tenant scope) |
| 422 | Validação falhou |
| 429 | Rate limit excedido |
| 500 | Erro interno (logado, nunca expõe detalhes) |
