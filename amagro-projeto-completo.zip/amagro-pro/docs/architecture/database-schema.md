# AMAGRO — Arquitetura de Banco de Dados

## 1. Decisões Fundamentais

| Decisão | Escolha | Justificativa |
|---------|---------|---------------|
| SGBD | PostgreSQL | JSON nativo, índices parciais, extensões geográficas (PostGIS futuro), melhor para analytics |
| Multi-tenancy | Isolamento por `farm_id` em todas as tabelas de domínio | Simples, funciona com Laravel scopes, escala até milhares de tenants |
| Soft deletes | Sim, em todas as tabelas de domínio | Auditoria, recuperação, integridade referencial |
| UUIDs vs Auto-increment | Auto-increment interno + `hash` público (nanoid 8 chars) nos lotes | Performance em JOINs, segurança na exposição |
| Timestamps | `created_at`, `updated_at` em todas as tabelas | Padrão Laravel |
| Encoding | UTF-8 (utf8mb4 se MySQL) | Suporte a acentos e emojis |

## 2. Diagrama de Relacionamentos (ER)

```
users (1)──────(N) farm_user (N)──────(1) farms
                                          │
                    ┌─────────┬───────────┼───────────┬──────────┐
                    │         │           │           │          │
                 plots    expenses    harvests    inventory   lots
                    │         │           │         items       │
                    │         │           │           │         │
              soil_analyses   │           │      inventory     lot_items
                              │           │      movements
                              │           │
                         expense_      harvest_
                         categories    (belongs to plot)
```

## 3. Tabelas — Definição Completa

---

### 3.1 `users`
Usuário da plataforma. Pode ter múltiplas fazendas.

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| name | VARCHAR(255) | NOT NULL | |
| email | VARCHAR(255) | UNIQUE, NOT NULL | Login |
| email_verified_at | TIMESTAMP | NULLABLE | |
| password | VARCHAR(255) | NOT NULL | bcrypt |
| phone | VARCHAR(20) | NULLABLE | Contato / WhatsApp |
| plan | ENUM('free','produtor','especial') | DEFAULT 'free' | Plano ativo |
| plan_expires_at | TIMESTAMP | NULLABLE | NULL = free forever |
| remember_token | VARCHAR(100) | NULLABLE | Laravel |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |
| deleted_at | TIMESTAMP | NULLABLE | Soft delete |

**Índices:** `email` (unique), `plan`

---

### 3.2 `farms`
Fazenda / propriedade rural.

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| name | VARCHAR(255) | NOT NULL | Nome da fazenda |
| municipality | VARCHAR(255) | NOT NULL | Município |
| state | CHAR(2) | NOT NULL | UF |
| altitude_m | SMALLINT | NULLABLE | Altitude em metros |
| latitude | DECIMAL(10,7) | NULLABLE | Para clima e mapa |
| longitude | DECIMAL(10,7) | NULLABLE | |
| total_area_ha | DECIMAL(10,2) | NULLABLE | Área total hectares |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |
| deleted_at | TIMESTAMP | NULLABLE | |

**Índices:** `state`, `(latitude, longitude)`

---

### 3.3 `farm_user` (pivot)
Relacionamento N:N entre users e farms. Suporta multi-fazenda e multi-usuário por fazenda.

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| farm_id | BIGINT FK | NOT NULL → farms.id | |
| user_id | BIGINT FK | NOT NULL → users.id | |
| role | ENUM('owner','manager','viewer') | DEFAULT 'owner' | Papel do usuário na fazenda |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |

**Índices:** `(farm_id, user_id)` UNIQUE, `user_id`

---

### 3.4 `plots` (talhões)
Subdivisão da fazenda onde o café é plantado.

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| farm_id | BIGINT FK | NOT NULL → farms.id | **Tenant key** |
| name | VARCHAR(255) | NOT NULL | Ex: "Talhão 3 - Encosta" |
| variety | VARCHAR(100) | NOT NULL | Ex: "Catuaí Vermelho", "Bourbon Amarelo" |
| area_ha | DECIMAL(8,2) | NOT NULL | Área em hectares |
| plant_count | INT | NULLABLE | Nº de pés de café |
| planted_at | DATE | NULLABLE | Data do plantio |
| altitude_m | SMALLINT | NULLABLE | Altitude específica do talhão |
| latitude | DECIMAL(10,7) | NULLABLE | Centro do talhão |
| longitude | DECIMAL(10,7) | NULLABLE | |
| notes | TEXT | NULLABLE | |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |
| deleted_at | TIMESTAMP | NULLABLE | |

**Índices:** `farm_id`, `variety`, `(farm_id, name)` UNIQUE

---

### 3.5 `expense_categories`
Categorias de gastos (seed data + customizáveis por fazenda).

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| farm_id | BIGINT FK | NULLABLE → farms.id | NULL = categoria global/seed |
| name | VARCHAR(100) | NOT NULL | Ex: "Adubo", "Mão de obra" |
| icon | VARCHAR(50) | NULLABLE | Ícone no frontend |
| is_system | BOOLEAN | DEFAULT false | true = não editável |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |

**Índices:** `farm_id`, `(farm_id, name)` UNIQUE

**Seed data (is_system=true, farm_id=NULL):** Adubo, Mão de obra, Defensivos, Irrigação, Combustível, Manutenção, Frete, Outros

---

### 3.6 `expenses`
Gastos registrados pelo produtor.

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| farm_id | BIGINT FK | NOT NULL → farms.id | **Tenant key** |
| plot_id | BIGINT FK | NULLABLE → plots.id | NULL = gasto geral da fazenda |
| category_id | BIGINT FK | NOT NULL → expense_categories.id | |
| description | VARCHAR(500) | NULLABLE | |
| amount_cents | BIGINT | NOT NULL | Valor em centavos (evita float) |
| expense_date | DATE | NOT NULL | Data do gasto |
| receipt_path | VARCHAR(500) | NULLABLE | Caminho do comprovante no storage |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |
| deleted_at | TIMESTAMP | NULLABLE | |

**Índices:** `farm_id`, `(farm_id, expense_date)`, `category_id`, `plot_id`

---

### 3.7 `harvests`
Registro de colheita por talhão.

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| farm_id | BIGINT FK | NOT NULL → farms.id | **Tenant key** |
| plot_id | BIGINT FK | NOT NULL → plots.id | |
| harvest_date | DATE | NOT NULL | |
| bags_60kg | DECIMAL(8,1) | NOT NULL | Sacas de 60kg |
| variety | VARCHAR(100) | NOT NULL | Redundante p/ snapshot histórico |
| process | ENUM('natural','washed','honey','other') | NOT NULL | Beneficiamento |
| notes | TEXT | NULLABLE | |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |
| deleted_at | TIMESTAMP | NULLABLE | |

**Índices:** `farm_id`, `(farm_id, harvest_date)`, `plot_id`

---

### 3.8 `inventory_items`
Insumos em estoque (adubo, defensivos, etc).

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| farm_id | BIGINT FK | NOT NULL → farms.id | **Tenant key** |
| name | VARCHAR(255) | NOT NULL | Ex: "NPK 20-05-20" |
| unit | VARCHAR(20) | NOT NULL | "kg", "L", "un" |
| current_qty | DECIMAL(12,2) | NOT NULL DEFAULT 0 | Quantidade atual |
| min_qty | DECIMAL(12,2) | NULLABLE | Alerta de nível baixo |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |
| deleted_at | TIMESTAMP | NULLABLE | |

**Índices:** `farm_id`, `(farm_id, name)` UNIQUE

---

### 3.9 `inventory_movements`
Entradas e saídas do estoque (log imutável).

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| inventory_item_id | BIGINT FK | NOT NULL → inventory_items.id | |
| farm_id | BIGINT FK | NOT NULL → farms.id | **Tenant key** (redundante p/ query) |
| type | ENUM('in','out') | NOT NULL | Entrada ou saída |
| qty | DECIMAL(12,2) | NOT NULL | Sempre positivo |
| unit_cost_cents | BIGINT | NULLABLE | Custo unitário na entrada |
| description | VARCHAR(500) | NULLABLE | |
| movement_date | DATE | NOT NULL | |
| created_at | TIMESTAMP | | |

**Índices:** `inventory_item_id`, `farm_id`, `(farm_id, movement_date)`

**Nota:** `inventory_movements` NÃO tem soft delete — é log de auditoria. `current_qty` em `inventory_items` é atualizado via trigger ou service.

---

### 3.10 `soil_analyses`
Análise de solo por talhão (inserção manual do laudo no MVP).

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| farm_id | BIGINT FK | NOT NULL → farms.id | **Tenant key** |
| plot_id | BIGINT FK | NOT NULL → plots.id | |
| analysis_date | DATE | NOT NULL | Data do laudo |
| ph | DECIMAL(3,1) | NULLABLE | 0.0–14.0 |
| clay_pct | DECIMAL(4,1) | NULLABLE | % argila |
| p_mg_dm3 | DECIMAL(6,1) | NULLABLE | Fósforo (mg/dm³) |
| k_mg_dm3 | DECIMAL(6,1) | NULLABLE | Potássio |
| ca_cmol | DECIMAL(5,2) | NULLABLE | Cálcio (cmolc/dm³) |
| mg_cmol | DECIMAL(5,2) | NULLABLE | Magnésio |
| al_cmol | DECIMAL(5,2) | NULLABLE | Alumínio |
| organic_matter_pct | DECIMAL(4,1) | NULLABLE | Matéria orgânica % |
| base_saturation_pct | DECIMAL(4,1) | NULLABLE | Saturação de bases V% |
| notes | TEXT | NULLABLE | Obs do laudo |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |
| deleted_at | TIMESTAMP | NULLABLE | |

**Índices:** `farm_id`, `plot_id`, `(plot_id, analysis_date)`

---

### 3.11 `lots`
Lote de café para rastreabilidade. Core do diferencial estratégico.

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | Nunca exposto publicamente |
| farm_id | BIGINT FK | NOT NULL → farms.id | **Tenant key** |
| hash | CHAR(8) | UNIQUE, NOT NULL | nanoid 8 chars — URL pública |
| plot_id | BIGINT FK | NULLABLE → plots.id | |
| variety | VARCHAR(100) | NOT NULL | Snapshot |
| process | ENUM('natural','washed','honey','other') | NOT NULL | |
| harvest_date | DATE | NOT NULL | |
| bags_60kg | DECIMAL(8,1) | NOT NULL | |
| altitude_m | SMALLINT | NULLABLE | |
| cupping_score | DECIMAL(3,1) | NULLABLE | Pontuação sensorial 0–100 |
| sensory_notes | VARCHAR(500) | NULLABLE | "Chocolate, frutas vermelhas" |
| status | ENUM('draft','published') | DEFAULT 'draft' | QR só no published |
| qr_code_path | VARCHAR(500) | NULLABLE | Caminho do PNG no storage |
| published_at | TIMESTAMP | NULLABLE | |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |
| deleted_at | TIMESTAMP | NULLABLE | |

**Índices:** `hash` (unique), `farm_id`, `status`, `(farm_id, status)`

---

### 3.12 `coffee_prices`
Cache de cotações do café (CEPEA/B3).

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| source | VARCHAR(50) | NOT NULL | 'cepea', 'b3' |
| type | VARCHAR(50) | NOT NULL | 'arabica', 'robusta' |
| price_cents | BIGINT | NOT NULL | Preço por saca em centavos |
| reference_date | DATE | NOT NULL | |
| fetched_at | TIMESTAMP | NOT NULL | Quando foi buscado |
| created_at | TIMESTAMP | | |

**Índices:** `(source, type, reference_date)` UNIQUE

---

### 3.13 `weather_cache`
Cache de previsão do tempo por coordenada (Open-Meteo).

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| latitude | DECIMAL(10,7) | NOT NULL | Arredondado p/ 2 casas no lookup |
| longitude | DECIMAL(10,7) | NOT NULL | |
| forecast_date | DATE | NOT NULL | |
| data | JSON | NOT NULL | Payload completo da API |
| fetched_at | TIMESTAMP | NOT NULL | TTL: 6h |
| created_at | TIMESTAMP | | |

**Índices:** `(latitude, longitude, forecast_date)` UNIQUE

---

### 3.14 `irrigation_calculations`
Cálculos de custo de irrigação salvos.

| Coluna | Tipo | Restrição | Notas |
|--------|------|-----------|-------|
| id | BIGINT PK | auto_increment | |
| farm_id | BIGINT FK | NOT NULL → farms.id | **Tenant key** |
| name | VARCHAR(255) | NULLABLE | "Pivô talhão 3" |
| power_cv | DECIMAL(8,2) | NOT NULL | Potência em cv |
| power_kw | DECIMAL(8,2) | NOT NULL | Calculado: cv × 0.735 |
| hours_per_day | DECIMAL(4,1) | NOT NULL | |
| tariff_cents_kwh | INT | NOT NULL | Tarifa em centavos/kWh |
| is_green_tariff | BOOLEAN | DEFAULT false | Horário verde noturno |
| daily_cost_cents | BIGINT | NOT NULL | Calculado |
| monthly_cost_cents | BIGINT | NOT NULL | Calculado (× 30) |
| season_cost_cents | BIGINT | NULLABLE | Se informado período |
| created_at | TIMESTAMP | | |
| updated_at | TIMESTAMP | | |

**Índices:** `farm_id`

---

### 3.15 `subscriptions` (Laravel Cashier)
Gerenciada automaticamente pelo Laravel Cashier + Pagar.me. Não definimos colunas — o Cashier cria via migration própria.

---

## 4. Regras de Integridade

1. **Isolamento multi-tenant**: Todo SELECT/UPDATE/DELETE em tabelas de domínio DEVE incluir `WHERE farm_id = ?`. Implementado via Laravel Global Scope no Model.
2. **Valores monetários**: Sempre em centavos (BIGINT). Nunca float/double. Conversão para R$ apenas no frontend.
3. **Soft deletes**: Todas as tabelas de domínio (exceto `inventory_movements` e caches). Índices devem considerar `deleted_at IS NULL`.
4. **Hash do lote**: Gerado com nanoid(8) no momento da criação. Verificação de unicidade com retry (colisão improvável mas possível).
5. **QR Code**: Gerado apenas quando `status` muda de `draft` para `published`. Armazenado como PNG no Laravel Storage.
6. **Estoque**: `current_qty` é sempre recalculado a partir dos `inventory_movements` (SUM entradas - SUM saídas). O campo é cache desnormalizado atualizado via Observer/Service.

## 5. Padrões de Consulta Frequentes

```sql
-- Dashboard: total de sacas por safra
SELECT SUM(bags_60kg), EXTRACT(YEAR FROM harvest_date) as year
FROM harvests
WHERE farm_id = ? AND deleted_at IS NULL
GROUP BY year ORDER BY year DESC;

-- Custo por saca
SELECT SUM(e.amount_cents) / NULLIF(SUM(h.bags_60kg), 0) as cost_per_bag
FROM expenses e
JOIN harvests h ON h.farm_id = e.farm_id
  AND EXTRACT(YEAR FROM h.harvest_date) = EXTRACT(YEAR FROM e.expense_date)
WHERE e.farm_id = ? AND e.deleted_at IS NULL AND h.deleted_at IS NULL;

-- Lote público (página QR Code) — query mais crítica em performance
SELECT l.*, f.name as farm_name, f.municipality, f.state, f.altitude_m,
       p.name as plot_name, p.variety as plot_variety
FROM lots l
JOIN farms f ON f.id = l.farm_id
LEFT JOIN plots p ON p.id = l.plot_id
WHERE l.hash = ? AND l.status = 'published' AND l.deleted_at IS NULL;

-- Alertas de estoque baixo
SELECT * FROM inventory_items
WHERE farm_id = ? AND min_qty IS NOT NULL AND current_qty <= min_qty
AND deleted_at IS NULL;

-- Alertas de solo (pH fora do ideal para café: 6.0–6.5)
SELECT sa.*, p.name as plot_name
FROM soil_analyses sa
JOIN plots p ON p.id = sa.plot_id
WHERE sa.farm_id = ? AND sa.deleted_at IS NULL
AND (sa.ph < 5.5 OR sa.ph > 7.0 OR sa.al_cmol > 0.5)
ORDER BY sa.analysis_date DESC;
```

## 6. Estratégia de Índices

| Índice | Tipo | Justificativa |
|--------|------|---------------|
| `lots.hash` | UNIQUE B-tree | Lookup O(1) na página pública — query mais quente |
| `expenses(farm_id, expense_date)` | Composto B-tree | Range scan por período no dashboard |
| `harvests(farm_id, harvest_date)` | Composto B-tree | Idem |
| `farm_user(farm_id, user_id)` | UNIQUE composto | Evita duplicata + lookup bidirecional |
| `plots(farm_id, name)` | UNIQUE composto | Sem talhão duplicado na fazenda |
| Todos `farm_id` FK | B-tree | Filtro tenant em toda query |

## 7. Escalabilidade

| Fase | Produtores | Estratégia |
|------|-----------|------------|
| MVP | 0–500 | PostgreSQL single instance, file cache, database queue |
| Crescimento | 500–5.000 | Redis cache + queue, read replica PostgreSQL |
| Escala | 5.000–50.000 | Particionamento de `expenses` e `harvests` por ano, connection pooling (PgBouncer) |
| Nacional | 50.000+ | Sharding por região ou migração para multi-database por tenant group |

## 8. Migrations Laravel — Ordem de Execução

1. `create_users_table` (Laravel default + campos extras)
2. `create_farms_table`
3. `create_farm_user_table`
4. `create_plots_table`
5. `create_expense_categories_table` + seeder
6. `create_expenses_table`
7. `create_harvests_table`
8. `create_inventory_items_table`
9. `create_inventory_movements_table`
10. `create_soil_analyses_table`
11. `create_lots_table`
12. `create_coffee_prices_table`
13. `create_weather_cache_table`
14. `create_irrigation_calculations_table`
