# AMAGRO — Setup Local

## Pré-requisitos

- PHP 8.2+ (ou Laragon)
- Composer
- Node.js 20+
- MySQL ou PostgreSQL
- Git

## Passo 1 — Clonar

```bash
git clone https://github.com/ArthurDadalto/amagro-web.git amagro
cd amagro
```

## Passo 2 — Backend

```bash
cd apps/api

# Se a pasta estiver vazia (só os arquivos do AMAGRO):
composer create-project laravel/laravel temp
# Copiar os arquivos padrão do Laravel (artisan, config/, etc.)
# Depois mover os arquivos AMAGRO de volta
# OU usar o setup.sh

composer install
composer require laravel/sanctum simplesoftwareio/simple-qrcode

cp ../../infra/.env.example .env
php artisan key:generate
```

### Criar o banco

**Laragon (MySQL):**
- Abrir HeidiSQL → criar schema `amagro`
- O .env já vem configurado para MySQL local

**PostgreSQL:**
```bash
createdb amagro
# Ajustar DB_CONNECTION=pgsql no .env
```

### Rodar migrations

```bash
php artisan migrate
php artisan db:seed --class=ExpenseCategorySeeder
php artisan serve
```

Testar: `http://localhost:8000/health`

## Passo 3 — Frontend

```bash
cd apps/web
npm install
npm run dev
```

Abrir: `http://localhost:5173`

## Passo 4 — Verificar

| URL | O que deve aparecer |
|-----|-------------------|
| `localhost:5173` | Landing page AMAGRO (verde escuro + dourado) |
| `localhost:5173/login` | Tela de login |
| `localhost:5173/dashboard` | Dashboard com KPIs |
| `localhost:8000/health` | `{"status":"ok"}` |
| `localhost:8000/api/v1/register` (POST) | Token + user |

## Estrutura no VS Code

Abra a pasta raiz `amagro/` no VS Code.  
Você verá `apps/`, `docs/`, `infra/`, `packages/` no Explorer.

**Dica:** Instale a extensão "Monorepo Workspace" para navegação rápida.
