# AMAGRO

> Gestão inteligente para produtores de café — Arábica e Conilon

SaaS voltado para cafeicultores do Espírito Santo e sul da Bahia.  
Controle financeiro, rastreabilidade por QR Code e inteligência de mercado.

## Stack

| Camada | Tecnologia |
|--------|-----------|
| API | Laravel 11 · PHP 8.2+ · PostgreSQL/MySQL |
| Web | React 19 · Vite · Tailwind CSS |
| Auth | Laravel Sanctum |
| Queue | Laravel Queue (database → Redis) |
| Cache | File (MVP) → Redis |

## Estrutura

```
apps/api     → Backend Laravel (API REST)
apps/web     → Frontend React (SPA)
packages/    → Código compartilhado
docs/        → Documentação técnica
infra/       → Docker, scripts, CI/CD
```

## Quick Start

```bash
# 1. Backend
cd apps/api
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
php artisan serve

# 2. Frontend (outro terminal)
cd apps/web
npm install
npm run dev
```

Abrir **http://localhost:5173**

## Documentação

- [Setup completo](docs/guides/setup.md)
- [Arquitetura do sistema](docs/architecture/system-overview.md)
- [Schema do banco](docs/architecture/database-schema.md)
- [API Endpoints](docs/architecture/api-endpoints.md)
- [Auditoria de segurança](docs/security/audit-report.md)

## Time

- **Arthur Miguel** — Idealizador & Frontend
- **Primo** — Backend & Infra

---

© 2026 AMAGRO. Todos os direitos reservados.
