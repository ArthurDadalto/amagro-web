export const EXPENSE_CATEGORIES = [
  { name: 'Adubo',       icon: 'leaf' },
  { name: 'Mão de obra', icon: 'users' },
  { name: 'Defensivos',  icon: 'shield' },
  { name: 'Irrigação',   icon: 'droplets' },
  { name: 'Combustível', icon: 'fuel' },
  { name: 'Manutenção',  icon: 'wrench' },
  { name: 'Frete',       icon: 'truck' },
  { name: 'Outros',      icon: 'ellipsis' },
];
