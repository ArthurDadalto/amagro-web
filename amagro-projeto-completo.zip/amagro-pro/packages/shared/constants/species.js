export const SPECIES = {
  arabica: { value: 'arabica', label: 'Arábica' },
  conilon: { value: 'conilon', label: 'Conilon' },
};
