export const PLANS = {
  produtor: {
    name: 'Produtor',
    price_cents: 4900,
    trial_days: 30,
    features: ['farms', 'plots', 'expenses', 'harvests', 'inventory', 'soil', 'weather', 'irrigation', 'pricing'],
  },
  especial: {
    name: 'Especial',
    price_cents: 12000,
    trial_days: 0,
    features: ['lots', 'qrcode', 'ndvi', 'vitrine', 'ai_assistant'],
  },
};
