export const PROCESSES = {
  natural: { value: 'natural', label: 'Natural (seco)' },
  washed:  { value: 'washed',  label: 'Lavado' },
  honey:   { value: 'honey',   label: 'Honey (cereja descascado)' },
  other:   { value: 'other',   label: 'Outro' },
};
