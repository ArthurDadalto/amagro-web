<?php

use App\Http\Controllers\PublicLotController;
use Illuminate\Support\Facades\Route;

// Public lot page (QR Code scan)
Route::get('/lote/{hash}', [PublicLotController::class, 'show'])
    ->middleware('throttle:public-lot')
    ->name('lot.public');

// Health check
Route::get('/health', fn () => response()->json(['status' => 'ok', 'time' => now()->toIso8601String()]));
