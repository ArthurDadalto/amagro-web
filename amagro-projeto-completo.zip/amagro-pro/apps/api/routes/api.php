<?php

use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\DashboardController;
use App\Http\Controllers\Api\V1\ExpenseController;
use App\Http\Controllers\Api\V1\FarmController;
use App\Http\Controllers\Api\V1\HarvestController;
use App\Http\Controllers\Api\V1\InventoryController;
use App\Http\Controllers\Api\V1\IrrigationController;
use App\Http\Controllers\Api\V1\LotController;
use App\Http\Controllers\Api\V1\PlotController;
use App\Http\Controllers\Api\V1\SoilAnalysisController;
use Illuminate\Support\Facades\Route;

// ── Public (no auth) ──────────────────────────────────────

Route::prefix('v1')->group(function () {
    Route::post('register', [AuthController::class, 'register'])->middleware('throttle:register');
    Route::post('login', [AuthController::class, 'login'])->middleware('throttle:login');
});

// ── Authenticated ─────────────────────────────────────────

Route::prefix('v1')->middleware('auth:sanctum')->group(function () {
    // Auth
    Route::post('logout', [AuthController::class, 'logout']);
    Route::get('me', [AuthController::class, 'me']);
    Route::put('me', [AuthController::class, 'updateProfile']);

    // Farms (user-level, no farm scope)
    Route::apiResource('farms', FarmController::class)->except(['show', 'update', 'destroy']);

    // ── Farm-scoped routes (tenant isolation) ─────────────
    Route::prefix('farms/{farm}')
        ->middleware('farm.access')
        ->group(function () {
            // Farm CRUD (show/update/delete)
            Route::get('/', [FarmController::class, 'show']);
            Route::put('/', [FarmController::class, 'update']);
            Route::delete('/', [FarmController::class, 'destroy']);

            // Dashboard
            Route::get('dashboard', [DashboardController::class, 'index']);

            // Plots
            Route::apiResource('plots', PlotController::class);

            // Expenses
            Route::get('expenses/summary', [ExpenseController::class, 'summary']);
            Route::apiResource('expenses', ExpenseController::class);

            // Expense Categories
            Route::get('expense-categories', function () {
                $cats = \App\Models\ExpenseCategory::forFarm(app('current_farm_id'))->get();
                return response()->json(['data' => $cats]);
            });

            // Harvests
            Route::get('harvests/summary', [HarvestController::class, 'summary']);
            Route::apiResource('harvests', HarvestController::class);

            // Inventory
            Route::post('inventory/{item}/movements', [InventoryController::class, 'addMovement']);
            Route::get('inventory/{item}/movements', [InventoryController::class, 'movements']);
            Route::apiResource('inventory', InventoryController::class)->parameters(['inventory' => 'item']);

            // Soil Analyses
            Route::get('soil-analyses/alerts', [SoilAnalysisController::class, 'alerts']);
            Route::apiResource('soil-analyses', SoilAnalysisController::class);

            // Lots (Traceability)
            Route::post('lots/{lot}/publish', [LotController::class, 'publish']);
            Route::post('lots/{lot}/unpublish', [LotController::class, 'unpublish']);
            Route::apiResource('lots', LotController::class);

            // Irrigation Calculator
            Route::post('irrigation/calculate', [IrrigationController::class, 'calculate']);
            Route::get('irrigation', [IrrigationController::class, 'index']);
            Route::post('irrigation', [IrrigationController::class, 'store']);
            Route::delete('irrigation/{id}', [IrrigationController::class, 'destroy']);
        });
});
