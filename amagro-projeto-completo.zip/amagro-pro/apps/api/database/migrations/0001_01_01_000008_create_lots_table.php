<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('farm_id')->constrained()->cascadeOnDelete();
            $table->char('hash', 8)->unique();
            $table->foreignId('plot_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('species', ['arabica', 'conilon'])->default('arabica');
            $table->string('variety', 100);
            $table->enum('process', ['natural', 'washed', 'honey', 'other']);
            $table->date('harvest_date');
            $table->decimal('bags_60kg', 8, 1);
            $table->smallInteger('altitude_m')->nullable();
            $table->decimal('cupping_score', 3, 1)->nullable();
            $table->string('sensory_notes', 500)->nullable();
            $table->enum('status', ['draft', 'published'])->default('draft');
            $table->string('qr_code_path', 500)->nullable();
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('farm_id');
            $table->index('status');
            $table->index(['farm_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lots');
    }
};
