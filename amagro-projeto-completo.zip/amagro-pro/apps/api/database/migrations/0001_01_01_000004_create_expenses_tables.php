<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('expense_categories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('farm_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('name', 100);
            $table->string('icon', 50)->nullable();
            $table->boolean('is_system')->default(false);
            $table->timestamps();

            $table->unique(['farm_id', 'name']);
            $table->index('farm_id');
        });

        Schema::create('expenses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('farm_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plot_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('category_id')->constrained('expense_categories');
            $table->string('description', 500)->nullable();
            $table->bigInteger('amount_cents');
            $table->date('expense_date');
            $table->string('receipt_path', 500)->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('farm_id');
            $table->index(['farm_id', 'expense_date']);
            $table->index('category_id');
            $table->index('plot_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('expenses');
        Schema::dropIfExists('expense_categories');
    }
};
