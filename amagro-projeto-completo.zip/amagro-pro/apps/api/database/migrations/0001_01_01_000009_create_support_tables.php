<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('coffee_prices', function (Blueprint $table) {
            $table->id();
            $table->string('source', 50);
            $table->string('type', 50);
            $table->bigInteger('price_cents');
            $table->date('reference_date');
            $table->timestamp('fetched_at');
            $table->timestamp('created_at')->useCurrent();

            $table->unique(['source', 'type', 'reference_date']);
        });

        Schema::create('weather_cache', function (Blueprint $table) {
            $table->id();
            $table->decimal('latitude', 10, 7);
            $table->decimal('longitude', 10, 7);
            $table->date('forecast_date');
            $table->json('data');
            $table->timestamp('fetched_at');
            $table->timestamp('created_at')->useCurrent();

            $table->unique(['latitude', 'longitude', 'forecast_date']);
        });

        Schema::create('irrigation_calculations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('farm_id')->constrained()->cascadeOnDelete();
            $table->string('name')->nullable();
            $table->decimal('power_cv', 8, 2);
            $table->decimal('power_kw', 8, 2);
            $table->decimal('hours_per_day', 4, 1);
            $table->integer('tariff_cents_kwh');
            $table->boolean('is_green_tariff')->default(false);
            $table->bigInteger('daily_cost_cents');
            $table->bigInteger('monthly_cost_cents');
            $table->bigInteger('season_cost_cents')->nullable();
            $table->timestamps();

            $table->index('farm_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('irrigation_calculations');
        Schema::dropIfExists('weather_cache');
        Schema::dropIfExists('coffee_prices');
    }
};
