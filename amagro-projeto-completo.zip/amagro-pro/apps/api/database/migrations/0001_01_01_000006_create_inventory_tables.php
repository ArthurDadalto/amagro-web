<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('inventory_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('farm_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('unit', 20);
            $table->decimal('current_qty', 12, 2)->default(0);
            $table->decimal('min_qty', 12, 2)->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('farm_id');
            $table->unique(['farm_id', 'name']);
        });

        Schema::create('inventory_movements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('inventory_item_id')->constrained()->cascadeOnDelete();
            $table->foreignId('farm_id')->constrained()->cascadeOnDelete();
            $table->enum('type', ['in', 'out']);
            $table->decimal('qty', 12, 2);
            $table->bigInteger('unit_cost_cents')->nullable();
            $table->string('description', 500)->nullable();
            $table->date('movement_date');
            $table->timestamp('created_at')->useCurrent();

            $table->index('inventory_item_id');
            $table->index('farm_id');
            $table->index(['farm_id', 'movement_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('inventory_movements');
        Schema::dropIfExists('inventory_items');
    }
};
