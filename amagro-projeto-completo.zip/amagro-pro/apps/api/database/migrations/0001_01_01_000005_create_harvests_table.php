<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('harvests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('farm_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plot_id')->constrained()->cascadeOnDelete();
            $table->date('harvest_date');
            $table->decimal('bags_60kg', 8, 1);
            $table->enum('species', ['arabica', 'conilon'])->default('arabica');
            $table->string('variety', 100);
            $table->enum('process', ['natural', 'washed', 'honey', 'other']);
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('farm_id');
            $table->index(['farm_id', 'harvest_date']);
            $table->index('plot_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('harvests');
    }
};
