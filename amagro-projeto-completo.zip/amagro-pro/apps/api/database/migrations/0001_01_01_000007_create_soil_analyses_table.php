<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('soil_analyses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('farm_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plot_id')->constrained()->cascadeOnDelete();
            $table->date('analysis_date');
            $table->decimal('ph', 3, 1)->nullable();
            $table->decimal('clay_pct', 4, 1)->nullable();
            $table->decimal('p_mg_dm3', 6, 1)->nullable();
            $table->decimal('k_mg_dm3', 6, 1)->nullable();
            $table->decimal('ca_cmol', 5, 2)->nullable();
            $table->decimal('mg_cmol', 5, 2)->nullable();
            $table->decimal('al_cmol', 5, 2)->nullable();
            $table->decimal('organic_matter_pct', 4, 1)->nullable();
            $table->decimal('base_saturation_pct', 4, 1)->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('farm_id');
            $table->index('plot_id');
            $table->index(['plot_id', 'analysis_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('soil_analyses');
    }
};
