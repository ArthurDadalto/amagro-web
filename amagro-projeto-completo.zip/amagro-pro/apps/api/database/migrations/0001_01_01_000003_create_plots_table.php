<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('plots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('farm_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->enum('species', ['arabica', 'conilon'])->default('arabica');
            $table->string('variety', 100); // Ex: Catuaí, Robustão, Vitória
            $table->decimal('area_ha', 8, 2);
            $table->unsignedInteger('plant_count')->nullable();
            $table->date('planted_at')->nullable();
            $table->smallInteger('altitude_m')->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('farm_id');
            $table->unique(['farm_id', 'name']);
            $table->index('variety');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('plots');
    }
};
