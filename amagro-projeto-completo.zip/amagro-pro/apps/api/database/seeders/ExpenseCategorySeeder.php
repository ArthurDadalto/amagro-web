<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class ExpenseCategorySeeder extends Seeder
{
    public function run(): void
    {
        $now = Carbon::now();

        $categories = [
            ['name' => 'Adubo',       'icon' => 'leaf'],
            ['name' => 'Mão de obra', 'icon' => 'users'],
            ['name' => 'Defensivos',  'icon' => 'shield'],
            ['name' => 'Irrigação',   'icon' => 'droplets'],
            ['name' => 'Combustível', 'icon' => 'fuel'],
            ['name' => 'Manutenção',  'icon' => 'wrench'],
            ['name' => 'Frete',       'icon' => 'truck'],
            ['name' => 'Outros',      'icon' => 'ellipsis'],
        ];

        foreach ($categories as $cat) {
            DB::table('expense_categories')->updateOrInsert(
                ['farm_id' => null, 'name' => $cat['name']],
                [
                    'icon'       => $cat['icon'],
                    'is_system'  => true,
                    'created_at' => $now,
                    'updated_at' => $now,
                ],
            );
        }
    }
}
