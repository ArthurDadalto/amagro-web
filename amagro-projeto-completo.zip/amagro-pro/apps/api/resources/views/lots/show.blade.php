<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $lot['variety'] }} — {{ $lot['farm_name'] }} | AMAGRO</title>

    {{-- OG Meta for sharing --}}
    <meta property="og:title" content="{{ $lot['variety'] }} — {{ $lot['farm_name'] }}">
    <meta property="og:description" content="Café {{ $lot['process_label'] }} • {{ $lot['municipality'] }}/{{ $lot['state'] }} • Colheita {{ $lot['harvest_date'] }}{{ $lot['cupping_score'] ? ' • Nota '.$lot['cupping_score'] : '' }}">
    <meta property="og:type" content="product">
    <meta property="og:url" content="{{ url("/lote/{$lot['hash']}") }}">
    <meta name="twitter:card" content="summary">

    {{-- Minimal inline CSS for < 300ms load --}}
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f0fdf4;
            color: #14532d;
            min-height: 100vh;
            padding: 0;
        }
        .header {
            background: #166534;
            color: white;
            padding: 1.5rem 1rem;
            text-align: center;
        }
        .header h1 { font-size: 1.1rem; font-weight: 600; opacity: 0.9; }
        .header .logo { font-size: 1.5rem; font-weight: 800; letter-spacing: 0.05em; }
        .card {
            max-width: 480px;
            margin: -1.5rem auto 2rem;
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        .hero {
            background: linear-gradient(135deg, #15803d, #166534);
            color: white;
            padding: 2rem 1.5rem;
            text-align: center;
        }
        .hero .variety { font-size: 1.5rem; font-weight: 700; margin-bottom: 0.25rem; }
        .hero .process { font-size: 0.95rem; opacity: 0.85; }
        .details { padding: 1.5rem; }
        .row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 0;
            border-bottom: 1px solid #dcfce7;
        }
        .row:last-child { border-bottom: none; }
        .row .label { font-size: 0.85rem; color: #15803d; font-weight: 500; }
        .row .value { font-size: 0.95rem; font-weight: 600; text-align: right; }
        .score {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: #fef3c7;
            color: #92400e;
            padding: 0.25rem 0.75rem;
            border-radius: 999px;
            font-weight: 700;
        }
        .sensory {
            background: #f0fdf4;
            border-radius: 0.5rem;
            padding: 1rem;
            margin: 1rem 1.5rem;
            font-style: italic;
            color: #166534;
            text-align: center;
            font-size: 0.95rem;
        }
        .footer {
            text-align: center;
            padding: 1.5rem;
            font-size: 0.8rem;
            color: #86efac;
        }
        .footer a { color: #22c55e; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">AMAGRO</div>
        <h1>Rastreabilidade do Café</h1>
    </div>

    <div class="card">
        <div class="hero">
            <div class="variety">{{ $lot['variety'] }}</div>
            <div class="process">{{ $lot['process_label'] }}</div>
        </div>

        <div class="details">
            <div class="row">
                <span class="label">Fazenda</span>
                <span class="value">{{ $lot['farm_name'] }}</span>
            </div>
            <div class="row">
                <span class="label">Localização</span>
                <span class="value">{{ $lot['municipality'] }}/{{ $lot['state'] }}</span>
            </div>
            @if($lot['altitude_m'] || $lot['farm_altitude'])
            <div class="row">
                <span class="label">Altitude</span>
                <span class="value">{{ $lot['altitude_m'] ?? $lot['farm_altitude'] }}m</span>
            </div>
            @endif
            @if($lot['plot_name'])
            <div class="row">
                <span class="label">Talhão</span>
                <span class="value">{{ $lot['plot_name'] }}</span>
            </div>
            @endif
            <div class="row">
                <span class="label">Colheita</span>
                <span class="value">{{ $lot['harvest_date'] }}</span>
            </div>
            <div class="row">
                <span class="label">Sacas (60kg)</span>
                <span class="value">{{ $lot['bags_60kg'] }}</span>
            </div>
            @if($lot['cupping_score'])
            <div class="row">
                <span class="label">Pontuação</span>
                <span class="value">
                    <span class="score">★ {{ $lot['cupping_score'] }}</span>
                </span>
            </div>
            @endif
        </div>

        @if($lot['sensory_notes'])
        <div class="sensory">
            "{{ $lot['sensory_notes'] }}"
        </div>
        @endif
    </div>

    <div class="footer">
        Publicado em {{ $lot['published_at'] }}<br>
        Rastreabilidade por <a href="https://amagro.com.br">AMAGRO</a>
    </div>
</body>
</html>
