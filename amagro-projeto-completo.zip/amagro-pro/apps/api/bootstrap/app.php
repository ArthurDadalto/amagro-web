<?php

/**
 * AMAGRO — Laravel 11 Bootstrap Configuration
 *
 * Add this to your bootstrap/app.php:
 */

use App\Http\Middleware\EnsureFarmAccess;
use App\Http\Middleware\SecurityHeaders;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Support\Facades\RateLimiter;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Append security headers to all responses
        $middleware->append(SecurityHeaders::class);

        // Middleware alias for farm access
        $middleware->alias([
            'farm.access' => EnsureFarmAccess::class,
        ]);

        // Sanctum SPA stateful domains
        $middleware->statefulApi();
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })
    ->booting(function () {
        // ── Rate Limiters ─────────────────────────────────
        RateLimiter::for('login', function ($request) {
            return Limit::perMinutes(15, 5)->by($request->ip());
        });

        RateLimiter::for('register', function ($request) {
            return Limit::perHour(3)->by($request->ip());
        });

        RateLimiter::for('api', function ($request) {
            return $request->user()
                ? Limit::perMinute(60)->by($request->user()->id)
                : Limit::perMinute(30)->by($request->ip());
        });

        RateLimiter::for('public-lot', function ($request) {
            return Limit::perMinute(120)->by($request->ip());
        });
    })
    ->create();
