<?php
// ============================================================
// app/Enums/Plan.php
// ============================================================

namespace App\Enums;

enum Plan: string
{
    case Produtor = 'produtor';
    case Especial = 'especial';

    public function label(): string
    {
        return match ($this) {
            self::Produtor => 'Produtor',
            self::Especial => 'Especial',
        };
    }
}
