<?php

namespace App\Enums;

enum Process: string
{
    case Natural = 'natural';
    case Washed = 'washed';
    case Honey = 'honey';
    case Other = 'other';

    public function label(): string
    {
        return match ($this) {
            self::Natural => 'Natural (seco)',
            self::Washed  => 'Lavado',
            self::Honey   => 'Honey (cereja descascado)',
            self::Other   => 'Outro',
        };
    }
}
