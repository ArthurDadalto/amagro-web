<?php

namespace App\Enums;

enum LotStatus: string
{
    case Draft = 'draft';
    case Published = 'published';

    public function label(): string
    {
        return match ($this) {
            self::Draft     => 'Rascunho',
            self::Published => 'Publicado',
        };
    }
}
