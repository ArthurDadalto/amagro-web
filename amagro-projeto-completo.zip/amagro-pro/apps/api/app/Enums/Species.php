<?php

namespace App\Enums;

enum Species: string
{
    case Arabica = 'arabica';
    case Conilon = 'conilon';

    public function label(): string
    {
        return match ($this) {
            self::Arabica => 'Arábica',
            self::Conilon => 'Conilon (Robusta)',
        };
    }
}
