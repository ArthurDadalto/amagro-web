<?php

namespace App\Enums;

enum FarmRole: string
{
    case Owner = 'owner';
    case Manager = 'manager';
    case Viewer = 'viewer';

    public function label(): string
    {
        return match ($this) {
            self::Owner   => 'Proprietário',
            self::Manager => 'Gerente',
            self::Viewer  => 'Visualizador',
        };
    }
}
