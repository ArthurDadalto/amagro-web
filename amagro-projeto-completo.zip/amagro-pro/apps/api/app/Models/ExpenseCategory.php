<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ExpenseCategory extends Model
{
    protected $fillable = ['farm_id', 'name', 'icon', 'is_system'];
    protected $casts = ['is_system' => 'boolean'];

    public function farm(): BelongsTo { return $this->belongsTo(Farm::class); }
    public function expenses(): HasMany { return $this->hasMany(Expense::class, 'category_id'); }

    public function scopeForFarm($query, int $farmId)
    {
        return $query->where(fn ($q) =>
            $q->whereNull('farm_id')->orWhere('farm_id', $farmId)
        );
    }
}
