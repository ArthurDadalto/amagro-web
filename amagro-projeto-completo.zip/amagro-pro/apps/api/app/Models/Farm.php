<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Farm extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name', 'municipality', 'state', 'altitude_m',
        'latitude', 'longitude', 'total_area_ha',
    ];

    protected $casts = [
        'latitude'      => 'decimal:7',
        'longitude'     => 'decimal:7',
        'total_area_ha' => 'decimal:2',
    ];

    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'farm_user')
            ->withPivot('role')
            ->withTimestamps();
    }

    public function plots(): HasMany { return $this->hasMany(Plot::class); }
    public function expenses(): HasMany { return $this->hasMany(Expense::class); }
    public function harvests(): HasMany { return $this->hasMany(Harvest::class); }
    public function inventoryItems(): HasMany { return $this->hasMany(InventoryItem::class); }
    public function soilAnalyses(): HasMany { return $this->hasMany(SoilAnalysis::class); }
    public function lots(): HasMany { return $this->hasMany(Lot::class); }
    public function irrigationCalculations(): HasMany { return $this->hasMany(IrrigationCalculation::class); }
    public function expenseCategories(): HasMany { return $this->hasMany(ExpenseCategory::class); }
}
