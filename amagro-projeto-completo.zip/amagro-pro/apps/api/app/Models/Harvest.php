<?php

namespace App\Models;

use App\Enums\Process;
use App\Enums\Species;
use App\Scopes\FarmScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Harvest extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'farm_id', 'plot_id', 'harvest_date', 'bags_60kg',
        'species', 'variety', 'process', 'notes',
    ];

    protected $casts = [
        'species'      => Species::class,
        'process'      => Process::class,
        'harvest_date' => 'date',
        'bags_60kg'    => 'decimal:1',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope(new FarmScope);
    }

    public function farm(): BelongsTo { return $this->belongsTo(Farm::class); }
    public function plot(): BelongsTo { return $this->belongsTo(Plot::class); }
}
