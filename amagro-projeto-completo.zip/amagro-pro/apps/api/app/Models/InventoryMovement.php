<?php

namespace App\Models;

use App\Scopes\FarmScope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InventoryMovement extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'inventory_item_id', 'farm_id', 'type', 'qty',
        'unit_cost_cents', 'description', 'movement_date',
    ];

    protected $casts = [
        'qty'             => 'decimal:2',
        'unit_cost_cents' => 'integer',
        'movement_date'   => 'date',
        'created_at'      => 'datetime',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope(new FarmScope);

        static::created(function (InventoryMovement $movement) {
            $movement->item->recalculateQty();
        });
    }

    public function item(): BelongsTo { return $this->belongsTo(InventoryItem::class, 'inventory_item_id'); }
    public function farm(): BelongsTo { return $this->belongsTo(Farm::class); }
}
