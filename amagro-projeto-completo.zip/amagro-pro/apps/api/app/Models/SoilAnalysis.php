<?php

namespace App\Models;

use App\Scopes\FarmScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class SoilAnalysis extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'soil_analyses';

    protected $fillable = [
        'farm_id', 'plot_id', 'analysis_date',
        'ph', 'clay_pct', 'p_mg_dm3', 'k_mg_dm3',
        'ca_cmol', 'mg_cmol', 'al_cmol',
        'organic_matter_pct', 'base_saturation_pct', 'notes',
    ];

    protected $casts = [
        'analysis_date' => 'date',
        'ph'            => 'decimal:1',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope(new FarmScope);
    }

    public function farm(): BelongsTo { return $this->belongsTo(Farm::class); }
    public function plot(): BelongsTo { return $this->belongsTo(Plot::class); }

    public function hasAlerts(): bool
    {
        return ($this->ph && ($this->ph < 5.5 || $this->ph > 7.0))
            || ($this->al_cmol && $this->al_cmol > 0.5);
    }
}
