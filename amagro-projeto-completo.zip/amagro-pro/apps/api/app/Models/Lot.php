<?php

namespace App\Models;

use App\Enums\LotStatus;
use App\Enums\Process;
use App\Enums\Species;
use App\Scopes\FarmScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Lot extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'farm_id',
        'plot_id',
        'species',
        'variety',
        'process',
        'harvest_date',
        'bags_60kg',
        'altitude_m',
        'cupping_score',
        'sensory_notes',
        'status',
    ];

    protected $casts = [
        'species'       => Species::class,
        'process'       => Process::class,
        'status'        => LotStatus::class,
        'harvest_date'  => 'date',
        'bags_60kg'     => 'decimal:1',
        'cupping_score' => 'decimal:1',
        'published_at'  => 'datetime',
    ];

    /**
     * FIX: VULN-023 — Removed $hidden. All output formatting is controlled
     * exclusively by LotResource. $hidden on the Model causes inconsistencies
     * if the model is serialized outside of a Resource.
     */

    // ── Boot ──────────────────────────────────────────────

    protected static function booted(): void
    {
        static::addGlobalScope(new FarmScope);

        static::creating(function (Lot $lot) {
            if (empty($lot->hash)) {
                $lot->hash = self::generateUniqueHash();
            }
        });
    }

    // ── Route Model Binding ──────────────────────────────

    /**
     * FIX: VULN-007 — Resolve route binding with tenant scope.
     * Ensures {lot} in URL can only resolve to lots within the current farm.
     */
    public function resolveRouteBinding($value, $field = null): ?self
    {
        $farmId = app()->bound('current_farm_id') ? app('current_farm_id') : null;

        $query = $this->newQuery()->where($field ?? $this->getRouteKeyName(), $value);

        if ($farmId) {
            $query->where('farm_id', $farmId);
        }

        return $query->firstOrFail();
    }

    // ── Relationships ─────────────────────────────────────

    public function farm(): BelongsTo
    {
        return $this->belongsTo(Farm::class);
    }

    public function plot(): BelongsTo
    {
        return $this->belongsTo(Plot::class);
    }

    // ── Scopes ────────────────────────────────────────────

    public function scopePublished($query)
    {
        return $query->where('status', LotStatus::Published);
    }

    public function scopeDraft($query)
    {
        return $query->where('status', LotStatus::Draft);
    }

    // ── Helpers ───────────────────────────────────────────

    public function isPublished(): bool
    {
        return $this->status === LotStatus::Published;
    }

    public function isDraft(): bool
    {
        return $this->status === LotStatus::Draft;
    }

    public function getPublicUrl(): string
    {
        return url("/lote/{$this->hash}");
    }

    public function getQrCodeUrl(): ?string
    {
        if (! $this->qr_code_path) {
            return null;
        }

        return asset("storage/{$this->qr_code_path}");
    }

    // ── Hash Generation ───────────────────────────────────

    /**
     * Generate a unique 8-character hash using nanoid-style random string.
     * Uses alphanumeric lowercase excluding ambiguous chars (0/O, 1/l/I).
     * 30^8 = ~656 billion combinations — collision near-impossible.
     */
    public static function generateUniqueHash(): string
    {
        $alphabet = '23456789abcdefghjkmnpqrstuvwxyz'; // 30 chars
        $maxAttempts = 5;

        for ($i = 0; $i < $maxAttempts; $i++) {
            $hash = '';
            for ($j = 0; $j < 8; $j++) {
                $hash .= $alphabet[random_int(0, strlen($alphabet) - 1)];
            }

            if (! self::withoutGlobalScopes()->where('hash', $hash)->exists()) {
                return $hash;
            }
        }

        // Fallback: extend to 10 chars if somehow all 5 collide
        return Str::random(10);
    }
}
