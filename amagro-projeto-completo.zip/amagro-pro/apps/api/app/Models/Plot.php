<?php

namespace App\Models;

use App\Enums\Species;
use App\Scopes\FarmScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Plot extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'farm_id', 'name', 'species', 'variety', 'area_ha',
        'plant_count', 'planted_at', 'altitude_m',
        'latitude', 'longitude', 'notes',
    ];

    protected $casts = [
        'species'    => Species::class,
        'area_ha'    => 'decimal:2',
        'planted_at' => 'date',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope(new FarmScope);
    }

    public function farm(): BelongsTo { return $this->belongsTo(Farm::class); }
    public function harvests(): HasMany { return $this->hasMany(Harvest::class); }
    public function soilAnalyses(): HasMany { return $this->hasMany(SoilAnalysis::class); }
    public function lots(): HasMany { return $this->hasMany(Lot::class); }
    public function expenses(): HasMany { return $this->hasMany(Expense::class); }
}
