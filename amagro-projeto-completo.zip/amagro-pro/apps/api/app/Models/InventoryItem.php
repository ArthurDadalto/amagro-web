<?php

namespace App\Models;

use App\Scopes\FarmScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class InventoryItem extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = ['farm_id', 'name', 'unit', 'current_qty', 'min_qty'];

    protected $casts = [
        'current_qty' => 'decimal:2',
        'min_qty'     => 'decimal:2',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope(new FarmScope);
    }

    public function farm(): BelongsTo { return $this->belongsTo(Farm::class); }
    public function movements(): HasMany { return $this->hasMany(InventoryMovement::class); }

    public function isLowStock(): bool
    {
        return $this->min_qty !== null && $this->current_qty <= $this->min_qty;
    }

    public function recalculateQty(): void
    {
        $ins = $this->movements()->where('type', 'in')->sum('qty');
        $outs = $this->movements()->where('type', 'out')->sum('qty');
        $this->update(['current_qty' => $ins - $outs]);
    }
}
