<?php

namespace App\Models;

use App\Enums\Plan;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    protected $fillable = [
        'name', 'email', 'password', 'phone',
        'plan', 'plan_expires_at', 'is_trial', 'trial_ends_at',
    ];

    protected $hidden = ['password', 'remember_token'];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'plan_expires_at'   => 'datetime',
        'trial_ends_at'     => 'datetime',
        'plan'              => Plan::class,
        'is_trial'          => 'boolean',
        'password'          => 'hashed',
    ];

    // ── Relationships ─────────────────────────────────────

    public function farms(): BelongsToMany
    {
        return $this->belongsToMany(Farm::class, 'farm_user')
            ->withPivot('role')
            ->withTimestamps();
    }

    // ── Helpers ───────────────────────────────────────────

    public function isTrialing(): bool
    {
        return $this->is_trial && $this->trial_ends_at?->isFuture();
    }

    public function hasPlan(Plan $plan): bool
    {
        return $this->plan === $plan;
    }

    public function hasFeature(string $feature): bool
    {
        $especial = ['lots', 'qrcode', 'ndvi', 'vitrine', 'ai_assistant'];

        if (in_array($feature, $especial)) {
            return $this->plan === Plan::Especial;
        }

        return true; // Produtor has all base features
    }
}
