<?php

namespace App\Services;

use App\Enums\LotStatus;
use App\Jobs\GenerateQrCode;
use App\Models\Lot;
use Illuminate\Pagination\CursorPaginator;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class LotService
{
    /**
     * List lots for the current farm with optional filters.
     *
     * FIX: VULN-001 — Escape LIKE wildcards, validate status enum, cap per_page.
     */
    public function list(array $filters = [], int $perPage = 20): CursorPaginator
    {
        $perPage = min($perPage, 100); // VULN-002: Cap pagination

        return Lot::query()
            ->with('plot:id,name')
            ->when(
                $filters['status'] ?? null,
                fn ($q, $s) => in_array($s, ['draft', 'published'], true)
                    ? $q->where('status', $s)
                    : $q
            )
            ->when(
                $filters['variety'] ?? null,
                fn ($q, $v) => $q->where(
                    'variety',
                    'like',
                    '%' . str_replace(['%', '_'], ['\\%', '\\_'], $v) . '%'
                )
            )
            ->orderByDesc('created_at')
            ->cursorPaginate($perPage);
    }

    /**
     * Create a new lot in draft status.
     */
    public function create(array $data): Lot
    {
        $data['status'] = LotStatus::Draft;

        return Lot::create($data);
    }

    /**
     * Update a draft lot. Published lots cannot be edited.
     *
     * @throws \DomainException
     */
    public function update(Lot $lot, array $data): Lot
    {
        if ($lot->isPublished()) {
            throw new \DomainException('Lotes publicados não podem ser editados. Despublique primeiro.');
        }

        $lot->update($data);

        return $lot->fresh();
    }

    /**
     * Publish a lot: set status, timestamp, dispatch QR generation.
     *
     * FIX: VULN-010 — Pessimistic lock to prevent double publish race condition.
     *
     * @throws \DomainException
     */
    public function publish(Lot $lot): Lot
    {
        if ($lot->isPublished()) {
            throw new \DomainException('Este lote já está publicado.');
        }

        $updated = DB::transaction(function () use ($lot) {
            // Pessimistic lock: SELECT ... FOR UPDATE — prevents race condition
            $lockedLot = Lot::withoutGlobalScopes()
                ->where('id', $lot->id)
                ->where('status', LotStatus::Draft)
                ->lockForUpdate()
                ->first();

            if (! $lockedLot) {
                throw new \DomainException('Este lote já está publicado ou foi removido.');
            }

            $lockedLot->update([
                'status'       => LotStatus::Published,
                'published_at' => now(),
            ]);

            GenerateQrCode::dispatch($lockedLot);

            return $lockedLot;
        });

        return $updated->fresh();
    }

    /**
     * Unpublish a lot: revert to draft, keep hash, delete QR file, clear cache.
     *
     * FIX: VULN-021 — Delete QR file from storage on unpublish.
     */
    public function unpublish(Lot $lot): Lot
    {
        if ($lot->isDraft()) {
            throw new \DomainException('Este lote já é rascunho.');
        }

        // Delete QR Code file from disk
        if ($lot->qr_code_path) {
            Storage::disk('public')->delete($lot->qr_code_path);
        }

        $lot->update([
            'status'       => LotStatus::Draft,
            'qr_code_path' => null,
            'published_at' => null,
        ]);

        // Clear public page cache
        Cache::forget("lot:{$lot->hash}");

        return $lot->fresh();
    }

    /**
     * Soft-delete a lot (only drafts).
     *
     * @throws \DomainException
     */
    public function delete(Lot $lot): void
    {
        if ($lot->isPublished()) {
            throw new \DomainException('Despublique o lote antes de excluir.');
        }

        $lot->delete();
    }

    /**
     * Get public lot data by hash (cached, no auth required).
     * This bypasses the FarmScope since it's a public route.
     */
    public function findPublicByHash(string $hash): ?array
    {
        return Cache::remember("lot:{$hash}", 3600, function () use ($hash) {
            $lot = Lot::withoutGlobalScopes()
                ->with(['farm:id,name,municipality,state,altitude_m', 'plot:id,name,variety'])
                ->where('hash', $hash)
                ->where('status', LotStatus::Published)
                ->first();

            if (! $lot) {
                return null;
            }

            return [
                'hash'           => $lot->hash,
                'species'        => $lot->species?->value ?? 'arabica',
                'species_label'  => self::speciesLabel($lot->species?->value ?? 'arabica'),
                'variety'        => $lot->variety,
                'process'        => $lot->process->value,
                'process_label'  => self::processLabel($lot->process->value),
                'harvest_date'   => $lot->harvest_date->format('d/m/Y'),
                'bags_60kg'      => $lot->bags_60kg,
                'altitude_m'     => $lot->altitude_m,
                'cupping_score'  => $lot->cupping_score,
                'sensory_notes'  => $lot->sensory_notes,
                'farm_name'      => $lot->farm->name,
                'municipality'   => $lot->farm->municipality,
                'state'          => $lot->farm->state,
                'farm_altitude'  => $lot->farm->altitude_m,
                'plot_name'      => $lot->plot?->name,
                'published_at'   => $lot->published_at?->format('d/m/Y'),
            ];
        });
    }

    private static function processLabel(string $process): string
    {
        return match ($process) {
            'natural' => 'Natural (seco)',
            'washed'  => 'Lavado',
            'honey'   => 'Honey (cereja descascado)',
            'other'   => 'Outro',
            default   => $process,
        };
    }

    private static function speciesLabel(string $species): string
    {
        return match ($species) {
            'arabica' => 'Arábica',
            'conilon' => 'Conilon (Robusta)',
            default   => $species,
        };
    }
}
