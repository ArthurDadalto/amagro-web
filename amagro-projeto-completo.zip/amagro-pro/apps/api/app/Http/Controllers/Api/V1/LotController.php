<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreLotRequest;
use App\Http\Requests\UpdateLotRequest;
use App\Http\Resources\LotResource;
use App\Models\Lot;
use App\Services\LotService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\Cache;

class LotController extends Controller
{
    public function __construct(
        private readonly LotService $lotService
    ) {}

    /**
     * GET /api/v1/farms/{farm}/lots
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        $lots = $this->lotService->list(
            filters: $request->only(['status', 'variety']),
            perPage: $request->integer('per_page', 20),
        );

        return LotResource::collection($lots);
    }

    /**
     * POST /api/v1/farms/{farm}/lots
     *
     * FIX: VULN-011 — Idempotency key to prevent double-submit creating duplicates.
     */
    public function store(StoreLotRequest $request): JsonResponse
    {
        $idempotencyKey = $request->header('X-Idempotency-Key');

        if ($idempotencyKey) {
            $cacheKey = "idempotency:{$idempotencyKey}:" . auth()->id();
            if ($cachedId = Cache::get($cacheKey)) {
                $lot = Lot::find($cachedId);
                if ($lot) {
                    return (new LotResource($lot->load('plot')))
                        ->response()
                        ->setStatusCode(201);
                }
            }
        }

        $lot = $this->lotService->create([
            'farm_id' => app('current_farm_id'),
            ...$request->validated(),
        ]);

        if ($idempotencyKey) {
            Cache::put($cacheKey, $lot->id, 3600); // 1 hour
        }

        return (new LotResource($lot->load('plot')))
            ->response()
            ->setStatusCode(201);
    }

    /**
     * GET /api/v1/farms/{farm}/lots/{lot}
     *
     * FIX: VULN-007 — Double-check tenant ownership.
     */
    public function show(Lot $lot): LotResource
    {
        $this->assertTenantOwnership($lot);

        return new LotResource($lot->load(['plot', 'farm']));
    }

    /**
     * PUT /api/v1/farms/{farm}/lots/{lot}
     *
     * FIX: VULN-007 — Double-check tenant ownership.
     */
    public function update(UpdateLotRequest $request, Lot $lot): LotResource
    {
        $this->assertTenantOwnership($lot);

        try {
            $lot = $this->lotService->update($lot, $request->validated());
            return new LotResource($lot->load('plot'));
        } catch (\DomainException $e) {
            abort(422, $e->getMessage());
        }
    }

    /**
     * DELETE /api/v1/farms/{farm}/lots/{lot}
     *
     * FIX: VULN-007 — Double-check tenant ownership.
     */
    public function destroy(Lot $lot): JsonResponse
    {
        $this->assertTenantOwnership($lot);

        try {
            $this->lotService->delete($lot);
            return response()->json(null, 204);
        } catch (\DomainException $e) {
            abort(422, $e->getMessage());
        }
    }

    /**
     * POST /api/v1/farms/{farm}/lots/{lot}/publish
     *
     * FIX: VULN-007 — Double-check tenant ownership.
     */
    public function publish(Lot $lot): LotResource
    {
        $this->assertTenantOwnership($lot);

        try {
            $lot = $this->lotService->publish($lot);
            return new LotResource($lot->load(['plot', 'farm']));
        } catch (\DomainException $e) {
            abort(422, $e->getMessage());
        }
    }

    /**
     * POST /api/v1/farms/{farm}/lots/{lot}/unpublish
     *
     * FIX: VULN-007 — Double-check tenant ownership.
     */
    public function unpublish(Lot $lot): LotResource
    {
        $this->assertTenantOwnership($lot);

        try {
            $lot = $this->lotService->unpublish($lot);
            return new LotResource($lot->load('plot'));
        } catch (\DomainException $e) {
            abort(422, $e->getMessage());
        }
    }

    /**
     * Ensure the lot belongs to the current tenant (farm).
     * Defense-in-depth: even if Global Scope is active, verify explicitly.
     */
    private function assertTenantOwnership(Lot $lot): void
    {
        abort_unless(
            (int) $lot->farm_id === (int) app('current_farm_id'),
            403,
            'Acesso negado a este recurso.'
        );
    }
}
