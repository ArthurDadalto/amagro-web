<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IrrigationController extends Controller
{
    /**
     * POST /api/v1/farms/{farm}/irrigation/calculate
     * Calculate only, does not save.
     */
    public function calculate(Request $request): JsonResponse
    {
        $data = $request->validate([
            'power_cv'         => ['required', 'numeric', 'min:0.1'],
            'hours_per_day'    => ['required', 'numeric', 'min:0.1', 'max:24'],
            'tariff_cents_kwh' => ['required', 'integer', 'min:1'],
            'is_green_tariff'  => ['boolean'],
        ]);

        $kw = round($data['power_cv'] * 0.735, 2);
        $tariff = $data['tariff_cents_kwh'];

        // Green tariff (horário noturno) = 70% do valor
        if ($data['is_green_tariff'] ?? false) {
            $tariff = (int) round($tariff * 0.7);
        }

        $dailyCents = (int) round($kw * $data['hours_per_day'] * $tariff);
        $monthlyCents = $dailyCents * 30;

        return response()->json([
            'power_cv'           => $data['power_cv'],
            'power_kw'           => $kw,
            'tariff_cents_kwh'   => $tariff,
            'is_green_tariff'    => $data['is_green_tariff'] ?? false,
            'daily_cost_cents'   => $dailyCents,
            'monthly_cost_cents' => $monthlyCents,
            'formula'            => "{$kw} kW × {$data['hours_per_day']}h × R\$ " . number_format($tariff / 100, 2, ',', '.') . "/kWh",
        ]);
    }

    /**
     * POST /api/v1/farms/{farm}/irrigation — save calculation
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'             => ['nullable', 'string', 'max:255'],
            'power_cv'         => ['required', 'numeric', 'min:0.1'],
            'hours_per_day'    => ['required', 'numeric', 'min:0.1', 'max:24'],
            'tariff_cents_kwh' => ['required', 'integer', 'min:1'],
            'is_green_tariff'  => ['boolean'],
        ]);

        $kw = round($data['power_cv'] * 0.735, 2);
        $tariff = ($data['is_green_tariff'] ?? false) ? (int) round($data['tariff_cents_kwh'] * 0.7) : $data['tariff_cents_kwh'];
        $dailyCents = (int) round($kw * $data['hours_per_day'] * $tariff);

        $calc = DB::table('irrigation_calculations')->insertGetId([
            'farm_id'            => app('current_farm_id'),
            'name'               => $data['name'],
            'power_cv'           => $data['power_cv'],
            'power_kw'           => $kw,
            'hours_per_day'      => $data['hours_per_day'],
            'tariff_cents_kwh'   => $tariff,
            'is_green_tariff'    => $data['is_green_tariff'] ?? false,
            'daily_cost_cents'   => $dailyCents,
            'monthly_cost_cents' => $dailyCents * 30,
            'season_cost_cents'  => null,
            'created_at'         => now(),
            'updated_at'         => now(),
        ]);

        return response()->json(['data' => DB::table('irrigation_calculations')->find($calc)], 201);
    }

    public function index(): JsonResponse
    {
        $calcs = DB::table('irrigation_calculations')
            ->where('farm_id', app('current_farm_id'))
            ->orderByDesc('created_at')
            ->get();

        return response()->json(['data' => $calcs]);
    }

    public function destroy(int $id): JsonResponse
    {
        DB::table('irrigation_calculations')
            ->where('id', $id)
            ->where('farm_id', app('current_farm_id'))
            ->delete();

        return response()->json(null, 204);
    }
}
