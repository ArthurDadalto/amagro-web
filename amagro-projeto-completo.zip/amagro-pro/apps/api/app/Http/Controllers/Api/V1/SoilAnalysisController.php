<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\SoilAnalysis;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SoilAnalysisController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $analyses = SoilAnalysis::with('plot:id,name')
            ->when($request->plot_id, fn ($q, $id) => $q->where('plot_id', $id))
            ->orderByDesc('analysis_date')
            ->get();

        return response()->json(['data' => $analyses]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'plot_id'              => ['required', 'integer', Rule::exists('plots', 'id')->where('farm_id', app('current_farm_id'))],
            'analysis_date'        => ['required', 'date'],
            'ph'                   => ['nullable', 'numeric', 'min:0', 'max:14'],
            'clay_pct'             => ['nullable', 'numeric', 'min:0', 'max:100'],
            'p_mg_dm3'             => ['nullable', 'numeric', 'min:0'],
            'k_mg_dm3'             => ['nullable', 'numeric', 'min:0'],
            'ca_cmol'              => ['nullable', 'numeric', 'min:0'],
            'mg_cmol'              => ['nullable', 'numeric', 'min:0'],
            'al_cmol'              => ['nullable', 'numeric', 'min:0'],
            'organic_matter_pct'   => ['nullable', 'numeric', 'min:0'],
            'base_saturation_pct'  => ['nullable', 'numeric', 'min:0', 'max:100'],
            'notes'                => ['nullable', 'string', 'max:1000'],
        ]);

        $data['farm_id'] = app('current_farm_id');
        $analysis = SoilAnalysis::create($data);

        return response()->json(['data' => $analysis->load('plot:id,name')], 201);
    }

    public function show(SoilAnalysis $soilAnalysis): JsonResponse
    {
        return response()->json(['data' => $soilAnalysis->load('plot')]);
    }

    public function update(Request $request, SoilAnalysis $soilAnalysis): JsonResponse
    {
        $data = $request->validate([
            'analysis_date'        => ['sometimes', 'date'],
            'ph'                   => ['nullable', 'numeric', 'min:0', 'max:14'],
            'clay_pct'             => ['nullable', 'numeric', 'min:0', 'max:100'],
            'p_mg_dm3'             => ['nullable', 'numeric', 'min:0'],
            'k_mg_dm3'             => ['nullable', 'numeric', 'min:0'],
            'ca_cmol'              => ['nullable', 'numeric', 'min:0'],
            'mg_cmol'              => ['nullable', 'numeric', 'min:0'],
            'al_cmol'              => ['nullable', 'numeric', 'min:0'],
            'organic_matter_pct'   => ['nullable', 'numeric', 'min:0'],
            'base_saturation_pct'  => ['nullable', 'numeric', 'min:0', 'max:100'],
            'notes'                => ['nullable', 'string', 'max:1000'],
        ]);

        $soilAnalysis->update($data);
        return response()->json(['data' => $soilAnalysis->fresh()]);
    }

    public function destroy(SoilAnalysis $soilAnalysis): JsonResponse
    {
        $soilAnalysis->delete();
        return response()->json(null, 204);
    }

    public function alerts(): JsonResponse
    {
        $alerts = SoilAnalysis::with('plot:id,name')
            ->where(fn ($q) => $q->where('ph', '<', 5.5)->orWhere('ph', '>', 7.0)->orWhere('al_cmol', '>', 0.5))
            ->orderByDesc('analysis_date')
            ->get();

        return response()->json(['data' => $alerts]);
    }
}
