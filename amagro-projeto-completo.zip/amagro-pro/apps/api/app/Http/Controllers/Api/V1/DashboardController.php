<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Expense;
use App\Models\Harvest;
use App\Models\InventoryItem;
use App\Models\Lot;
use App\Models\SoilAnalysis;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(): JsonResponse
    {
        $farmId = app('current_farm_id');
        $year = now()->year;

        // Total bags current season
        $totalBags = Harvest::where('farm_id', $farmId)
            ->whereYear('harvest_date', $year)
            ->sum('bags_60kg');

        // Total expenses current year
        $totalExpenses = Expense::where('farm_id', $farmId)
            ->whereYear('expense_date', $year)
            ->sum('amount_cents');

        // Cost per bag
        $costPerBag = $totalBags > 0 ? (int) round($totalExpenses / $totalBags) : null;

        // Low stock alerts
        $lowStockCount = InventoryItem::where('farm_id', $farmId)
            ->whereNotNull('min_qty')
            ->whereColumn('current_qty', '<=', 'min_qty')
            ->count();

        // Soil alerts
        $soilAlerts = SoilAnalysis::where('farm_id', $farmId)
            ->where(fn ($q) => $q->where('ph', '<', 5.5)->orWhere('ph', '>', 7.0)->orWhere('al_cmol', '>', 0.5))
            ->count();

        // Lots
        $lotsPublished = Lot::withoutGlobalScopes()->where('farm_id', $farmId)->where('status', 'published')->count();
        $lotsDraft = Lot::withoutGlobalScopes()->where('farm_id', $farmId)->where('status', 'draft')->count();

        // Expenses by month (last 6 months)
        $expensesByMonth = Expense::where('farm_id', $farmId)
            ->where('expense_date', '>=', now()->subMonths(6)->startOfMonth())
            ->select(DB::raw("TO_CHAR(expense_date, 'YYYY-MM') as month"), DB::raw('SUM(amount_cents) as total_cents'))
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        return response()->json([
            'current_season'      => ($year - 1) . '/' . $year,
            'total_bags'          => (float) $totalBags,
            'total_expense_cents' => (int) $totalExpenses,
            'cost_per_bag_cents'  => $costPerBag,
            'low_stock_alerts'    => $lowStockCount,
            'soil_alerts'         => $soilAlerts,
            'lots_published'      => $lotsPublished,
            'lots_draft'          => $lotsDraft,
            'expenses_by_month'   => $expensesByMonth,
        ]);
    }
}
