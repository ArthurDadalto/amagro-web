<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Expense;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class ExpenseController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $expenses = Expense::with('category:id,name,icon', 'plot:id,name')
            ->when($request->from, fn ($q, $d) => $q->where('expense_date', '>=', $d))
            ->when($request->to, fn ($q, $d) => $q->where('expense_date', '<=', $d))
            ->when($request->category_id, fn ($q, $id) => $q->where('category_id', $id))
            ->when($request->plot_id, fn ($q, $id) => $q->where('plot_id', $id))
            ->orderByDesc('expense_date')
            ->cursorPaginate(min($request->integer('per_page', 20), 100));

        return response()->json($expenses);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'plot_id'      => ['nullable', 'integer', Rule::exists('plots', 'id')->where('farm_id', app('current_farm_id'))],
            'category_id'  => ['required', 'integer', 'exists:expense_categories,id'],
            'description'  => ['nullable', 'string', 'max:500'],
            'amount_cents' => ['required', 'integer', 'min:1'],
            'expense_date' => ['required', 'date', 'before_or_equal:today'],
        ]);

        $data['farm_id'] = app('current_farm_id');
        $expense = Expense::create($data);

        return response()->json(['data' => $expense->load('category:id,name')], 201);
    }

    public function show(Expense $expense): JsonResponse
    {
        return response()->json(['data' => $expense->load(['category', 'plot'])]);
    }

    public function update(Request $request, Expense $expense): JsonResponse
    {
        $data = $request->validate([
            'plot_id'      => ['nullable', 'integer', Rule::exists('plots', 'id')->where('farm_id', app('current_farm_id'))],
            'category_id'  => ['sometimes', 'integer', 'exists:expense_categories,id'],
            'description'  => ['nullable', 'string', 'max:500'],
            'amount_cents' => ['sometimes', 'integer', 'min:1'],
            'expense_date' => ['sometimes', 'date', 'before_or_equal:today'],
        ]);

        $expense->update($data);
        return response()->json(['data' => $expense->fresh()->load('category')]);
    }

    public function destroy(Expense $expense): JsonResponse
    {
        $expense->delete();
        return response()->json(null, 204);
    }

    /**
     * GET /api/v1/farms/{farm}/expenses/summary
     */
    public function summary(Request $request): JsonResponse
    {
        $farmId = app('current_farm_id');
        $from = $request->input('from', now()->startOfYear()->toDateString());
        $to = $request->input('to', now()->toDateString());

        $total = Expense::where('farm_id', $farmId)
            ->whereBetween('expense_date', [$from, $to])
            ->sum('amount_cents');

        $byCategory = Expense::where('farm_id', $farmId)
            ->whereBetween('expense_date', [$from, $to])
            ->join('expense_categories', 'expenses.category_id', '=', 'expense_categories.id')
            ->select('expense_categories.name', DB::raw('SUM(amount_cents) as total_cents'))
            ->groupBy('expense_categories.name')
            ->orderByDesc('total_cents')
            ->get();

        $byMonth = Expense::where('expenses.farm_id', $farmId)
            ->whereBetween('expense_date', [$from, $to])
            ->select(DB::raw("TO_CHAR(expense_date, 'YYYY-MM') as month"), DB::raw('SUM(amount_cents) as total_cents'))
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        return response()->json([
            'period'      => compact('from', 'to'),
            'total_cents' => (int) $total,
            'by_category' => $byCategory,
            'by_month'    => $byMonth,
        ]);
    }
}
