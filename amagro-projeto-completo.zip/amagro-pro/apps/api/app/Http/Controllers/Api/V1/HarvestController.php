<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Enums\Process;
use App\Enums\Species;
use App\Models\Harvest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class HarvestController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $harvests = Harvest::with('plot:id,name')
            ->when($request->from, fn ($q, $d) => $q->where('harvest_date', '>=', $d))
            ->when($request->to, fn ($q, $d) => $q->where('harvest_date', '<=', $d))
            ->when($request->plot_id, fn ($q, $id) => $q->where('plot_id', $id))
            ->orderByDesc('harvest_date')
            ->cursorPaginate(min($request->integer('per_page', 20), 100));

        return response()->json($harvests);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'plot_id'      => ['required', 'integer', Rule::exists('plots', 'id')->where('farm_id', app('current_farm_id'))],
            'harvest_date' => ['required', 'date', 'before_or_equal:today'],
            'bags_60kg'    => ['required', 'numeric', 'min:0.1'],
            'species'      => ['required', Rule::enum(Species::class)],
            'variety'      => ['required', 'string', 'max:100'],
            'process'      => ['required', Rule::enum(Process::class)],
            'notes'        => ['nullable', 'string', 'max:1000'],
        ]);

        $data['farm_id'] = app('current_farm_id');
        $harvest = Harvest::create($data);

        return response()->json(['data' => $harvest->load('plot:id,name')], 201);
    }

    public function show(Harvest $harvest): JsonResponse
    {
        return response()->json(['data' => $harvest->load('plot')]);
    }

    public function update(Request $request, Harvest $harvest): JsonResponse
    {
        $data = $request->validate([
            'plot_id'      => ['sometimes', 'integer', Rule::exists('plots', 'id')->where('farm_id', app('current_farm_id'))],
            'harvest_date' => ['sometimes', 'date', 'before_or_equal:today'],
            'bags_60kg'    => ['sometimes', 'numeric', 'min:0.1'],
            'species'      => ['sometimes', Rule::enum(Species::class)],
            'variety'      => ['sometimes', 'string', 'max:100'],
            'process'      => ['sometimes', Rule::enum(Process::class)],
            'notes'        => ['nullable', 'string', 'max:1000'],
        ]);

        $harvest->update($data);
        return response()->json(['data' => $harvest->fresh()->load('plot:id,name')]);
    }

    public function destroy(Harvest $harvest): JsonResponse
    {
        $harvest->delete();
        return response()->json(null, 204);
    }

    public function summary(Request $request): JsonResponse
    {
        $farmId = app('current_farm_id');

        $bySeason = Harvest::where('farm_id', $farmId)
            ->select(DB::raw("EXTRACT(YEAR FROM harvest_date) as year"), DB::raw('SUM(bags_60kg) as total_bags'))
            ->groupBy('year')
            ->orderByDesc('year')
            ->get();

        return response()->json(['data' => $bySeason]);
    }
}
