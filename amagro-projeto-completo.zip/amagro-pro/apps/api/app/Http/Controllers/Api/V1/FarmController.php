<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Farm;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FarmController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $farms = $request->user()->farms()->withPivot('role')->get()
            ->map(fn (Farm $f) => [
                'id'            => $f->id,
                'name'          => $f->name,
                'municipality'  => $f->municipality,
                'state'         => $f->state,
                'altitude_m'    => $f->altitude_m,
                'latitude'      => $f->latitude,
                'longitude'     => $f->longitude,
                'total_area_ha' => $f->total_area_ha,
                'role'          => $f->pivot->role,
            ]);

        return response()->json(['data' => $farms]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'          => ['required', 'string', 'max:255'],
            'municipality'  => ['required', 'string', 'max:255'],
            'state'         => ['required', 'string', 'size:2'],
            'altitude_m'    => ['nullable', 'integer', 'min:0', 'max:3000'],
            'latitude'      => ['nullable', 'numeric', 'min:-90', 'max:90'],
            'longitude'     => ['nullable', 'numeric', 'min:-180', 'max:180'],
            'total_area_ha' => ['nullable', 'numeric', 'min:0'],
        ]);

        $farm = Farm::create($data);
        $request->user()->farms()->attach($farm->id, ['role' => 'owner']);

        return response()->json(['data' => $farm], 201);
    }

    public function show(Farm $farm): JsonResponse
    {
        return response()->json(['data' => $farm]);
    }

    public function update(Request $request, Farm $farm): JsonResponse
    {
        $role = app('current_farm_role');
        abort_unless(in_array($role, ['owner', 'manager']), 403, 'Sem permissão para editar.');

        $data = $request->validate([
            'name'          => ['sometimes', 'string', 'max:255'],
            'municipality'  => ['sometimes', 'string', 'max:255'],
            'state'         => ['sometimes', 'string', 'size:2'],
            'altitude_m'    => ['nullable', 'integer', 'min:0', 'max:3000'],
            'latitude'      => ['nullable', 'numeric', 'min:-90', 'max:90'],
            'longitude'     => ['nullable', 'numeric', 'min:-180', 'max:180'],
            'total_area_ha' => ['nullable', 'numeric', 'min:0'],
        ]);

        $farm->update($data);

        return response()->json(['data' => $farm->fresh()]);
    }

    public function destroy(Farm $farm): JsonResponse
    {
        $role = app('current_farm_role');
        abort_unless($role === 'owner', 403, 'Apenas o proprietário pode excluir.');

        $farm->delete();

        return response()->json(null, 204);
    }
}
