<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Enums\Species;
use App\Models\Plot;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PlotController extends Controller
{
    public function index(): JsonResponse
    {
        $plots = Plot::orderBy('name')->get();
        return response()->json(['data' => $plots]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'        => ['required', 'string', 'max:255'],
            'species'     => ['required', Rule::enum(Species::class)],
            'variety'     => ['required', 'string', 'max:100'],
            'area_ha'     => ['required', 'numeric', 'min:0.01'],
            'plant_count' => ['nullable', 'integer', 'min:0'],
            'planted_at'  => ['nullable', 'date'],
            'altitude_m'  => ['nullable', 'integer', 'min:0', 'max:3000'],
            'latitude'    => ['nullable', 'numeric'],
            'longitude'   => ['nullable', 'numeric'],
            'notes'       => ['nullable', 'string', 'max:1000'],
        ]);

        $data['farm_id'] = app('current_farm_id');
        $plot = Plot::create($data);

        return response()->json(['data' => $plot], 201);
    }

    public function show(Plot $plot): JsonResponse
    {
        $plot->load(['soilAnalyses' => fn ($q) => $q->latest('analysis_date')->limit(3)]);
        return response()->json(['data' => $plot]);
    }

    public function update(Request $request, Plot $plot): JsonResponse
    {
        $data = $request->validate([
            'name'        => ['sometimes', 'string', 'max:255'],
            'species'     => ['sometimes', Rule::enum(Species::class)],
            'variety'     => ['sometimes', 'string', 'max:100'],
            'area_ha'     => ['sometimes', 'numeric', 'min:0.01'],
            'plant_count' => ['nullable', 'integer', 'min:0'],
            'planted_at'  => ['nullable', 'date'],
            'altitude_m'  => ['nullable', 'integer'],
            'latitude'    => ['nullable', 'numeric'],
            'longitude'   => ['nullable', 'numeric'],
            'notes'       => ['nullable', 'string', 'max:1000'],
        ]);

        $plot->update($data);
        return response()->json(['data' => $plot->fresh()]);
    }

    public function destroy(Plot $plot): JsonResponse
    {
        $plot->delete();
        return response()->json(null, 204);
    }
}
