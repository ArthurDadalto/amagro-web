<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\InventoryItem;
use App\Models\InventoryMovement;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class InventoryController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $items = InventoryItem::query()
            ->when($request->boolean('low_stock'), fn ($q) =>
                $q->whereNotNull('min_qty')->whereColumn('current_qty', '<=', 'min_qty')
            )
            ->orderBy('name')
            ->get();

        return response()->json(['data' => $items]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'    => ['required', 'string', 'max:255'],
            'unit'    => ['required', 'string', 'max:20'],
            'min_qty' => ['nullable', 'numeric', 'min:0'],
        ]);

        $data['farm_id'] = app('current_farm_id');
        $item = InventoryItem::create($data);

        return response()->json(['data' => $item], 201);
    }

    public function show(InventoryItem $item): JsonResponse
    {
        $item->load(['movements' => fn ($q) => $q->orderByDesc('movement_date')->limit(20)]);
        return response()->json(['data' => $item]);
    }

    public function update(Request $request, InventoryItem $item): JsonResponse
    {
        $data = $request->validate([
            'name'    => ['sometimes', 'string', 'max:255'],
            'unit'    => ['sometimes', 'string', 'max:20'],
            'min_qty' => ['nullable', 'numeric', 'min:0'],
        ]);

        $item->update($data);
        return response()->json(['data' => $item->fresh()]);
    }

    public function destroy(InventoryItem $item): JsonResponse
    {
        $item->delete();
        return response()->json(null, 204);
    }

    /**
     * POST /api/v1/farms/{farm}/inventory/{item}/movements
     */
    public function addMovement(Request $request, InventoryItem $item): JsonResponse
    {
        $data = $request->validate([
            'type'            => ['required', 'in:in,out'],
            'qty'             => ['required', 'numeric', 'min:0.01'],
            'unit_cost_cents' => ['nullable', 'integer', 'min:0'],
            'description'     => ['nullable', 'string', 'max:500'],
            'movement_date'   => ['required', 'date', 'before_or_equal:today'],
        ]);

        // Prevent negative stock
        if ($data['type'] === 'out' && $data['qty'] > $item->current_qty) {
            abort(422, 'Quantidade de saída maior que o estoque atual.');
        }

        $data['inventory_item_id'] = $item->id;
        $data['farm_id'] = app('current_farm_id');
        $data['created_at'] = now();

        $movement = InventoryMovement::create($data);

        return response()->json([
            'data' => [
                'movement'    => $movement,
                'current_qty' => $item->fresh()->current_qty,
            ],
        ], 201);
    }

    public function movements(InventoryItem $item): JsonResponse
    {
        $movements = $item->movements()
            ->orderByDesc('movement_date')
            ->cursorPaginate(50);

        return response()->json($movements);
    }
}
