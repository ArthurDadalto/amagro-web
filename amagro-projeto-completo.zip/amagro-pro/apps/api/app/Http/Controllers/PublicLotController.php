<?php

namespace App\Http\Controllers;

use App\Services\LotService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PublicLotController extends Controller
{
    public function __construct(
        private readonly LotService $lotService
    ) {}

    /**
     * GET /lote/{hash}
     * Public page rendered via Blade with aggressive caching.
     * Target: < 300ms on cache hit.
     */
    public function show(string $hash): View
    {
        // Validate hash format (8 alphanumeric chars)
        if (! preg_match('/^[a-z0-9]{8,10}$/', $hash)) {
            abort(404);
        }

        $lot = $this->lotService->findPublicByHash($hash);

        if (! $lot) {
            abort(404);
        }

        return view('lots.show', ['lot' => $lot]);
    }
}
