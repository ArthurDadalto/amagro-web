<?php

namespace App\Http\Requests;

use App\Enums\Process;
use App\Enums\Species;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreLotRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // Farm access checked by middleware
    }

    public function rules(): array
    {
        return [
            /**
             * FIX: VULN-003 — Validate plot_id belongs to current farm (prevents IDOR).
             * Without this, user A could link a lot to user B's plot.
             */
            'plot_id' => [
                'nullable',
                'integer',
                Rule::exists('plots', 'id')->where('farm_id', app('current_farm_id')),
            ],

            'species' => ['required', Rule::enum(Species::class)],
            'variety' => ['required', 'string', 'max:100'],
            'process' => ['required', Rule::enum(Process::class)],
            'harvest_date' => ['required', 'date', 'before_or_equal:today'],
            'bags_60kg' => ['required', 'numeric', 'min:0.1', 'max:99999'],
            'altitude_m' => ['nullable', 'integer', 'min:0', 'max:3000'],
            'cupping_score' => ['nullable', 'numeric', 'min:0', 'max:100'],

            /**
             * FIX: VULN-004 — Strip HTML/script tags from sensory notes.
             * Although Blade escapes output, prevent storage of malicious content.
             */
            'sensory_notes' => ['nullable', 'string', 'max:500', 'regex:/^[^<>]*$/'],
        ];
    }

    public function messages(): array
    {
        return [
            'species.required'    => 'Selecione a espécie (Arábica ou Conilon).',
            'variety.required'    => 'Informe a variedade do café.',
            'process.required'    => 'Selecione o processo de beneficiamento.',
            'harvest_date.required' => 'Informe a data da colheita.',
            'harvest_date.before_or_equal' => 'A data de colheita não pode ser no futuro.',
            'bags_60kg.required'  => 'Informe a quantidade de sacas.',
            'bags_60kg.min'       => 'A quantidade mínima é 0.1 saca.',
            'plot_id.exists'      => 'Talhão não encontrado nesta fazenda.',
            'sensory_notes.regex' => 'Notas sensoriais não podem conter caracteres especiais (< >).',
        ];
    }
}
