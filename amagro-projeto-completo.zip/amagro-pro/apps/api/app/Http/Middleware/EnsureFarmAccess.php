<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureFarmAccess
{
    public function handle(Request $request, Closure $next): Response
    {
        $farm = $request->route('farm');

        if (! $farm) {
            abort(404, 'Fazenda não encontrada.');
        }

        // Resolve farm if it's an ID
        if (is_numeric($farm)) {
            $farm = \App\Models\Farm::findOrFail($farm);
        }

        // Check user has access
        $user = $request->user();
        $pivot = $user->farms()->where('farms.id', $farm->id)->first();

        if (! $pivot) {
            abort(403, 'Você não tem acesso a esta fazenda.');
        }

        // Bind farm and tenant context
        $request->route()->setParameter('farm', $farm);
        app()->instance('current_farm_id', $farm->id);
        app()->instance('current_farm', $farm);
        app()->instance('current_farm_role', $pivot->pivot->role);

        return $next($request);
    }
}
