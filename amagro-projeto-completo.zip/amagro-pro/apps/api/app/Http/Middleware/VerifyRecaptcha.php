<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

/**
 * FIX: VULN-013 — Google reCAPTCHA v3 server-side verification.
 *
 * Usage in routes:
 *   Route::post('login', ...)->middleware('recaptcha:0.5');
 *   Route::post('register', ...)->middleware('recaptcha:0.7');
 *
 * Register in bootstrap/app.php:
 *   $middleware->alias(['recaptcha' => VerifyRecaptcha::class]);
 */
class VerifyRecaptcha
{
    public function handle(Request $request, Closure $next, float $minScore = 0.5): Response
    {
        // Skip in testing/local
        if (app()->environment('local', 'testing')) {
            return $next($request);
        }

        $token = $request->input('recaptcha_token');

        if (! $token) {
            abort(422, 'Verificação de segurança ausente. Recarregue a página.');
        }

        try {
            $response = Http::asForm()
                ->timeout(5)
                ->post('https://www.google.com/recaptcha/api/siteverify', [
                    'secret'   => config('services.recaptcha.secret'),
                    'response' => $token,
                    'remoteip' => $request->ip(),
                ]);

            $result = $response->json();

            $success = $result['success'] ?? false;
            $score   = $result['score'] ?? 0;

            if (! $success || $score < $minScore) {
                Log::warning('reCAPTCHA failed', [
                    'ip'      => $request->ip(),
                    'score'   => $score,
                    'success' => $success,
                    'errors'  => $result['error-codes'] ?? [],
                ]);

                abort(422, 'Verificação de segurança falhou. Tente novamente.');
            }
        } catch (\Exception $e) {
            // If Google is down, log but allow through (fail-open for availability)
            Log::error('reCAPTCHA API error', ['error' => $e->getMessage()]);
        }

        return $next($request);
    }
}
