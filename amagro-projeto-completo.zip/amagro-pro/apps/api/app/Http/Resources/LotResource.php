<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LotResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'             => $this->id, // Internal, for auth routes only
            'hash'           => $this->hash,
            'variety'        => $this->variety,
            'process'        => $this->process->value,
            'process_label'  => $this->processLabel(),
            'harvest_date'   => $this->harvest_date->format('Y-m-d'),
            'bags_60kg'      => (float) $this->bags_60kg,
            'altitude_m'     => $this->altitude_m,
            'cupping_score'  => $this->cupping_score ? (float) $this->cupping_score : null,
            'sensory_notes'  => $this->sensory_notes,
            'status'         => $this->status->value,
            'status_label'   => $this->status->label(),
            'public_url'     => $this->isPublished() ? $this->getPublicUrl() : null,
            'qr_code_url'    => $this->getQrCodeUrl(),
            'published_at'   => $this->published_at?->toIso8601String(),
            'created_at'     => $this->created_at->toIso8601String(),
            'updated_at'     => $this->updated_at->toIso8601String(),

            // Relationships (when loaded)
            'plot' => $this->when($this->relationLoaded('plot') && $this->plot, [
                'id'   => $this->plot?->id,
                'name' => $this->plot?->name,
            ]),
            'farm' => $this->when($this->relationLoaded('farm'), [
                'name'         => $this->farm?->name,
                'municipality' => $this->farm?->municipality,
                'state'        => $this->farm?->state,
                'altitude_m'   => $this->farm?->altitude_m,
            ]),
        ];
    }

    private function processLabel(): string
    {
        return match ($this->process->value) {
            'natural' => 'Natural (seco)',
            'washed'  => 'Lavado',
            'honey'   => 'Honey (cereja descascado)',
            default   => 'Outro',
        };
    }
}
