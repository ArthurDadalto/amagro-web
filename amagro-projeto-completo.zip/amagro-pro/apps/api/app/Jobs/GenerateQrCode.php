<?php

namespace App\Jobs;

use App\Models\Lot;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

/**
 * FIX: VULN-008 — Sanitize hash before using in file path.
 * FIX: Added ShouldBeUnique to prevent duplicate QR generation from race conditions.
 */
class GenerateQrCode implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $backoff = 10;
    public int $uniqueFor = 300; // 5 min uniqueness window

    public function __construct(
        public readonly Lot $lot
    ) {}

    /**
     * Unique ID prevents duplicate jobs for the same lot.
     */
    public function uniqueId(): string
    {
        return 'qr-' . $this->lot->id;
    }

    public function handle(): void
    {
        // VULN-008: Sanitize hash — strip any non-alphanumeric chars
        $safeHash = preg_replace('/[^a-z0-9]/', '', $this->lot->hash);

        if (strlen($safeHash) < 8) {
            Log::error("Invalid hash for lot {$this->lot->id}: '{$this->lot->hash}'");
            return;
        }

        $url  = url("/lote/{$safeHash}");
        $path = "qrcodes/{$safeHash}.png";

        $png = QrCode::format('png')
            ->size(400)
            ->margin(2)
            ->errorCorrection('H') // High error correction for print on coffee bags
            ->generate($url);

        Storage::disk('public')->put($path, $png);

        // Update lot with QR path (bypass global scope)
        Lot::withoutGlobalScopes()
            ->where('id', $this->lot->id)
            ->update(['qr_code_path' => $path]);

        Log::info("QR Code generated for lot {$safeHash}");
    }

    public function failed(\Throwable $e): void
    {
        Log::error("Failed to generate QR for lot {$this->lot->hash}: {$e->getMessage()}");
    }
}
