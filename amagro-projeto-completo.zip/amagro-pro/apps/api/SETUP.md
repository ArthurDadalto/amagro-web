# AMAGRO Backend — Setup Guide

## 1. Criar projeto Laravel 11

```bash
composer create-project laravel/laravel amagro-api
cd amagro-api
```

## 2. Instalar dependências

```bash
# Auth SPA
composer require laravel/sanctum

# QR Code (lotes)
composer require simplesoftwareio/simple-qrcode

# Pagamentos (futuro)
# composer require laravel/cashier

# UUID / nanoid helper (opcional)
# composer require hidehalo/nanoid-php
```

## 3. Configurar .env

```env
APP_NAME=AMAGRO
APP_URL=http://localhost:8000
FRONTEND_URL=http://localhost:5173

DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=amagro
DB_USERNAME=postgres
DB_PASSWORD=secret

SANCTUM_STATEFUL_DOMAINS=localhost:5173,localhost
SESSION_DOMAIN=localhost

CACHE_STORE=file
QUEUE_CONNECTION=database
```

## 4. Configurar Sanctum SPA

```php
// config/sanctum.php
'stateful' => explode(',', env('SANCTUM_STATEFUL_DOMAINS', 'localhost,localhost:5173')),
```

```php
// config/cors.php
'supports_credentials' => true,
'allowed_origins' => [env('FRONTEND_URL', 'http://localhost:5173')],
```

## 5. Copiar arquivos

Copiar todos os arquivos entregues para os respectivos diretórios:
- `app/Enums/` — Enums PHP
- `app/Models/` — Eloquent Models
- `app/Scopes/` — FarmScope
- `app/Http/Controllers/Api/V1/` — Controllers API
- `app/Http/Middleware/` — Middlewares custom
- `app/Http/Requests/` — Form Requests
- `app/Services/` — Business logic
- `routes/` — api.php e web.php
- `database/migrations/` — Migrations
- `database/seeders/` — Seeders

## 6. Rodar migrations

```bash
php artisan migrate
php artisan db:seed --class=ExpenseCategorySeeder
```

## 7. Rodar

```bash
php artisan serve
# API em http://localhost:8000
# Frontend apontando via proxy do Vite
```
