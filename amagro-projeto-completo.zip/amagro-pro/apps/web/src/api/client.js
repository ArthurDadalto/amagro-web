import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api/v1',
  withCredentials: true,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
  timeout: 30000,
});

let csrfReady = false;

async function ensureCsrf() {
  if (csrfReady) return;
  await axios.get('/sanctum/csrf-cookie', { withCredentials: true });
  csrfReady = true;
}

api.interceptors.request.use(async (config) => {
  if (['post', 'put', 'patch', 'delete'].includes(config.method)) {
    await ensureCsrf();
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      csrfReady = false;
      window.location.href = '/login';
    }
    if (err.response?.status === 419) {
      csrfReady = false;
    }
    return Promise.reject(err);
  }
);

export default api;
