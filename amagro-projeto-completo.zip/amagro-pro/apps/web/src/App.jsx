import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useThemeStore } from './stores/themeStore';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { DashboardPage } from './features/dashboard/DashboardPage';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';

const Placeholder = ({ title }) => (
  <div className="flex flex-col items-center justify-center h-[60vh] text-center">
    <h2 className="text-xl font-bold mb-2" style={{ color: 'var(--am-text)' }}>{title}</h2>
    <p style={{ color: 'var(--am-muted)' }} className="text-sm">Módulo em desenvolvimento.</p>
  </div>
);

export default function App() {
  const initTheme = useThemeStore((s) => s.initTheme);

  useEffect(() => {
    initTheme();
  }, [initTheme]);

  return (
    <BrowserRouter>
      <Routes>
        {/* Pública */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Dashboard (futuramente protegido) */}
        <Route path="/dashboard" element={<DashboardLayout />}>
          <Route index element={<DashboardPage />} />
          <Route path="fazendas" element={<Placeholder title="Fazendas e Talhões" />} />
          <Route path="gastos" element={<Placeholder title="Controle de Gastos" />} />
          <Route path="colheita" element={<Placeholder title="Registro de Colheita" />} />
          <Route path="estoque" element={<Placeholder title="Estoque de Insumos" />} />
          <Route path="solo" element={<Placeholder title="Solo e Mapa" />} />
          <Route path="lotes" element={<Placeholder title="Lotes e Rastreabilidade" />} />
          <Route path="precificacao" element={<Placeholder title="Precificação" />} />
          <Route path="irrigacao" element={<Placeholder title="Calculadora de Irrigação" />} />
          <Route path="clima" element={<Placeholder title="Previsão do Tempo" />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
