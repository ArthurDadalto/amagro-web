import { NavLink } from 'react-router-dom';
import { LayoutDashboard, DollarSign, Plus, QrCode, MoreHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';

const tabs = [
  { name: 'Início', href: '/dashboard', icon: LayoutDashboard, end: true },
  { name: 'Gastos', href: '/dashboard/gastos', icon: DollarSign },
  { name: 'Novo', href: '#fab', icon: Plus, isFab: true },
  { name: 'Lotes', href: '/dashboard/lotes', icon: QrCode },
  { name: 'Mais', href: '#more', icon: MoreHorizontal },
];

export function BottomNav({ onFab, onMore }) {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-30 flex items-center justify-around h-16 lg:hidden"
      style={{ background: 'var(--am-bg-deep)', borderTop: '1px solid var(--am-border)' }}
    >
      {tabs.map((tab) => {
        if (tab.isFab) {
          return (
            <button
              key={tab.name}
              onClick={onFab}
              className="w-12 h-12 -mt-4 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95"
              style={{ background: 'var(--am-gold)', color: '#0C1F0E' }}
            >
              <Plus size={24} strokeWidth={2.5} />
            </button>
          );
        }

        if (tab.href === '#more') {
          return (
            <button
              key={tab.name}
              onClick={onMore}
              className="flex flex-col items-center gap-0.5 py-1 px-3"
              style={{ color: 'var(--am-muted)' }}
            >
              <tab.icon size={20} />
              <span className="text-[10px] font-medium">{tab.name}</span>
            </button>
          );
        }

        return (
          <NavLink
            key={tab.name}
            to={tab.href}
            end={tab.end}
            className="flex flex-col items-center gap-0.5 py-1 px-3"
            style={({ isActive }) => ({ color: isActive ? 'var(--am-gold)' : 'var(--am-muted)' })}
          >
            <tab.icon size={20} />
            <span className="text-[10px] font-medium">{tab.name}</span>
          </NavLink>
        );
      })}
    </nav>
  );
}
