import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard, Map, DollarSign, Sprout, Package,
  FlaskConical, QrCode, TrendingUp, Droplets, CloudSun, X,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const nav = [
  { name: 'Início', href: '/dashboard', icon: LayoutDashboard, end: true },
  { name: 'Fazendas', href: '/dashboard/fazendas', icon: Map },
  { name: 'Gastos', href: '/dashboard/gastos', icon: DollarSign },
  { name: 'Colheita', href: '/dashboard/colheita', icon: Sprout },
  { name: 'Estoque', href: '/dashboard/estoque', icon: Package },
  { name: 'Solo & Mapa', href: '/dashboard/solo', icon: FlaskConical },
  { name: 'Lotes / QR', href: '/dashboard/lotes', icon: QrCode },
  { name: 'Precificação', href: '/dashboard/precificacao', icon: TrendingUp },
  { name: 'Irrigação', href: '/dashboard/irrigacao', icon: Droplets },
  { name: 'Clima', href: '/dashboard/clima', icon: CloudSun },
];

export function Sidebar({ isOpen, setIsOpen }) {
  return (
    <>
      {/* Overlay mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 w-[260px] flex flex-col transform transition-transform duration-300 lg:translate-x-0 lg:static lg:h-screen',
          isOpen ? 'translate-x-0' : '-translate-x-full'
        )}
        style={{ background: 'var(--am-bg-deep)', borderRight: '1px solid var(--am-border)' }}
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-5">
          <span className="text-xl font-bold tracking-wider" style={{ color: 'var(--am-gold)' }}>
            AMAGRO
          </span>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1.5 rounded-lg lg:hidden transition-colors"
            style={{ color: 'var(--am-muted)' }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-2 space-y-0.5 overflow-y-auto">
          {nav.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              end={item.end}
              onClick={() => setIsOpen(false)}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-[10px] text-[13px] font-medium transition-all duration-200',
                  isActive
                    ? 'am-nav-active'
                    : 'am-nav-default'
                )
              }
              style={({ isActive }) =>
                isActive
                  ? { background: 'var(--am-primary)', color: '#fff' }
                  : { color: 'var(--am-muted)' }
              }
            >
              <item.icon size={18} className="shrink-0" />
              <span>{item.name}</span>
            </NavLink>
          ))}
        </nav>

        {/* Footer */}
        <div className="px-5 py-4 text-[11px]" style={{ color: 'var(--am-muted)', borderTop: '1px solid var(--am-border)' }}>
          <p className="font-medium" style={{ color: 'var(--am-gold)' }}>Plano Produtor</p>
          <p className="mt-0.5">Trial — 24 dias restantes</p>
        </div>
      </aside>
    </>
  );
}
