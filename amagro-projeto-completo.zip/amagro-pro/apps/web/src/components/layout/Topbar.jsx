import { Menu, Search, Bell, Sun, Moon } from 'lucide-react';
import { useThemeStore } from '@/stores/themeStore';

export function Topbar({ setIsSidebarOpen }) {
  const { theme, toggleTheme } = useThemeStore();

  return (
    <header
      className="sticky top-0 z-20 h-14 flex items-center justify-between px-4 sm:px-5"
      style={{ background: 'var(--am-bg-deep)', borderBottom: '1px solid var(--am-border)' }}
    >
      {/* Left */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setIsSidebarOpen(true)}
          className="p-2 -ml-2 rounded-lg lg:hidden transition-colors"
          style={{ color: 'var(--am-muted)' }}
          aria-label="Abrir menu"
        >
          <Menu size={20} />
        </button>

        <div
          className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all"
          style={{ background: 'var(--am-card)', border: '1px solid var(--am-border)' }}
        >
          <Search size={15} style={{ color: 'var(--am-muted)' }} />
          <input
            type="text"
            placeholder="Buscar..."
            className="bg-transparent border-none focus:outline-none w-40 lg:w-56 text-[13px]"
            style={{ color: 'var(--am-text)' }}
          />
        </div>
      </div>

      {/* Right */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Theme toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg transition-colors"
          style={{ color: 'var(--am-muted)' }}
          aria-label={theme === 'dark' ? 'Modo claro' : 'Modo escuro'}
        >
          {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
        </button>

        {/* Notifications */}
        <button className="relative p-2 rounded-lg transition-colors" style={{ color: 'var(--am-muted)' }}>
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full ring-2" style={{ ringColor: 'var(--am-bg-deep)' }} />
        </button>

        <div className="hidden sm:block w-px h-6" style={{ background: 'var(--am-border)' }} />

        {/* Avatar */}
        <button className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold"
            style={{ background: 'var(--am-card)', color: 'var(--am-gold)', border: '1px solid var(--am-border)' }}
          >
            AM
          </div>
          <div className="hidden sm:flex flex-col items-start leading-tight">
            <span className="text-[13px] font-medium" style={{ color: 'var(--am-text)' }}>Arthur Miguel</span>
            <span className="text-[11px]" style={{ color: 'var(--am-muted)' }}>Faz. Taquarussu</span>
          </div>
        </button>
      </div>
    </header>
  );
}
