import { Coffee, Leaf } from 'lucide-react';

export function SpeciesToggle({ selected, onChange }) {
  const options = [
    { value: 'arabica', label: 'Arábica', icon: Coffee },
    { value: 'conilon', label: 'Conilon', icon: Leaf },
  ];

  return (
    <div className="flex rounded-lg p-0.5" style={{ background: 'var(--am-border)' }}>
      {options.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[12px] font-medium transition-all duration-200"
          style={
            selected === opt.value
              ? { background: 'var(--am-primary)', color: '#fff' }
              : { color: 'var(--am-muted)' }
          }
        >
          <opt.icon size={13} />
          {opt.label}
        </button>
      ))}
    </div>
  );
}
