import { useState } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, Droplets, CloudSun, BarChart3 } from 'lucide-react';
import { SpeciesToggle } from '@/components/shared/SpeciesToggle';

// Mock data
const cotacoes = {
  arabica: { preco: 'R$ 2.480', varDia: '+1.2%', varMes: '+4.5%', diaUp: true, mesUp: true },
  conilon: { preco: 'R$ 1.690', varDia: '-0.5%', varMes: '-2.1%', diaUp: false, mesUp: false },
};

const kpis = [
  { label: 'Sacas colhidas', value: '1.204', trend: '+12% vs anterior', up: true },
  { label: 'Custo por saca', value: 'R$ 385', trend: '+5% vs anterior', up: false },
  { label: 'Receita estimada', value: 'R$ 298k', trend: 'Safra 25/26', neutral: true },
  { label: 'Lotes publicados', value: '8', trend: '2 rascunhos', neutral: true },
];

const months = ['Out', 'Nov', 'Dez', 'Jan', 'Fev', 'Mar', 'Abr'];
const barValues = [35, 55, 40, 80, 65, 45, 70];

export function DashboardPage() {
  const [species, setSpecies] = useState('arabica');
  const cot = cotacoes[species];

  return (
    <div className="space-y-5 animate-slide-up">
      {/* Header row: Cotação + Clima */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Cotação */}
        <div className="am-card p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold" style={{ color: 'var(--am-text)' }}>Cotação do dia</h3>
              <p className="text-[11px] mt-0.5" style={{ color: 'var(--am-muted)' }}>Fonte: CEPEA/B3</p>
            </div>
            <SpeciesToggle selected={species} onChange={setSpecies} />
          </div>
          <div className="text-3xl font-bold mt-1" style={{ color: 'var(--am-gold)' }}>{cot.preco}</div>
          <div className="flex gap-8 mt-4 pt-4" style={{ borderTop: '1px solid var(--am-border)' }}>
            <div>
              <p className="text-[10px] uppercase font-semibold tracking-wider" style={{ color: 'var(--am-muted)' }}>Var. dia</p>
              <span className={`text-sm font-bold flex items-center gap-1 mt-1 ${cot.diaUp ? 'text-emerald-400' : 'text-red-400'}`}>
                {cot.diaUp ? <TrendingUp size={14} /> : <TrendingDown size={14} />} {cot.varDia}
              </span>
            </div>
            <div>
              <p className="text-[10px] uppercase font-semibold tracking-wider" style={{ color: 'var(--am-muted)' }}>Var. mês</p>
              <span className={`text-sm font-bold flex items-center gap-1 mt-1 ${cot.mesUp ? 'text-emerald-400' : 'text-red-400'}`}>
                {cot.mesUp ? <TrendingUp size={14} /> : <TrendingDown size={14} />} {cot.varMes}
              </span>
            </div>
          </div>
        </div>

        {/* Clima */}
        <div className="am-card p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold" style={{ color: 'var(--am-text)' }}>Previsão do tempo</h3>
              <p className="text-[11px] mt-0.5" style={{ color: 'var(--am-muted)' }}>Colatina, ES</p>
            </div>
            <span
              className="text-[11px] font-semibold px-2 py-1 rounded-md"
              style={{ background: 'rgba(96, 165, 250, 0.15)', color: '#60A5FA' }}
            >
              <Droplets size={12} className="inline mr-1" />10% chuva
            </span>
          </div>
          <div className="flex items-center gap-4">
            <CloudSun size={48} style={{ color: 'var(--am-gold)' }} />
            <div>
              <span className="text-3xl font-bold" style={{ color: 'var(--am-text)' }}>28°C</span>
              <p className="text-sm" style={{ color: 'var(--am-muted)' }}>Parcialmente nublado</p>
            </div>
          </div>
          <div className="flex justify-between mt-4 pt-4" style={{ borderTop: '1px solid var(--am-border)' }}>
            {[
              { day: 'Amanhã', temp: '24°/30°' },
              { day: 'Quinta', temp: '22°/28°' },
              { day: 'Sexta', temp: '21°/25°', rain: true },
            ].map((d) => (
              <div key={d.day} className="text-center">
                <p className="text-[10px] uppercase font-semibold tracking-wider" style={{ color: d.rain ? '#60A5FA' : 'var(--am-muted)' }}>
                  {d.day}{d.rain ? ' (chuva)' : ''}
                </p>
                <p className="text-xs font-bold mt-1" style={{ color: 'var(--am-text)' }}>{d.temp}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Section title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold" style={{ color: 'var(--am-text)' }}>Resumo da safra</h2>
          <p className="text-[12px]" style={{ color: 'var(--am-muted)' }}>Safra 2025/2026</p>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {kpis.map((kpi, i) => (
          <div key={i} className="am-card p-4">
            <p className="text-[11px] font-medium mb-1" style={{ color: 'var(--am-muted)' }}>{kpi.label}</p>
            <p className="text-xl font-bold" style={{ color: 'var(--am-gold)' }}>{kpi.value}</p>
            <p className={`text-[11px] font-semibold mt-1.5 ${kpi.up === true ? 'text-emerald-400' : kpi.up === false ? 'text-red-400' : ''}`}
               style={kpi.neutral ? { color: 'var(--am-muted)' } : {}}>
              {kpi.trend}
            </p>
          </div>
        ))}
      </div>

      {/* Chart placeholder */}
      <div className="am-card p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold" style={{ color: 'var(--am-text)' }}>Gastos por mês</h3>
            <p className="text-[11px]" style={{ color: 'var(--am-muted)' }}>Últimos 7 meses</p>
          </div>
          <BarChart3 size={18} style={{ color: 'var(--am-muted)' }} />
        </div>
        <div className="flex items-end gap-2 h-32">
          {months.map((m, i) => (
            <div key={m} className="flex-1 flex flex-col items-center gap-1">
              <div
                className="w-full rounded-t-md transition-all duration-500"
                style={{
                  height: `${barValues[i]}%`,
                  background: i % 2 === 0 ? 'var(--am-border)' : 'var(--am-gold)',
                  animationDelay: `${i * 80}ms`,
                }}
              />
              <span className="text-[10px]" style={{ color: 'var(--am-muted)' }}>{m}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom row: Estoque + Alerta */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="am-card p-5">
          <h3 className="text-sm font-semibold mb-3" style={{ color: 'var(--am-text)' }}>Estoque baixo</h3>
          <div className="space-y-2.5">
            {['NPK 20-05-20', 'Calcário dolomítico', 'Fungicida cúprico'].map((item) => (
              <div key={item} className="flex items-center justify-between py-1.5" style={{ borderBottom: '1px solid var(--am-border)' }}>
                <span className="text-[13px]" style={{ color: 'var(--am-text)' }}>{item}</span>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full" style={{ background: 'rgba(248,113,113,0.15)', color: '#F87171' }}>
                  Baixo
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="am-card p-5">
          <h3 className="text-sm font-semibold mb-3" style={{ color: 'var(--am-text)' }}>Alertas</h3>
          <div className="space-y-2.5">
            <div className="flex items-start gap-3 p-3 rounded-lg" style={{ background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.2)' }}>
              <AlertTriangle size={16} className="text-amber-400 mt-0.5 shrink-0" />
              <div>
                <p className="text-[12px] font-medium" style={{ color: 'var(--am-text)' }}>Solo — Talhão 04</p>
                <p className="text-[11px]" style={{ color: 'var(--am-muted)' }}>pH 4.8 abaixo do ideal. Recomenda-se calagem.</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-lg" style={{ background: 'rgba(96,165,250,0.08)', border: '1px solid rgba(96,165,250,0.2)' }}>
              <Droplets size={16} className="text-blue-400 mt-0.5 shrink-0" />
              <div>
                <p className="text-[12px] font-medium" style={{ color: 'var(--am-text)' }}>Chuva prevista</p>
                <p className="text-[11px]" style={{ color: 'var(--am-muted)' }}>Sexta-feira — considere adiar aplicação de defensivo.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
