import { Link } from 'react-router-dom';
import { useThemeStore } from '@/stores/themeStore';
import {
  ArrowRight, BarChart3, QrCode, CloudSun, Shield, Smartphone, TrendingUp,
  Sun, Moon, ChevronRight, Star, Leaf, Coffee,
} from 'lucide-react';

const features = [
  {
    icon: BarChart3,
    title: 'Controle financeiro completo',
    desc: 'Saiba o custo real de cada saca. Gastos por categoria, colheita por talhão e margem por canal de venda.',
  },
  {
    icon: QrCode,
    title: 'Rastreabilidade por QR Code',
    desc: 'Cada lote conta a história do café. Cafeterias e importadores escaneiam e veem origem, processo e nota sensorial.',
  },
  {
    icon: CloudSun,
    title: 'Clima e cotação em tempo real',
    desc: 'Previsão do tempo na sua fazenda e cotação CEPEA/B3 atualizada. Decisões no momento certo.',
  },
  {
    icon: Shield,
    title: 'Análise de solo inteligente',
    desc: 'Registre laudos por talhão, receba alertas de pH e nutrientes. Mapa de satélite integrado.',
  },
  {
    icon: Smartphone,
    title: 'Feito para o campo',
    desc: 'Mobile-first. Funciona no celular, no meio da lavoura, com conexão instável. Simples como deve ser.',
  },
  {
    icon: TrendingUp,
    title: 'Precificação inteligente',
    desc: 'Custo real por saca + cotação de mercado + margem por canal. Nunca mais venda abaixo do custo.',
  },
];

const plans = [
  {
    name: 'Produtor',
    price: 'R$ 49',
    period: '/mês',
    desc: 'Gestão completa da sua fazenda',
    trial: '30 dias grátis',
    features: ['Fazendas e talhões ilimitados', 'Gastos, colheita e estoque', 'Cotação e clima em tempo real', 'Calculadora de irrigação', 'Análise de solo por talhão'],
    cta: 'Começar teste grátis',
    highlighted: false,
  },
  {
    name: 'Especial',
    price: 'R$ 120',
    period: '/mês',
    desc: 'Para café especial e exportação',
    trial: 'Tudo do Produtor +',
    features: ['Rastreabilidade com QR Code', 'Página pública do lote', 'NDVI por satélite (Sentinel)', 'Vitrine para cafeterias', 'Suporte prioritário'],
    cta: 'Começar com Especial',
    highlighted: true,
  },
];

export function LandingPage() {
  const { theme, toggleTheme } = useThemeStore();

  return (
    <div className="min-h-screen" style={{ background: 'var(--am-bg)' }}>
      {/* Navbar */}
      <nav className="flex justify-between items-center px-5 sm:px-8 py-4 max-w-6xl mx-auto">
        <span className="text-xl font-bold tracking-wider" style={{ color: 'var(--am-gold)' }}>AMAGRO</span>
        <div className="flex items-center gap-3">
          <button onClick={toggleTheme} className="p-2 rounded-lg" style={{ color: 'var(--am-muted)' }}>
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <Link to="/login" className="text-sm font-medium px-4 py-2 rounded-lg transition-colors" style={{ color: 'var(--am-muted)' }}>
            Entrar
          </Link>
          <Link to="/dashboard" className="am-btn-primary text-sm hidden sm:inline-flex items-center gap-1.5">
            Teste grátis <ArrowRight size={14} />
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="px-5 sm:px-8 pt-16 pb-20 max-w-6xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-[12px] font-medium mb-6"
          style={{ background: 'rgba(212,168,83,0.1)', color: 'var(--am-gold)', border: '1px solid rgba(212,168,83,0.2)' }}>
          <Coffee size={14} /> Arábica e Conilon
          <Leaf size={14} />
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight max-w-3xl mx-auto" style={{ color: 'var(--am-text)' }}>
          A tecnologia que{' '}
          <span style={{ color: 'var(--am-gold)' }}>valoriza cada saca</span>{' '}
          do seu café.
        </h1>

        <p className="text-base sm:text-lg mt-6 max-w-xl mx-auto leading-relaxed" style={{ color: 'var(--am-muted)' }}>
          Gestão financeira, rastreabilidade por QR Code e inteligência de mercado para produtores do Espírito Santo e sul da Bahia.
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-3 mt-10">
          <Link to="/dashboard" className="am-btn-primary text-base px-8 py-3.5 inline-flex items-center justify-center gap-2">
            Começar meus 30 dias grátis <ArrowRight size={16} />
          </Link>
          <a href="#features" className="am-btn-outline text-base px-8 py-3.5 inline-flex items-center justify-center gap-2">
            Conhecer funcionalidades <ChevronRight size={16} />
          </a>
        </div>

        <p className="text-[12px] mt-4" style={{ color: 'var(--am-muted)' }}>
          Cartão de crédito necessário. Cancele quando quiser.
        </p>
      </section>

      {/* Social proof bar */}
      <section className="py-8 px-5" style={{ borderTop: '1px solid var(--am-border)', borderBottom: '1px solid var(--am-border)' }}>
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-12 text-center">
          {[
            { val: '500+', label: 'Produtores na fila' },
            { val: 'ES + BA', label: 'Cobertura regional' },
            { val: '< 5 min', label: 'Para começar a usar' },
          ].map((s) => (
            <div key={s.label}>
              <span className="text-xl font-bold" style={{ color: 'var(--am-gold)' }}>{s.val}</span>
              <p className="text-[12px] mt-0.5" style={{ color: 'var(--am-muted)' }}>{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="px-5 sm:px-8 py-20 max-w-6xl mx-auto">
        <div className="text-center mb-14">
          <h2 className="text-2xl sm:text-3xl font-bold" style={{ color: 'var(--am-text)' }}>
            Tudo que o produtor precisa.{' '}
            <span style={{ color: 'var(--am-gold)' }}>Nada que não precisa.</span>
          </h2>
          <p className="text-sm mt-3 max-w-md mx-auto" style={{ color: 'var(--am-muted)' }}>
            Construído por quem conhece a lida do campo. Cada funcionalidade resolve um problema real.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f, i) => (
            <div
              key={i}
              className="am-card p-6 group hover:scale-[1.02] transition-transform duration-200"
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center mb-4"
                style={{ background: 'rgba(212,168,83,0.1)', color: 'var(--am-gold)' }}
              >
                <f.icon size={20} />
              </div>
              <h3 className="text-[15px] font-semibold mb-2" style={{ color: 'var(--am-text)' }}>{f.title}</h3>
              <p className="text-[13px] leading-relaxed" style={{ color: 'var(--am-muted)' }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="px-5 sm:px-8 py-20 max-w-4xl mx-auto">
        <div className="text-center mb-14">
          <h2 className="text-2xl sm:text-3xl font-bold" style={{ color: 'var(--am-text)' }}>Planos simples e justos</h2>
          <p className="text-sm mt-3" style={{ color: 'var(--am-muted)' }}>Comece com 30 dias grátis no plano Produtor. Sem surpresas.</p>
        </div>

        <div className="grid sm:grid-cols-2 gap-5">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className="am-card p-6 flex flex-col"
              style={plan.highlighted ? { border: '2px solid var(--am-gold)' } : {}}
            >
              {plan.highlighted && (
                <span className="text-[11px] font-bold px-3 py-1 rounded-full w-fit mb-4"
                  style={{ background: 'rgba(212,168,83,0.15)', color: 'var(--am-gold)' }}>
                  <Star size={12} className="inline mr-1" />Mais popular
                </span>
              )}
              <h3 className="text-lg font-bold" style={{ color: 'var(--am-text)' }}>{plan.name}</h3>
              <p className="text-[13px] mt-1" style={{ color: 'var(--am-muted)' }}>{plan.desc}</p>
              <div className="flex items-baseline gap-1 mt-4">
                <span className="text-3xl font-bold" style={{ color: 'var(--am-gold)' }}>{plan.price}</span>
                <span className="text-sm" style={{ color: 'var(--am-muted)' }}>{plan.period}</span>
              </div>
              <p className="text-[12px] font-medium mt-1" style={{ color: 'var(--am-gold)' }}>{plan.trial}</p>

              <ul className="mt-6 space-y-2.5 flex-1">
                {plan.features.map((feat) => (
                  <li key={feat} className="flex items-start gap-2 text-[13px]" style={{ color: 'var(--am-text)' }}>
                    <ChevronRight size={14} className="mt-0.5 shrink-0" style={{ color: 'var(--am-gold)' }} />
                    {feat}
                  </li>
                ))}
              </ul>

              <button
                className="mt-6 w-full py-3 rounded-xl font-semibold text-sm transition-all active:scale-[0.98]"
                style={
                  plan.highlighted
                    ? { background: 'var(--am-gold)', color: '#0C1F0E' }
                    : { background: 'transparent', border: '1px solid var(--am-border)', color: 'var(--am-text)' }
                }
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* CTA final */}
      <section className="px-5 sm:px-8 py-20 text-center" style={{ borderTop: '1px solid var(--am-border)' }}>
        <h2 className="text-2xl sm:text-3xl font-bold" style={{ color: 'var(--am-text)' }}>
          Pronto para valorizar seu café?
        </h2>
        <p className="text-sm mt-3 max-w-md mx-auto" style={{ color: 'var(--am-muted)' }}>
          Junte-se aos produtores do ES e sul da Bahia que já estão no controle.
        </p>
        <Link to="/dashboard" className="am-btn-primary text-base px-8 py-3.5 mt-8 inline-flex items-center gap-2">
          Começar agora <ArrowRight size={16} />
        </Link>
      </section>

      {/* Footer */}
      <footer className="px-5 sm:px-8 py-8 text-center" style={{ borderTop: '1px solid var(--am-border)' }}>
        <span className="text-sm font-bold tracking-wider" style={{ color: 'var(--am-gold)' }}>AMAGRO</span>
        <p className="text-[12px] mt-2" style={{ color: 'var(--am-muted)' }}>
          &copy; 2026 AMAGRO. Gestão inteligente do café.
        </p>
      </footer>
    </div>
  );
}
