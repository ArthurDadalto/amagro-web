import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Eye, EyeOff, ArrowRight, Coffee, CreditCard } from 'lucide-react';

export function RegisterPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState(1); // 1 = dados, 2 = cartão

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--am-bg)' }}>
      {/* Left branding */}
      <div
        className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12"
        style={{ background: 'var(--am-bg-deep)', borderRight: '1px solid var(--am-border)' }}
      >
        <span className="text-2xl font-bold tracking-wider" style={{ color: 'var(--am-gold)' }}>AMAGRO</span>
        <div>
          <h2 className="text-3xl font-bold leading-tight" style={{ color: 'var(--am-text)' }}>
            30 dias grátis.
            <br />
            <span style={{ color: 'var(--am-gold)' }}>Sem compromisso.</span>
          </h2>
          <p className="text-sm mt-4 max-w-sm leading-relaxed" style={{ color: 'var(--am-muted)' }}>
            Acesso completo ao plano Produtor durante o período de teste.
            Cancele a qualquer momento antes de ser cobrado.
          </p>
          <div className="flex gap-6 mt-8">
            {['Gastos e colheita', 'Cotação e clima', 'Estoque e solo'].map((f) => (
              <div key={f} className="text-[12px] font-medium" style={{ color: 'var(--am-muted)' }}>
                <span style={{ color: 'var(--am-gold)' }}>✓</span> {f}
              </div>
            ))}
          </div>
        </div>
        <p className="text-[11px]" style={{ color: 'var(--am-muted)' }}>&copy; 2026 AMAGRO</p>
      </div>

      {/* Form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="flex items-center gap-2 mb-10 lg:hidden">
            <Coffee size={24} style={{ color: 'var(--am-gold)' }} />
            <span className="text-xl font-bold tracking-wider" style={{ color: 'var(--am-gold)' }}>AMAGRO</span>
          </div>

          {/* Step indicator */}
          <div className="flex gap-2 mb-6">
            {[1, 2].map((s) => (
              <div
                key={s}
                className="h-1 flex-1 rounded-full transition-all"
                style={{ background: step >= s ? 'var(--am-gold)' : 'var(--am-border)' }}
              />
            ))}
          </div>

          {step === 1 ? (
            <>
              <h1 className="text-2xl font-bold mb-1" style={{ color: 'var(--am-text)' }}>Criar conta</h1>
              <p className="text-sm mb-8" style={{ color: 'var(--am-muted)' }}>
                Comece seus 30 dias grátis no plano Produtor.
              </p>

              <div className="space-y-4">
                <div>
                  <label className="block text-[12px] font-medium mb-1.5" style={{ color: 'var(--am-muted)' }}>Nome completo</label>
                  <input type="text" placeholder="João da Silva" required className="am-input" />
                </div>
                <div>
                  <label className="block text-[12px] font-medium mb-1.5" style={{ color: 'var(--am-muted)' }}>Email</label>
                  <input type="email" placeholder="joao@email.com" required className="am-input" />
                </div>
                <div>
                  <label className="block text-[12px] font-medium mb-1.5" style={{ color: 'var(--am-muted)' }}>WhatsApp</label>
                  <input type="tel" placeholder="(27) 99999-0000" className="am-input" />
                </div>
                <div>
                  <label className="block text-[12px] font-medium mb-1.5" style={{ color: 'var(--am-muted)' }}>Senha</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Mínimo 8 caracteres"
                      required
                      className="am-input pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                      style={{ color: 'var(--am-muted)' }}
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => setStep(2)}
                  className="am-btn-primary w-full py-3 flex items-center justify-center gap-2"
                >
                  Continuar <ArrowRight size={16} />
                </button>
              </div>
            </>
          ) : (
            <>
              <h1 className="text-2xl font-bold mb-1" style={{ color: 'var(--am-text)' }}>Cartão de crédito</h1>
              <p className="text-sm mb-2" style={{ color: 'var(--am-muted)' }}>
                Necessário para ativar o teste. Você só será cobrado após 30 dias.
              </p>
              <div
                className="flex items-center gap-2 text-[12px] font-medium px-3 py-2 rounded-lg mb-6"
                style={{ background: 'rgba(212,168,83,0.1)', color: 'var(--am-gold)', border: '1px solid rgba(212,168,83,0.2)' }}
              >
                <CreditCard size={14} />
                Primeiro mês: R$ 0,00 — cobrado R$ 49/mês a partir de {new Date(Date.now() + 30 * 86400000).toLocaleDateString('pt-BR')}
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-[12px] font-medium mb-1.5" style={{ color: 'var(--am-muted)' }}>Número do cartão</label>
                  <input type="text" placeholder="0000 0000 0000 0000" className="am-input" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[12px] font-medium mb-1.5" style={{ color: 'var(--am-muted)' }}>Validade</label>
                    <input type="text" placeholder="MM/AA" className="am-input" />
                  </div>
                  <div>
                    <label className="block text-[12px] font-medium mb-1.5" style={{ color: 'var(--am-muted)' }}>CVV</label>
                    <input type="text" placeholder="123" className="am-input" />
                  </div>
                </div>
                <div>
                  <label className="block text-[12px] font-medium mb-1.5" style={{ color: 'var(--am-muted)' }}>Nome no cartão</label>
                  <input type="text" placeholder="JOÃO DA SILVA" className="am-input" />
                </div>

                <button
                  disabled={isLoading}
                  onClick={() => setIsLoading(true)}
                  className="am-btn-primary w-full py-3 flex items-center justify-center gap-2 disabled:opacity-60"
                >
                  {isLoading ? (
                    <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>Ativar teste grátis <ArrowRight size={16} /></>
                  )}
                </button>

                <button onClick={() => setStep(1)} className="w-full text-center text-[13px] font-medium py-2" style={{ color: 'var(--am-muted)' }}>
                  Voltar
                </button>
              </div>
            </>
          )}

          <p className="text-center text-[13px] mt-6" style={{ color: 'var(--am-muted)' }}>
            Já tem conta?{' '}
            <Link to="/login" className="font-semibold" style={{ color: 'var(--am-gold)' }}>Entrar</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
