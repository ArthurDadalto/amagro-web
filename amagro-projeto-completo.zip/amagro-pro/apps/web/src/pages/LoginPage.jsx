import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Eye, EyeOff, ArrowRight, Coffee } from 'lucide-react';

export function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    // TODO: integrate with auth API
    setTimeout(() => setIsLoading(false), 1500);
  };

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--am-bg)' }}>
      {/* Left side - branding (hidden on mobile) */}
      <div
        className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12"
        style={{ background: 'var(--am-bg-deep)', borderRight: '1px solid var(--am-border)' }}
      >
        <div>
          <span className="text-2xl font-bold tracking-wider" style={{ color: 'var(--am-gold)' }}>AMAGRO</span>
        </div>
        <div>
          <h2 className="text-3xl font-bold leading-tight" style={{ color: 'var(--am-text)' }}>
            Gestão inteligente
            <br />
            <span style={{ color: 'var(--am-gold)' }}>para quem vive o café.</span>
          </h2>
          <p className="text-sm mt-4 max-w-sm leading-relaxed" style={{ color: 'var(--am-muted)' }}>
            Controle financeiro, rastreabilidade por QR Code e cotação em tempo real.
            Do campo à xícara.
          </p>
        </div>
        <p className="text-[11px]" style={{ color: 'var(--am-muted)' }}>&copy; 2026 AMAGRO</p>
      </div>

      {/* Right side - form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-10 lg:hidden">
            <Coffee size={24} style={{ color: 'var(--am-gold)' }} />
            <span className="text-xl font-bold tracking-wider" style={{ color: 'var(--am-gold)' }}>AMAGRO</span>
          </div>

          <h1 className="text-2xl font-bold mb-1" style={{ color: 'var(--am-text)' }}>Bem-vindo de volta</h1>
          <p className="text-sm mb-8" style={{ color: 'var(--am-muted)' }}>
            Entre na sua conta para acessar o dashboard.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[12px] font-medium mb-1.5" style={{ color: 'var(--am-muted)' }}>Email</label>
              <input
                type="email"
                placeholder="seu@email.com"
                required
                className="am-input"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[12px] font-medium" style={{ color: 'var(--am-muted)' }}>Senha</label>
                <Link to="/forgot-password" className="text-[11px] font-medium" style={{ color: 'var(--am-gold)' }}>
                  Esqueceu?
                </Link>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  required
                  className="am-input pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--am-muted)' }}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="am-btn-primary w-full py-3 flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {isLoading ? (
                <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : (
                <>Entrar <ArrowRight size={16} /></>
              )}
            </button>
          </form>

          <p className="text-center text-[13px] mt-6" style={{ color: 'var(--am-muted)' }}>
            Não tem conta?{' '}
            <Link to="/register" className="font-semibold" style={{ color: 'var(--am-gold)' }}>
              Teste grátis por 30 dias
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
