import { create } from 'zustand';

export const useAuthStore = create((set) => ({
  user: null,
  token: null,
  currentFarmId: null,
  isAuthenticated: false,

  setAuth: (user, token) =>
    set({
      user,
      token,
      currentFarmId: user?.farms?.[0]?.id ?? null,
      isAuthenticated: true,
    }),

  setCurrentFarm: (farmId) => set({ currentFarmId: farmId }),

  logout: () => {
    localStorage.removeItem('am-token');
    set({ user: null, token: null, currentFarmId: null, isAuthenticated: false });
  },
}));
