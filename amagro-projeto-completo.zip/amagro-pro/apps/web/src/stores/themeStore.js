import { create } from 'zustand';

const getInitialTheme = () => {
  if (typeof window === 'undefined') return 'dark';
  return localStorage.getItem('am-theme') || 'dark';
};

export const useThemeStore = create((set) => ({
  theme: getInitialTheme(),
  toggleTheme: () =>
    set((state) => {
      const next = state.theme === 'dark' ? 'light' : 'dark';
      localStorage.setItem('am-theme', next);
      document.documentElement.className = next;
      return { theme: next };
    }),
  initTheme: () => {
    const theme = getInitialTheme();
    document.documentElement.className = theme;
    set({ theme });
  },
}));
