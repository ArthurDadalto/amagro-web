/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        am: {
          // Dark mode greens (backgrounds)
          'deep':    '#081509',
          'base':    '#0C1F0E',
          'card':    '#162B18',
          'border':  '#1E3A21',
          'hover':   '#2A5A30',
          // Gold accent
          'gold':    '#D4A853',
          'gold-light': '#E8C872',
          'gold-dim':   '#A07D3A',
          // Text
          'muted':   '#6B8F6E',
          'text':    '#E2E8E3',
          // Light mode
          'cream':   '#F7F5F0',
          'cream-dark': '#E5E0D5',
          'forest':  '#1B4332',
          'forest-light': '#2D6A4F',
          'earth':   '#8B7E6A',
        },
        // Semantic
        success: { DEFAULT: '#4ADE80', dark: '#166534' },
        danger:  { DEFAULT: '#F87171', dark: '#991B1B' },
        warning: { DEFAULT: '#FBBF24', dark: '#92400E' },
        info:    { DEFAULT: '#60A5FA', dark: '#1E40AF' },
      },
      fontFamily: {
        sans: ['"DM Sans"', 'system-ui', 'sans-serif'],
        display: ['"Playfair Display"', 'serif'],
      },
      borderRadius: {
        'am': '12px',
        'am-lg': '16px',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'slide-in-left': 'slideInLeft 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideInLeft: {
          '0%': { opacity: '0', transform: 'translateX(-16px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
      },
    },
  },
  plugins: [],
};
