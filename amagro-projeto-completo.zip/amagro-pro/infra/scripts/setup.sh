#!/bin/bash
# AMAGRO — Setup local completo

set -e
echo "🌿 AMAGRO — Setup local"
echo "========================"

# Backend
echo ""
echo "📦 Configurando API (Laravel)..."
cd apps/api

if [ ! -f composer.json ]; then
  echo "❌ Rode 'composer create-project laravel/laravel .' primeiro nesta pasta"
  exit 1
fi

composer install --no-interaction
cp ../../infra/.env.example .env
php artisan key:generate
php artisan migrate
php artisan db:seed --class=ExpenseCategorySeeder
echo "✅ API pronta"

# Frontend
echo ""
echo "📦 Configurando Web (React)..."
cd ../../apps/web
npm install
echo "✅ Web pronta"

echo ""
echo "========================"
echo "🚀 Tudo pronto! Rode:"
echo "   Terminal 1: cd apps/api && php artisan serve"
echo "   Terminal 2: cd apps/web && npm run dev"
echo "   Abrir: http://localhost:5173"
