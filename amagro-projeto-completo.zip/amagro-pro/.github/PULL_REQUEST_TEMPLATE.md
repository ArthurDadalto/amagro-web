## O que mudou?

<!-- Descreva brevemente -->

## Tipo de mudança

- [ ] feat: nova funcionalidade
- [ ] fix: correção de bug
- [ ] refactor: refatoração
- [ ] docs: documentação
- [ ] chore: manutenção

## Checklist

- [ ] Testei localmente
- [ ] Sem erros no lint
- [ ] Migrations rodam sem erro (se aplicável)
- [ ] Documentação atualizada (se aplicável)
