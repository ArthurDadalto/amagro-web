---
name: Bug Report
about: Reportar um problema
---

## Descrição do bug

## Passos para reproduzir

1.
2.
3.

## Comportamento esperado

## Screenshots (se aplicável)

## Ambiente
- Browser:
- Mobile/Desktop:
- Plano:
