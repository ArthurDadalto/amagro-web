---
name: Feature Request
about: Sugerir uma funcionalidade
---

## Problema que resolve

## Solução proposta

## Alternativas consideradas
