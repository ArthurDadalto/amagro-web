# AMAGRO — Gestão Inteligente do Café

SaaS de gestão para produtores de café (Arábica e Conilon).
Foco: Espírito Santo e sul da Bahia.

## Stack
- **Backend:** Laravel 11 (API REST) + PostgreSQL
- **Frontend:** React 19 + Vite + Tailwind CSS
- **Auth:** Laravel Sanctum
- **Design:** Direction B (verde escuro + dourado, dark/light mode)

## Quick Start

```bash
# Backend
cd backend
composer install
cp .env.example .env
php artisan migrate
php artisan db:seed --class=ExpenseCategorySeeder
php artisan serve

# Frontend (outro terminal)
cd frontend
npm install
npm run dev
```

Abrir http://localhost:5173

## Documentação
Tudo em `docs/`
