# AMAGRO — Setup Local (do zero)

## Pré-requisitos

- Laragon (já inclui PHP, Composer, MySQL, Node, Git)
- VS Code

## Passo 1 — Criar o projeto do zero

Abra o **Terminal do Laragon** e rode:

```bash
cd C:/laragon/www
mkdir amagro
cd amagro
git init
```

## Passo 2 — Descompactar o ZIP

Descompacte o `amagro-projeto-completo.zip` que você baixou.
Copie o **conteúdo** da pasta `amagro-pro/` para dentro de `C:/laragon/www/amagro/`.

A estrutura deve ficar assim:

```
C:/laragon/www/amagro/
├── apps/
│   ├── api/         ← Arquivos AMAGRO (ainda não é Laravel completo)
│   └── web/         ← React pronto
├── packages/
├── docs/
├── infra/
├── .github/
├── .gitignore
├── .editorconfig
└── README.md
```

## Passo 3 — Criar o Laravel dentro de apps/api

O ZIP contém apenas os arquivos AMAGRO (Models, Controllers, Migrations, etc.).
Precisamos criar o Laravel completo e depois copiar os arquivos por cima.

```bash
cd C:/laragon/www/amagro

# Criar Laravel num diretório temporário
composer create-project laravel/laravel temp-api

# Mover TODO o conteúdo do temp-api para apps/api
# (isso traz artisan, config/, vendor/, etc.)
xcopy temp-api\* apps\api\ /E /Y /I

# Remover o temporário
rmdir /S /Q temp-api
```

**Importante:** o `xcopy` vai perguntar se quer sobrescrever — responda **S (Sim para todos)**. Os arquivos AMAGRO que já estão em `apps/api/` (User.php, api.php, web.php, bootstrap/app.php) serão sobrescritos pelo Laravel padrão. Vamos restaurá-los no próximo passo.

Agora **recopie os arquivos AMAGRO por cima** dos padrões do Laravel:
- Reextraia o ZIP e copie apenas `apps/api/` por cima de novo (sobrescrever tudo)

Instale as dependências extras:

```bash
cd apps/api
composer require laravel/sanctum simplesoftwareio/simple-qrcode
```

## Passo 4 — Configurar o banco (MySQL via Laragon)

1. Abra o **Laragon** → clique em **Database** (abre o HeidiSQL)
2. Clique com botão direito → **Criar novo** → **Banco de dados**
3. Nome: `amagro` → OK

Agora configure o `.env`:

```bash
cd C:/laragon/www/amagro/apps/api
copy ..\..\infra\.env.example .env
php artisan key:generate
```

O `.env` já vem configurado para MySQL local do Laragon (root sem senha).

## Passo 5 — Rodar migrations

```bash
cd C:/laragon/www/amagro/apps/api
php artisan migrate
php artisan db:seed --class=ExpenseCategorySeeder
```

Deve mostrar 10 migrations rodadas com sucesso.

## Passo 6 — Configurar CORS e Sanctum

Edite `apps/api/config/cors.php`:
```php
'supports_credentials' => true,
'allowed_origins' => [env('FRONTEND_URL', 'http://localhost:5173')],
```

Edite `apps/api/config/sanctum.php`:
```php
'stateful' => explode(',', env(
    'SANCTUM_STATEFUL_DOMAINS',
    'localhost,localhost:5173'
)),
```

## Passo 7 — Testar o backend

```bash
cd C:/laragon/www/amagro/apps/api
php artisan serve
```

No navegador: `http://localhost:8000/health` → deve retornar `{"status":"ok"}`

## Passo 8 — Instalar e rodar o frontend

Abra **outro terminal** do Laragon:

```bash
cd C:/laragon/www/amagro/apps/web
npm install
npm run dev
```

## Passo 9 — Testar tudo junto

Com os dois terminais rodando:

| URL | O que deve aparecer |
|-----|-------------------|
| `localhost:5173` | Landing page AMAGRO (verde escuro + dourado) |
| `localhost:5173/login` | Tela de login split-screen |
| `localhost:5173/register` | Cadastro em 2 steps (dados + cartão) |
| `localhost:5173/dashboard` | Dashboard com sidebar, KPIs, cotação |
| `localhost:8000/health` | `{"status":"ok"}` |

## Passo 10 — Criar repositório no GitHub

Crie um repositório **novo e vazio** no GitHub (sem README, sem .gitignore).

```bash
cd C:/laragon/www/amagro
git add .
git commit -m "feat: AMAGRO MVP - monorepo (api + web)"
git remote add origin https://github.com/ArthurDadalto/amagro.git
git branch -M main
git push -u origin main

# Criar branch de desenvolvimento
git checkout -b develop
git push -u origin develop
```

## Abrindo no VS Code

Abra a pasta `C:/laragon/www/amagro/` no VS Code.
Você verá toda a estrutura profissional no Explorer.
